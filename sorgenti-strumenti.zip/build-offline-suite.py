#!/usr/bin/env python3
"""Rebuild every offline page from Suite-source; no hosted-site mutation."""
from pathlib import Path
import argparse,base64,hashlib,json,re,shutil
P=Path(__file__).resolve().parent
arg=argparse.ArgumentParser();arg.add_argument('--output',type=Path,default=P/'Bloomy-Offline');a=arg.parse_args();D=a.output;D.mkdir(parents=True,exist_ok=True)
pages={k:(P/'Suite-source'/f'{k}.html').read_text() for k in ['install','backup','convert','projects']}
fw=re.search(r'const OFFLINE_FW = "([^"]+)"',pages['install'])[1]
assert hashlib.sha256(base64.b64decode(fw)).hexdigest()=='8b2a5f14f9fe302008824d121b8a1a6cc5dbaffd6297e588ecdd32b426e4857b'
assert all('crypto.subtle.digest' not in s or 'globalThis.crypto.subtle.digest' in s or 'globalThis.crypto?.subtle' in s for s in pages.values())
payload={k:base64.b64encode(s.encode()).decode() for k,s in pages.items()}
shell=(P/'Suite-source/shell.html').read_text();assert shell.count('__PAYLOAD__')==1
(D/'Bloomy.html').write_text(shell.replace('__PAYLOAD__',json.dumps(payload)))
for key,name in [('install','Installazione-diretta.html'),('backup','Backup-diretto.html'),('convert','Convertitore-diretto.html'),('projects','Progetti-diretti.html')]:
 s=pages[key]
 s=re.sub(r"<script>document.addEventListener\('click',e=>.*?</script>",'',s,flags=re.S)
 s=s.replace('href="Backup.html"','href="Backup-diretto.html"').replace('href="Installazione.html"','href="Installazione-diretta.html"').replace('href="Manuale.pdf"','href="Manuale-Bloomy-1.0.pdf"').replace('href="../manual/Manuale-Bloomy-1.0.pdf"','href="Manuale-Bloomy-1.0.pdf"')
 (D/name).write_text(s)
manifest={'suite':'Bloomy Offline','firmware_version':'1.0.0-blue','tools_revision':'1.2','firmware_sha256':hashlib.sha256(base64.b64decode(fw)).hexdigest(),'sections':list(pages),'network_dependencies':[],'user_reported':['offline page and installer SHA work on iPhone','Backup and Restore work on iPhone'],'ios_other_devices':'NOT_RUN','firmware_changed':False}
(D/'MANIFEST.json').write_text(json.dumps(manifest,indent=2))
print('Built',D,'from canonical sources')
