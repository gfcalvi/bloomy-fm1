"""Package tools 1.5. Does not modify firmware or publish remotely."""
from pathlib import Path
import hashlib,json,shutil,zipfile,re
P=Path(__file__).resolve().parents[2];S=P/'Strumenti/Bloomy-Offline';D=P/'Hosting-statico/dist';U=P/'Hosting-statico/update';M=P/'Manuale-Bloomy-1.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(S/'Bloomy-1.0.1.fwsc')=='fc4657446c35c9145f100f1d294a2f5a68c672937e7d43f03338241c7eb1805d'
assert sha(S/'Bloomy-1.0.1.rfm1')=='9d8c08d61e3bd9370c1b93782d32f46a6f6c89e3a42a97af0daf21ad7f7ddbbf'
shutil.copy2(M/'Manuale-Bloomy-1.0.pdf',S/'Manuale-Bloomy-1.0.pdf')
report='''# Bloomy — strumenti 1.5

Firmware 1.0.1 invariato. Manuale edizione 13. Nessuna scrittura hardware eseguita dall’agente.

Carica brano legge l’archivio salvato, sostituisce i sette oggetti dello slot scelto,
conserva gli altri due slot e la libreria preset. Il banco campioni non viene scritto.
Confronto di compatibilità dei campioni, backup preventivo scaricabile, conferma
interna alla pagina, rilettura prima dell’invio e verifica completa dopo il ripristino.
Usa il protocollo journalled già esistente: non richiede firmware nuovo.

105 casi software PASS, 0 FAIL:
- 34 percorsi nelle pagine reali di Chrome, con MIDI simulato (29 precedenti + 5 nuovi).
- 19 casi di importazione/merge: cinque formati, tutte le destinazioni, slot vuoto,
  CRC, dati compressi, campioni incompatibili e vecchio RemoteFM1 compresso.
- 12 casi del controller di caricamento: conferma/annulla, STOP/HOME/errori,
  cambiamenti del dispositivo, disconnessione, rilettura errata e condivisione iOS opzionale.
- 3 trasferimenti SysEx completi verso ciascuno slot con dispositivo simulato,
  conferma hardware simulata e confronto byte per byte degli altri slot.
- 23 regressioni formati/sicurezza e 14 regressioni del protocollo backup/campioni.

Le simulazioni non sono misure delle temporizzazioni USB dell’iPhone o del chip.
L’utente aveva confermato Backup/Restore e uso offline su iPhone; il nuovo percorso
Carica brano non è ancora stato provato fisicamente su iPhone/FM-1.

File TXT senza banco: usa i campioni esistenti; i soli parametri non identificano
l’audio originale. Per campioni personalizzati preferire un backup con LSMP.

Sorgenti e builder inclusi. Fixture e backup privati non distribuiti.
'''
(S/'VERIFICA-STRUMENTI.md').write_text(report)
(S/'LEGGIMI.txt').write_text('''BLOOMY 1.0.1 — STRUMENTI 1.5
https://gfcalvi.github.io/bloomy-fm1/
Mac: Chrome/Edge online. iPhone: MIDIWeb Browser, online o Make Available Offline.
Aggiorna la copia offline aprendo il sito online e salvandolo nuovamente.
Carica brano: SAVE e STOP sul dispositivo, scegli file e destinazione,
leggi FM-1, salva il backup preventivo, conferma nella pagina e con SEL su FM-1.
Gli altri due slot, preset e campioni vengono conservati e verificati.
Supporta .bloomyproject/.loom8/.txt/.rfm1state/.fm1save senza conversione preliminare.
Set e slot: prepara un intero set. Backup → Ripristino completo: sostituisce tutto.
Firmware invariato 1.0.1: nessuna reinstallazione necessaria per Carica brano.
Manuale edizione13 incluso. File elaborati sul dispositivo, senza upload.
''')
with zipfile.ZipFile(S/'sorgenti-strumenti.zip','w',zipfile.ZIP_DEFLATED) as z:
 for rel in ['build-offline-suite.py',*[str(p.relative_to(P/'Strumenti')) for p in sorted((P/'Strumenti/Suite-source').glob('*.html'))],*[str(p.relative_to(P/'Strumenti')) for p in sorted((P/'Strumenti/Carica-brano').glob('*')) if p.is_file()]]:
  z.write(P/'Strumenti'/rel,rel)
def sums(d):
 (d/'SHA256SUMS').write_text(''.join(sha(p)+'  '+str(p.relative_to(d))+'\n' for p in sorted(d.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
# Remove obsolete QA evidence from the current deliverable, keep full local QA separately.
for name in ['browser-results.txt','format-tests.log','protocol-tests.log','Verifica-browser.png','Anteprima.png']:
 f=S/name
 if f.exists():shutil.move(f,P/'Strumenti/QA/carica-brano'/('precedente-'+name))
sums(S)
Z=P/'Strumenti/Bloomy-Offline-1.5.zip'
with zipfile.ZipFile(Z,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(S.iterdir()):
  if p.is_file():z.write(p,'Bloomy-Offline/'+p.name)
(D/'index.html').write_text((S/'Bloomy.html').read_text())
for name in ['Installazione-diretta.html','Backup-diretto.html','Carica-brano.html','Convertitore-diretto.html','Progetti-diretti.html','Manuale-Bloomy-1.0.pdf','sorgenti-strumenti.zip','VERIFICA-STRUMENTI.md']:
 shutil.copy2(S/name,D/name)
zlink=D/Z.name
if zlink.exists() or zlink.is_symlink():zlink.unlink()
zlink.symlink_to('../../Strumenti/'+Z.name)
(D/'README.md').write_text('''# Bloomy 1.0.1 · strumenti 1.5
https://gfcalvi.github.io/bloomy-fm1/

Installazione · Backup · Carica brano · Convertitore · Set e slot.
Carica un singolo progetto in uno slot conservando gli altri due, preset e campioni.
SAVE e STOP prima della lettura; backup preventivo e rilettura di verifica inclusi.
Formati .bloomyproject/.loom8/.txt/.rfm1state/.fm1save. Banchi incompatibili bloccati.

Mac: Chrome/Edge. iPhone: MIDIWeb Browser, anche dopo Make Available Offline.
Aggiornare la copia salvata per vedere Strumenti1.5. Nessun login/server locale.
Firmware invariato1.0.1; nessuna reinstallazione per usare Carica brano.
Manuale edizione13. File personali elaborati nel browser, senza upload.
Licenze e attribuzioni originali conservate in LICENZE.txt e sorgenti.
''')
for p in D.glob('*.zip'):
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  assert not any(re.search(r'\.(loom8|rfm1state|bloomyproject|fm1save)$',n,re.I) for n in z.namelist())
  assert not any(re.search(r'(^|/)(\.env[^/]*|\.git/|credentials[^/]*)',n,re.I) for n in z.namelist())
sums(D)
for p in D.iterdir():
 if p.is_file():
  q=U/p.name
  if q.exists() or q.is_symlink():q.unlink()
  q.symlink_to('../dist/'+p.name)
print('Prepared',len(list(D.iterdir())),'public files; firmware unchanged; zip',Z.stat().st_size)
