from pathlib import Path
import re
P=Path(__file__).resolve().parent;S=P.parent/'Suite-source'
c=(S/'convert.html').read_text();b=(S/'backup.html').read_text();p=(S/'projects.html').read_text()
def iife(s,start):
 a=s.index(start);return s[a:s.index('})();',a)+5]
codec=iife(c,'globalThis.Bloomy =')
validation='' # Converter already has identical validate; export it below.
codec=codec.replace('return{saveRead,',''+validation+'\nreturn{validate,saveRead,')
picker=iife(p,'globalThis.Picker=') if 'globalThis.Picker=' in p else iife(p,'globalThis.Picker =')
bridge='<script>'+b[b.index('// MIDIWeb may expose'):b.index('</script>',b.index('// MIDIWeb may expose'))]+'</script>'
protocol=b[b.index('// --- backup protocol: begin'):b.index('// --- backup protocol: end')]
extras=b[b.index('const EXTRAS =',b.index('// --- backup protocol: end')):b.index('// one MIDI in/out pair')]
link=b[b.index('class Link {',b.index('// one MIDI in/out pair')):b.index('const $ =',b.index('// one MIDI in/out pair'))]
decoder=re.search(r"const decoder\s*=\s*Bloomy.un64\('[^']+'\);",c)[0]
page=(P/'page.html').read_text()
for k,v in dict(BRIDGE=bridge,CODEC=codec,PICKER=picker,TRANSFER=(P/'slot-transfer.js').read_text(),PROTOCOL=protocol,EXTRAS=extras,LINK=link,UI=decoder+'\n'+(P/'ui.js').read_text()).items():page=page.replace('@@'+k+'@@',v)
assert '@@' not in page
(S/'load.html').write_text(page)
print('Built Carica brano:',len(page.encode()),'bytes')
