/* SPDX-License-Identifier: MPL-2.0 */
/* Bloomy: the project (everything that is saved), the app's entry points and its half of the contract with fm1-base
 * (base/device/unity.c, base/host/plat_host.c). Included first by fm1-base's unity build and by its simulator. */
#pragma once
#include <stdint.h>
#include "plat.h"
#include "seq/pattern.h"
#include "seq/seq.h"
#include "dsp/synth.h"
#include "dsp/fx.h"

#define APP_NAME "Bloomy"
#define APP_BLOCK 256u                  /* frames a render (5.8 ms): fm1-base's USB audio input takes 256-frame halves
                                         * at most (felucca-bsp usb.c); Bloomy's own platform had 512-frame halves,
                                         * each rendered as two 256-frame calls, which is what the simulator always did */
#define FM1B_UAC_DEEP 1                 /* the USB audio input a half deeper: a song's busy blocks take most of their
                                         * time, which ran fm1-base's ring dry (holds in a recording; base/device/unity.c) */
#define APP_CANVAS_PX (240u * 120u)     /* the tallest band, the main one, is 240 x 120 */
#define APP_SYS_TEXT                    /* fm1-base's own screens (crash, update, restore, calibration) in Bloomy's faces:
                                         * gfx_loom.c app_sys_*; fm1-base's are then not linked (18 KB) */

/* Five-slot storage: keep calibration/presets, the first three projects and BLE at their original addresses.
 * Additional project objects 24..37 occupy C1000..DAFFF and E5000..E6FFF, with A/B pairs.
 * Object 37 uses APP_STORE_GAP to leave each loader record mark erased. The sample bank has 104 KiB:
 * DB000 (4 KiB), E7000 (84 KiB), 93000 (16 KiB). Upgrading requires lossless bank relocation
 * from a verified full backup; never install the five-slot firmware with the old sample installer. */
#define NPROJ 5                         /* project slots in flash */
#define PROJ_NOSLOT 0xFFu                /* proj_slot of a new project when every slot is taken: SAVE TO gives it one */
#define PROJ_NOBJ 7
enum { OBJ_PANEL, OBJ_PRESETS, OBJ_PROJ0, OBJ_BLE = 23, OBJ_NOBJ = 38 };
#define OBJ_PROJ(slot, k) (OBJ_PROJ0 + (slot) * PROJ_NOBJ + ((slot) >= 3) + (k))
#define APP_STORE_MAP {0xdc000u, 0xde000u, 0x97000u, 0x99000u, 0x9b000u, 0x9d000u, 0x9f000u, 0xa1000u, 0xa3000u, 0xa5000u, 0xa7000u, 0xa9000u, 0xab000u, 0xad000u, 0xaf000u, 0xb1000u, 0xb3000u, 0xb5000u, 0xb7000u, 0xb9000u, 0xbb000u, 0xbd000u, 0xbf000u, 0xfc000u, 0xc1000u, 0xc3000u, 0xc5000u, 0xc7000u, 0xc9000u, 0xcb000u, 0xcd000u, 0xcf000u, 0xd1000u, 0xd3000u, 0xd5000u, 0xd7000u, 0xd9000u, 0xe5000u}
#define APP_STORE_GAP 1


/* backup and restore over USB (fm1-base's backup.c; base/tools/fm1_backup.py, base/web/backup): the user presets
 * and the five project slots, all or nothing. Not the user sample bank (raw flash, not store objects: its source is
 * the player's own WAVs, tools/loom_samples.py); a restore writes only the objects listed here, never its windows */
#define APP_BACKUP_OBJS {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37}
#define APP_BACKUP_MAGIC 0x42384D4Cu     /* "LM8B" */
#define APP_BACKUP_VERSION 2u
#define APP_BACKUP_WHAT "replaces projects, presets"
int app_backup_playing(void);
void app_backup_flush(void);
void app_backup_hold(int on);
void app_backup_restored(void);

/* the contract: the platform calls these (app.c) */
void app_init(void);                    /* boot: the user bank, the project, the presets, the engine, the second core */
void app_render(int32_t *lr, uint32_t n, uint32_t gain_q12);   /* audio interrupt: n stereo frames, 24-bit */
void app_panic(void);                   /* silence now (before an update rewrites the flash) */
void app_ui_init(void);
void app_frame(void);
void app_input_only(void);
void app_say(const char *a, const char *b);
#define APP_BTDEV                       /* Bluetooth MIDI devices (fm1-base lib/btdev.h): GLO's BT DEVICE list (bt.c) */
#define APP_SPLASH                      /* the name over the eight tracks' inks woven as threads */
void app_splash(void);
#define APP_REDRAW                      /* the screen mirror lost a part (or a viewer came): every band again */
void app_redraw(void);
#define APP_SYSEX                       /* the user sample bank over USB-MIDI (samples.c: F0 7D 46 4C) */
int app_sysex(const uint8_t *p, uint32_t n);

/* the host simulator's part (host.c): Bloomy's checks and commands, the screen reader's dump */
#ifdef PLAT_HOST
#define APP_HOST_EXPECT
int app_expect(const char *what, int *got);
#define APP_HOST_CMD
int app_host_cmd(const char *cmd, const char *a, const char *b, const char *c, const char *d);
#define APP_HOST_SPEAKDUMP
void app_speak_dump(void);
#define APP_HOST_REBOOT
void app_host_reboot(void);
#define APP_HOST_FAILS
int app_host_fails(void);
#define APP_HOST_MS                     /* the voices' and the estimated load's peaks (host.c "stats") */
void app_host_ms(void);
#define APP_HOST_CPU2                   /* the second core simulated in host.c (its work counted apart) */
#endif

/* Bloomy's own platform extras, beyond fm1-base's plat.h (its second core too: fm1.toml cpu2 = true): on the FM-1 in
 * plat_loom.c (felucca-bsp's helpers), in the simulator in host.c */
uint32_t plat_cpu_peak_pct(void);       /* the render's peak load since the last call, % */
uint32_t plat_cycles(void);             /* a cycle counter for the profiler (ISR) */
int plat_store_load_prev(uint32_t obj, void *dst, uint32_t max);   /* the copy before the current one (a torn stream) */
int loom_store_save(uint32_t obj, const void *src, uint32_t len);  /* plat_store_save, the host keeping the copy before */
int plat_vdc14_mv(void);                /* VDC14 as set at start, mV (the Status page) */
int plat_sysvdd_mv(void);
int plat_last_crash(uint32_t v[5]);     /* 1: a crash since power-on (vec, pc, emu, dbg, rets as its red screen) */
/* the lights: lit buttons and keys; glow: the unlit buttons dim (PLAY's green one); dim_keys dim; red: PLAY red */
void loom_lights(uint32_t buttons, uint32_t keys, int glow, uint32_t dim_keys, int red);

/* a debug build (not tools/build.py --release): GLO's last page, Debug, with the load, the voices and CORES */
#define DEBUG_BUILD (APP_VERSION[0] == 'D' && APP_VERSION[1] == 'E' && APP_VERSION[2] == 'V' && \
                     (!APP_VERSION[3] || APP_VERSION[3] == 'T'))   /* DEV, or the load test's DEVTEST */
#define PROJ_MAGIC 0x384D4F4Cu          /* "LOM8" (was "XXY1": XY-1's projects start fresh) */
#define PROJ_FORMAT 28u                 /* 24: bounded project notes trailer after compressed track settings.
                                         * 22: synth layer controls in existing track bytes, old imports neutral.
                                         * 20: appended Tweed engine and hybrid kit models (old indices unchanged).
                                         * (10, 0.5-beta's, to 12 load too: project.c migrate_old; older ones do not)
                                         * 19: Generator/Evolver config and protected degree-offset lanes (no struct growth);
                                         * 18: two extra LFOs per melodic track;
                                         * 16: knit's osc 2 fine (TP_O2FINE), the tracks' last parameter;
                                         * 15: a kit key's knobs 5..8 (TP_DRUMX: an eight-knob model's second page), after
                                         * the keys; the settings object's tracks packed (project.c settings_pack);
                                         * 14: the filter type off (FT_DYNAMIC) moved past bp12 (TP_FTYPE 4 and 5 swap);
                                         * 13: the shared LFO (the conductor's LFO slots: glfo_defaults on an older one);
                                         * 12: a scene's kit sound mutes per kit track (scene_t kmute[NKITM]);
                                         * 11: 32 scenes, a scene's kit sound mutes (one mask);
                                         * 10: a kit key's own sends (DP_SEND1/2, the kit's track sends gone), a
                                         *     parameter's index past a byte (a lane's 16 bits, LANE_TUNE moved);
                                         * 9: the sound's octave (TP_OCT) moved TP_PLAYER on;
                                         * 8: the WEAVE track (its patterns, its settings: a track more);
                                         * 7: a kit step's sounds as bits (pattern.h kit_*: any of the 11);
                                         * 6: the engine's second page (TP_X1..X4: brocade's sub) moved TP_PLAYER on
                                         * (and every index after it); 5: the master's pump (master[] 12 -> 16
                                         * bytes, out of rsv[]); 4: no tape (its track and send), the reverb's modes, the master's tape,
                                         * and each drum key its envelope and filter (DP_N 9 -> 18); 2: the character
                                         * stage moved TP_PLAYER on (and every index after it) */
#define NUSER_PRESETS 16
#define NAME_LEN 12

typedef struct {
    uint8_t par[NTP];                   /* dsp/synth.h: the sound, player, mix, brain, channel, the drum kit */
    char name[NAME_LEN];                /* the preset's name, as loaded or saved */
    uint8_t rsv[4];
} trk_t;

/* the settings object: small, stored raw. The patterns (seq/pattern.h patterns_t, in the pool) are
 * an LZ stream across the slot's other objects */
typedef struct {
    uint32_t magic, format;
    char name[NAME_LEN];                /* (unused since projects lost their names: a project is its slot, "Proj 2";
                                         * kept, so format 10's projects load) */
    uint16_t tempo_x10;                 /* 400..3000 */
    uint8_t swing;                      /* unused since the grooves (a reserved byte; the UI may still write it) */
    uint8_t groove;                     /* the project's groove type (pattern.h GR_*); each track has its amount */
    uint8_t metronome;                  /* 0 off, 1 while recording, 2 on */
    uint8_t lights;                     /* 0 off, 1 keys and glow, 2 keys only */
    uint8_t clock, send_notes, one_core, usb_full;
    uint8_t scene;                      /* the scene to start on */
    uint8_t trk_sel;                    /* the track selected */
    uint8_t rsv[10];                    /* (format 4 had 14: its last four are master[0..3] now); rsv[0] the count-in,
                                         * [1] the theme, [2] bits (pages.c): 1 REC's mode, 2 SCENES SWITCH
                                         * (SCENES_AT_END), 4 AUTOSAVE_OFF, 8 LOOP_FREE, 16 CC_OUT_OFF, 32 SCENES_OUT, 64 BT_AUDIO_ON, 128 BT_MIDI_OFF (bt.c);
                                         * [4..7] the save count (project.c: the slot saved or loaded last opens at
                                         * power-on) */
    uint8_t master[NMS];                /* fx.h MS_*: format 4's twelve end where these sixteen end */
    trk_t trk[NALLTRK];
} settings_t;

typedef struct {
    char name[NAME_LEN];
    uint8_t engine;
    uint8_t par[NTP_SOUND];
    uint8_t o2fine;                     /* knit's osc 2 fine (TP_O2FINE, past par[]: presets format 9) */
} user_preset_t;

#define PROJECT_NOTES_MAX 250
extern char project_notes[PROJECT_NOTES_MAX + 1];
extern settings_t proj;                 /* the project's settings (RAM) */
extern uint8_t proj_par[NALLTRK][NTP];  /* the tracks' par[] as one contiguous array: what the synth and the
                                         * sequencer read (engine_init gets it); engine_set / engine_set_all
                                         * keep it in step with proj.trk[].par (the UI writes those) */
extern patterns_t pats;                 /* its patterns, lanes, scenes, song (pool) */
extern user_preset_t user_presets[NUSER_PRESETS];
extern uint8_t user_layer[NUSER_PRESETS][LAYER_N];
/* the user kits (a kit track's SELECT list: SAVE KIT, KIT): a kit is its name, the track's sound (par[0..NTP_SOUND):
 * the kit's envelope, bus filter, sends, LFO, character, volume) and its keys (par[TP_DRUM0..TP_O2FINE)); not the mix, the
 * players or MIDI OUT. They live in the presets object after the user presets (PRESETS_FORMAT 9), in flash only:
 * RAM keeps their names */
#define NUSER_KITS 8                     /* (formats 8..10 held four: presets_load) */
#define KIT_KEYS (TP_O2FINE - TP_DRUM0)          /* (the keys and their knobs 5..8: not knit's osc 2 fine after them) */
#define KIT_LEN (NAME_LEN + NTP_SOUND + KIT_KEYS)
extern char user_kit_name[NUSER_KITS][NAME_LEN];   /* "" = an empty slot */
void kit_hybrid(uint8_t *img);
int kit_load(int slot, uint8_t *img);  /* img: KIT_LEN bytes; 0 = the slot holds a kit, 1 = one saved before presets
                                        * format 10 (its keys past the sample model: a development build's, keys_fix) */
int kit_save(int slot, const uint8_t *img);   /* 0 = saved (the user presets with it, as they are) */
extern uint8_t proj_slot;               /* the slot loaded */

void project_defaults(void);
void project_device_get(void);         /* the FM-1's own settings (Setup's, the theme) noted, and put back */
void project_device_put(void);         /* into proj: a project loaded keeps them */
void project_random_sounds(uint32_t seed);   /* T2-T8: a random preset each of a part (bass, poly, pad, lead, keys, fx, pluck) */
int project_mem_pct(void);              /* how full the patterns' room in flash is, % (the last save or load) */
int project_load(int slot);             /* 0 = loaded; else defaults are in place */
int project_save(int slot);             /* 0 = saved and verified; -1 = full / failed */
void project_apply(void);               /* every value to the engine (boot, load) */
int project_exists(int slot);
extern uint32_t project_titles_revision;
int project_slot_title(int slot,char name[NAME_LEN]);
int project_last_slot(void);            /* the slot saved or loaded last (0 when none holds a project) */
int project_touch(int slot);            /* the loaded slot the last: its settings saved again, its count the next */
int presets_load(void);
int presets_save(void);

void ui_init(void);
void ui_frame(void);
void ui_input_only(void);
void ui_redraw(void);
int ui_dirty(void);
int ui_asking(void);                             /* a question is up (the host's expect ask) */
void ui_say(const char *a, const char *b);
