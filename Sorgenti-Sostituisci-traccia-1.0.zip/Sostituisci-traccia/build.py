from pathlib import Path
import json
P=Path(__file__).resolve().parent;R=P.parents[1]
parts=['Sviluppo/Shimmer/tools/codec.js','Sviluppo/Titolo-1.1.1/metadata-final.js','Sviluppo/Export-WAV/picker.js','Sviluppo/Titolo-1.1.1/slot-transfer.js','Sviluppo/Sostituisci-traccia/track-transfer.js']
js='\n'.join((R/p).read_text() for p in parts)
js+='\nconst DECODER=Bloomy.un64('+json.dumps((R/'Sviluppo/Export-WAV/dependencies/decoder.b64').read_text().strip())+');\n'+(P/'page.js').read_text()
(P/'Sostituisci-traccia.html').write_text((P/'page.html').read_text().replace('<!--SCRIPTS-->','<script>'+js.replace('</script','<\\/script')+'</script>'))
print('Standalone offline page:',(P/'Sostituisci-traccia.html').stat().st_size,'bytes')
