/* SPDX-License-Identifier: MPL-2.0
 * Bloomy Track Transfer 1.0: file-only, immutable merge. Raw layout checked against
 * Bloomy project.c / pattern.h, formats 23 and 24. No MIDI or device writes. */
globalThis.TrackTransfer=(()=>{
'use strict';
const TRACK=357,PARAMS=341,TPAT=776,TRACKPAT=6208,LANE=63648,NLANE=96,SCENE=70368,SONG=71200,RAW=71332;
const U16=(b,p)=>new DataView(b.buffer,b.byteOffset,b.byteLength).getUint16(p,true),U32=(b,p)=>new DataView(b.buffer,b.byteOffset,b.byteLength).getUint32(p,true);
const W16=(b,p,v)=>new DataView(b.buffer,b.byteOffset,b.byteLength).setUint16(p,v,true),W32=(b,p,v)=>new DataView(b.buffer,b.byteOffset,b.byteLength).setUint32(p,v,true);
const eq=Five.eq,fail=s=>{throw Error(s)},cat=parts=>{const b=new Uint8Array(parts.reduce((n,a)=>n+a.length,0));let p=0;for(const a of parts){b.set(a,p);p+=a.length}return b};
function unzip(input,size){
 const out=new Uint8Array(size);let r=0,w=0;
 while(r<input.length&&w<size){let c=input[r++],n;
  if(c<128){n=c+1;if(r+n>input.length||w+n>size)fail('Dati compressi troncati.');out.set(input.subarray(r,r+n),w);r+=n;w+=n}
  else{n=(c&127)+3;if(r+2>input.length)fail('Dati compressi troncati.');const d=input[r++]+256*input[r++]+1;if(d>w||w+n>size)fail('Compressione progetto non valida.');for(let i=0;i<n;i++,w++)out[w]=out[w-d]}
 }
 if(w!==size||r!==input.length)fail('Dimensione del progetto non valida.');return out;
}
// Same bounded LZ77 as firmware lz.c; decoder acceptance is independently checked.
function zip(a){
 const head=new Int32Array(2048).fill(-1),out=[];let i=0,lit=0;
 const hash=p=>Math.imul((a[p]<<16)|(a[p+1]<<8)|a[p+2],2654435761)>>>21;
 const match=(c,p)=>{let n=0;while(n<130&&p+n<a.length&&a[c+n]===a[p+n])n++;return n};
 const literals=(p,n)=>{while(n){const k=Math.min(n,128);out.push(k-1);for(let j=0;j<k;j++)out.push(a[p+j]);p+=k;n-=k}};
 while(i<a.length){let best=0,dist=0;
  if(i+3<=a.length){const h=hash(i),c=head[h];head[h]=i;if(c>=0&&i-c<=65536){best=match(c,i);dist=i-c}if(i){const n=match(i-1,i);if(n>best){best=n;dist=1}}}
  if(best<3){i++;continue}literals(lit,i-lit);out.push(128|(best-3),(dist-1)&255,(dist-1)>>>8);
  for(let k=1;k<best&&i+k+3<=a.length;k++)head[hash(i+k)]=i+k;
  i+=best;lit=i;
 }
 literals(lit,a.length-lit);const b=Uint8Array.from(out);if(!eq(unzip(b,a.length),a))fail('Verifica compressione fallita.');return b;
}
function slotBase(m,slot){Bloomy.validate(m);if(!Number.isInteger(slot)||!m.projects.includes(slot))fail('Scegli uno slot con un progetto.');return Five.base(slot)}
function decode(m,slot){
 const base=slotBase(m,slot),a=m.objects[base],fmt=U32(a,4);
 if(![23,24].includes(fmt))fail('Questa versione del progetto non è supportata per sostituire tracce. Aprila e salvala con Bloomy aggiornato, poi riprova.');
 const n=U32(a,58);if(62+n>a.length)fail('Impostazioni troncate.');if(fmt===24)BloomyMetadata.parse(a);else if(62+n!==a.length)fail('Impostazioni non valide.');
 const tracks=unzip(a.subarray(62,62+n),13*TRACK),first=m.objects[base+1];
 if(!first||first.length<16||U32(first,0)!==2||U32(first,4)!==RAW)fail('Struttura dei pattern non supportata.');
 const plen=U32(first,12);if(plen<1||plen>23004)fail('Lunghezza pattern non valida.');const parts=[first.subarray(16)];
 for(let k=2;k<7;k++){const b=m.objects[base+k];if(!b||b.length<4||U32(b,0)!==2)fail('Archivio pattern incompleto.');parts.push(b.subarray(4))}
 const packed=cat(parts);if(packed.length!==plen)fail('Dimensione archivio pattern incoerente.');const raw=unzip(packed,RAW);if(Five.crc(raw)!==U32(first,8))fail('CRC dei pattern errato.');
 if(raw[SONG]>64||raw[SONG+1]>1)fail('Song non valida.');
 for(let t=0;t<10;t++)for(let p=0;p<8;p++){const o=t*TRACKPAT+p*TPAT;if(raw[o+768]<1||raw[o+768]>64||raw[o+769]>8)fail('Pattern fuori intervallo.');}
 const seen=new Set();for(let k=0;k<NLANE;k++){const o=LANE+k*70;if(!raw[o])continue;const t=raw[o+2],p=raw[o+3],par=U16(raw,o+4);if(t>=13||(p>=8&&!(t<8&&p===255&&par===0xfff9))||!(par<PARAMS||(par>=0xff00&&par<0xff10)||[0xfff9,0xfffa,0xfffb,0xfffd,0xfffe].includes(par)))fail('Automazione non valida.');const id=t+':'+p+':'+par;if(seen.has(id))fail('Automazione duplicata.');seen.add(id);}
 return {base,a,fmt,tracks,raw,tempo:U16(a,20)/10};
}
const engines=['Knit','Rayon','Jacquard','Bellows','Cane','Voile','Sample','Slice','Kit','MIDI','Tweed'];
function info(m,slot){const d=decode(m,slot);return {tempo:d.tempo,title:d.fmt===24?BloomyMetadata.parse(d.a).title:'',tracks:Array.from({length:8},(_,t)=>({track:t+1,engine:engines[d.tracks[t*TRACK]]||'?',name:new TextDecoder().decode(d.tracks.subarray(t*TRACK+341,t*TRACK+353)).split('\0')[0]})),songSections:d.raw[SONG]};}
function lanes(d,t){const rows=[];for(let k=0;k<NLANE;k++){const o=LANE+k*70;if(d.raw[o]&&d.raw[o+2]===t)rows.push(d.raw.slice(o,o+70))}return rows;}
function songMap(a,b,at,bt){
 const x=a.raw,y=b.raw,map=new Map(),alen=x[SONG],blen=y[SONG];
 if(alen!==blen||x[SONG+1]!==y[SONG+1])fail('Song diverse: numero di sezioni o modalità loop non corrispondenti. Le scene del progetto base restano da conservare: disattiva “Copia le assegnazioni nelle scene”, oppure allinea prima le due Song.');
 const put=(dest,src)=>{if(dest>=32||src>=32||!x[SCENE+dest*26+10]||!y[SCENE+src*26+10])fail('La Song richiama una scena mancante.');const so=SCENE+src*26,signature=y[so+bt]+':'+((U16(y,so+12)>>>bt)&1)+':'+kitMute(b,bt,src);const old=map.get(dest);if(old&&old.signature!==signature)fail('La scena '+(dest+1)+' del progetto base è riutilizzata in sezioni che richiedono pattern o mute diversi. Duplica quella scena prima del trasferimento.');map.set(dest,{src,signature});};
 if(alen){for(let i=0;i<alen;i++){const o=SONG+4+i*2;if(x[o+1]!==y[o+1])fail('Song diverse: la sezione '+(i+1)+' ha una durata differente. Nessun progetto è stato modificato.');put(x[o],y[o]);}}
 else{for(let s=0;s<32;s++){const aa=!!x[SCENE+s*26+10],bb=!!y[SCENE+s*26+10];if(aa!==bb)fail('Progetti senza Song: le scene presenti non corrispondono. Disattiva la copia delle assegnazioni.');if(aa)put(s,s);}}
 return map;
}
function kitRank(d,t){let n=0;for(let i=0;i<t;i++)if(d.tracks[i*TRACK]===8)n++;return n;}
function kitMute(d,t,s){return d.tracks[t*TRACK]===8&&kitRank(d,t)<4?U16(d.raw,SCENE+s*26+18+kitRank(d,t)*2):0;}
function sampleRefs(d,t){
 const par=d.tracks.subarray(t*TRACK,t*TRACK+341),refs=new Set(),ls=lanes(d,t),add=v=>{if(v!==255)refs.add(v)};let e=par[0];
 const locked=p=>ls.filter(l=>U16(l,4)===p).flatMap(l=>Array.from(l.subarray(6)).filter(v=>v!==255));
 const types=new Set([e,...locked(0)]);if(types.has(6)||types.has(7)){add(par[1]);locked(1).forEach(add);}
 if(types.has(8))for(let k=0;k<11;k++){const o=52+k*20;const models=new Set([par[o],...locked(o)]);if(models.has(10)||models.has(22)){add(par[o+1]);locked(o+1).forEach(add);}}
 return [...refs];
}
function checkSamples(source,destination,refs){
 if(!refs.length)return;
 if(!source.bank||!destination.bank)fail('La traccia usa campioni. Esporta entrambi i progetti includendo il banco campioni: il trasferimento non sostituisce il banco della destinazione.');
 const s=Five.entries(source.bank),d=Five.entries(destination.bank);
 for(const k of refs){if(!s[k]||!d[k]||!['meta','adp','ck'].every(p=>eq(s[k][p],d[k][p])))fail('Il campione '+(k+1)+' non coincide nei due progetti. Trasferimento bloccato per conservare i suoni delle altre tracce.');}
}
function merge(destination,source,{destinationSlot=1,sourceSlot=1,destinationTrack=2,sourceTrack=2,scenes=true}={}){
 if(![destinationTrack,sourceTrack].every(t=>Number.isInteger(t)&&t>=1&&t<=8))fail('Scegli due tracce da 1 a 8.');
 const a=decode(destination,destinationSlot),b=decode(source,sourceSlot),dt=destinationTrack-1,st=sourceTrack-1;
 const destKit=a.tracks[dt*TRACK]===8,srcKit=b.tracks[st*TRACK]===8;
 if(destKit!==srcKit)fail('Per conservare i mute dei kit, scegli due tracce entrambe melodiche oppure entrambe Kit.');
 for(const l of lanes(b,st))if(U16(l,4)===0&&Array.from(l.subarray(6)).some(v=>v!==255&&((v===8)!==srcKit)))fail('Automazioni che passano fra Kit e traccia melodica non sono supportate da questo trasferimento.');
 const map=scenes?songMap(a,b,dt,st):new Map(),refs=sampleRefs(b,st);checkSamples(source,destination,refs);
 const tr=a.tracks.slice(),raw=a.raw.slice();tr.set(b.tracks.subarray(st*TRACK,(st+1)*TRACK),dt*TRACK);
 // A self-weave follows the moved track. External dependencies remain on destination counterparts.
 if(tr[dt*TRACK+353]===st+1)tr[dt*TRACK+353]=dt+1;
 raw.set(b.raw.subarray(st*TRACKPAT,(st+1)*TRACKPAT),dt*TRACKPAT);
 const free=[],owned=[];for(let k=0;k<NLANE;k++){const o=LANE+k*70;if(!raw[o]||raw[o+2]===dt)free.push(k);if(raw[o]&&raw[o+2]===dt)owned.push(k);}
 const incoming=lanes(b,st);if(incoming.length>free.length)fail('Automazioni insufficienti: servono '+incoming.length+' corsie, disponibili '+free.length+'. Nessuna corsia di altre tracce è stata rimossa.');
 for(const k of owned)raw.fill(0,LANE+k*70,LANE+(k+1)*70);
 incoming.forEach((l,i)=>{const o=LANE+free[i]*70;raw.set(l,o);raw[o+2]=dt;});
 for(const [d,{src}]of map){const o=SCENE+d*26,so=SCENE+src*26;raw[o+dt]=b.raw[so+st];W16(raw,o+12,(U16(raw,o+12)&~(1<<dt))|(((U16(b.raw,so+12)>>>st)&1)<<dt));if(destKit){const rank=kitRank(a,dt),mask=kitMute(b,st,src);if(rank>=4&&mask)fail('Questo kit non può conservare i mute dei singoli suoni nella posizione scelta.');if(rank<4)W16(raw,o+18+rank*2,mask);}}
 const packed=zip(tr);if(62+packed.length+(a.a.length-62-U32(a.a,58))>3840)fail('Impostazioni troppo grandi per uno slot.');const settings=cat([a.a.subarray(0,62),packed,a.a.subarray(62+U32(a.a,58))]);W32(settings,58,packed.length);
 const stream=zip(raw);if(stream.length>23004)fail('Il progetto risultante supera la memoria disponibile per i pattern.');const objects=Object.fromEntries(Object.entries(destination.objects).map(([id,v])=>[id,v.slice()]));objects[a.base]=settings;
 let pos=0;for(let k=1;k<7;k++){const hdr=k===1?16:4,n=Math.min(3840-hdr,stream.length-pos),part=new Uint8Array(hdr+n);W32(part,0,2);if(k===1){W32(part,4,RAW);W32(part,8,Five.crc(raw));W32(part,12,stream.length);}part.set(stream.subarray(pos,pos+n),hdr);pos+=n;objects[a.base+k]=part;}
 if(pos!==stream.length)fail('Il progetto risultante supera lo spazio disponibile per i pattern. Nessun dato originale è stato modificato.');
 const model=Bloomy.validate({slots:destination.slots,objects,bank:destination.bank?destination.bank.slice():null}),check=decode(model,destinationSlot);
 if(!eq(check.raw,raw)||!eq(check.tracks,tr))fail('La verifica del progetto esportato non coincide.');
 for(let t=0;t<13;t++)if(t!==dt&&!eq(a.tracks.subarray(t*TRACK,(t+1)*TRACK),check.tracks.subarray(t*TRACK,(t+1)*TRACK)))fail('Verifica di conservazione del suono fallita.');
 for(let t=0;t<10;t++)if(t!==dt&&!eq(a.raw.subarray(t*TRACKPAT,(t+1)*TRACKPAT),raw.subarray(t*TRACKPAT,(t+1)*TRACKPAT)))fail('Verifica di conservazione pattern fallita.');
 for(let k=0;k<NLANE;k++){const o=LANE+k*70;if(a.raw[o]&&a.raw[o+2]!==dt&&!eq(a.raw.subarray(o,o+70),raw.subarray(o,o+70)))fail('Verifica di conservazione automazioni fallita.');}
 if(!eq(a.a.subarray(0,58),settings.subarray(0,58))||!eq(a.a.subarray(62+U32(a.a,58)),settings.subarray(62+packed.length)))fail('Titolo, note o impostazioni globali sono cambiati.');
 for(let scene=0;scene<32;scene++){const o=SCENE+scene*26;
  for(let t=0;t<10;t++)if(t!==dt&&a.raw[o+t]!==raw[o+t])fail('Verifica pattern delle altre scene fallita.');
  if(((U16(a.raw,o+12)^U16(raw,o+12))&~(1<<dt))||!eq(a.raw.subarray(o+10,o+12),raw.subarray(o+10,o+12))||!eq(a.raw.subarray(o+14,o+18),raw.subarray(o+14,o+18)))fail('Verifica impostazioni delle altre scene fallita.');
  for(let k=0;k<4;k++)if(!(destKit&&map.has(scene)&&k===kitRank(a,dt))&&U16(a.raw,o+18+k*2)!==U16(raw,o+18+k*2))fail('Verifica mute degli altri kit fallita.');
 }
 if(!eq(a.raw.subarray(SONG),raw.subarray(SONG))||!eq(a.raw.subarray(62080,LANE),raw.subarray(62080,LANE)))fail('La struttura Song o Weave è cambiata.');
 const warnings=[];if(tr[dt*TRACK+50])warnings.push('La traccia segue il Conductor del progetto base.');if(tr[dt*TRACK+353])warnings.push('Weave collegata: usa le tracce presenti nel progetto base.');if(a.tempo!==b.tempo)warnings.push('La sorgente verrà eseguita al tempo del progetto base ('+a.tempo+' BPM).');
 return {model,summary:{destinationTrack,sourceTrack,tempo:a.tempo,sourceTempo:b.tempo,patterns:8,automationLanes:incoming.length,sceneAssignments:map.size,samples:refs.length,warnings,masterEffects:'conservati dal progetto base'}};
}
return {decode,info,merge,zip,unzip};})();
