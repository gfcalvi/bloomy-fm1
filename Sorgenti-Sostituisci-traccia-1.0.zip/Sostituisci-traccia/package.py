from pathlib import Path
import base64,json,re,hashlib,zipfile,shutil
P=Path(__file__).resolve().parent;R=P.parents[1];old=R/'Strumenti/Bloomy-Offline-2.1.2';D=R/'Strumenti/Bloomy-Tools-2.2.0';D.mkdir(exist_ok=True)
html=(old/'index.html').read_text();match=re.search(r'const PAGES=(\{.*?\});\s*const titles=',html,re.S);assert match
pages=json.loads(match[1]);assert len(pages)==7;pages['track']=base64.b64encode((P/'Sostituisci-traccia.html').read_bytes()).decode();html=html[:match.start(1)]+json.dumps(pages,separators=(',',':'))+html[match.end(1):]
html=html.replace('const titles={','const titles={track:"Sostituisci traccia",',1)
html=html.replace('</nav>','<button role="tab" data-tab="track" aria-selected="false">Sostituisci traccia</button></nav>',1)
html=html.replace('2.1.2','2.2.0').replace('sette sezioni','otto sezioni')
html=re.sub(r'<p><b>Novità tools 2\.2\.0:</b>.*?</p>','',html)
html=html.replace('<h2>Mac e iPhone</h2>','<p><b>Novità tools 2.2.0:</b> Sostituisci una traccia prendendola da un altro salvataggio, conservando le altre tracce e le impostazioni del tuo brano. Funziona anche offline; non richiede un nuovo firmware. <a href="Sorgenti-Sostituisci-traccia-1.0.zip">Sorgenti della nuova funzione</a>.</p><h2>Mac e iPhone</h2>',1)
html=html.replace('</ul>','<li><b>Sostituisci traccia</b>: suono, pattern, automazioni e assegnazioni della traccia nelle scene; gli altri strumenti e gli effetti master rimangono quelli del progetto base.</li></ul>',1)
html=html.replace('Bloomy-Offline-2.2.0.zip','Bloomy-Tools-2.2.0.zip').replace('Pacchetto offline completo','Pacchetto offline tools')
(D/'index.html').write_text(html);(D/'Bloomy.html').write_text(html);shutil.copy2(P/'Sostituisci-traccia.html',D/'Sostituisci-traccia.html')
for name in ['Bloomy-1.2.0.fwsc','Bloomy-1.2.0.rfm1','LICENZE.txt','LICENSE-firmware.txt','LICENSE-MPL-2.0.txt','LICENSE-LAME.txt','LICENSE-LZFSE.txt']:
 shutil.copy2(old/name,D/name)
for file,tab in {'Carica-brano.html':'load','Salva-brano.html':'save','Backup.html':'backup','Backup-diretto.html':'backup','Convertitore.html':'convert','Convertitore-diretto.html':'convert','Progetti.html':'projects','Progetti-diretti.html':'projects','Installazione.html':'install','Installazione-diretta.html':'install','Esporta-audio.html':'wav','Esporta-WAV.html':'wav'}.items():
 (D/file).write_text('<!doctype html><meta charset="utf-8"><script>location.replace("index.html#'+tab+'")</script><a href="index.html#'+tab+'">Apri i tools Bloomy</a>')
readme='''# Bloomy Tools 2.2.0

https://gfcalvi.github.io/bloomy-fm1/

Firmware1.2.0 invariato. La novità è **Sostituisci traccia**.

## Sostituire il basso della propria r7 con quello della r10

1. Salva/esporta il tuo progetto modificato con Salva brano.
2. Apri Sostituisci traccia: a sinistra scegli **la tua r7 modificata**, a destra la r10.
3. Scegli T2 in entrambe le colonne. Lascia attiva **Copia anche le assegnazioni nelle scene**: serve al ciclo XXX2XXX1.
4. Premi Crea progetto con traccia sostituita, poi Salva .bloomyproject (o Condividi/Salva su File su iOS).
5. Usa Carica brano per inserire il nuovo progetto nello slot desiderato.

Le altre tracce, titolo/note, tempo, Song, Conductor, Weave globale, libreria e banco campioni restano quelli del progetto base. Suono, otto pattern, automazioni, Turing/Evolver e pattern/mute nelle scene della traccia scelta arrivano dalla sorgente. Gli effetti master restano quelli del progetto base: le mandate importate usano quegli effetti.

Le Song devono avere sezioni corrispondenti per numero e durata; i numeri delle scene possono differire. Una scena riutilizzata con assegnazioni sorgente in conflitto viene bloccata. Si può scegliere di mantenere le assegnazioni delle scene del progetto base, disattivando la casella. Due progetti senza Song devono avere le stesse scene presenti.

Per conservare i mute dei kit sono ammessi trasferimenti melodica→melodica o Kit→Kit. Campioni usati dalla traccia devono coincidere nei banchi dei due progetti; nessun banco viene sostituito. Formati progetto23/24 qualificati; per file più vecchi aprire/salvare prima con Bloomy aggiornato.

## Mac, iPhone/iPad e offline

Mac: apri il sito con Chrome/Edge. Il pacchetto ZIP contiene anche index.html con tutti gli otto strumenti incorporati: puoi aprirlo con Chrome senza server locale. I file personali vengono elaborati sul dispositivo.

iPhone/iPad: apri il sito in MIDIWeb Browser e usa **Make Available Offline**. Dopo l’aggiornamento sostituisci la copia offline e verifica **Strumenti2.2.0**. Questa procedura non richiede un Mac acceso. L’apertura diretta file:// da Files in MIDIWeb Browser dipende dall’app e non è il percorso consigliato.

La pagina Sostituisci-traccia.html è autonoma e funziona anche salvata offline. Non usa Web MIDI e non scrive sull’FM-1. Non carica file su server e non richiede login.

Manuale PDF edizione16 ed emulatore sono download separati, non inclusi nel pacchetto tools compatto. La guida della nuova funzione è questa; il PDF precedente non è stato modificato. Tutte le istruzioni di installazione degli strumenti precedenti restano valide.
'''
(D/'README.md').write_text(readme);(P/'GUIDA.md').write_text(readme)
m=json.loads((old/'MANIFEST.json').read_text());m['tools_revision']='2.2.0';m['sections'].append('track');m['track_transfer']={'version':'1.0','file_only':True,'preserves_other_tracks':True,'scene_mapping':'Song slot/duration; conflicting reused scenes rejected','qualified_project_formats':[23,24],'hardware_firmware_unchanged':True};m['offline_package']='Bloomy-Tools-2.2.0.zip';(D/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
verification=(old/'VERIFICA-STRUMENTI.md').read_text()+'\n\n## Tools2.2.0 · Sostituisci traccia1.0\n\n18 verifiche su dati reali e casi di errore; 8 test browser PASS, inclusi viewport390px, stato errori, file RemoteFM1 senza crypto.subtle. Progetto combinato caricato nel simulatore nativo: parametri modificati della destinazione e basso sorgente verificati, Song completa/stop automatico, guard0 e coda eventi mai piena. Nota grafica footer Song del simulatore già nota. Test hardware/iOS fisico non eseguiti dall’agente.\n'
(D/'VERIFICA-STRUMENTI.md').write_text(verification)
with zipfile.ZipFile(D/'Sorgenti-Sostituisci-traccia-1.0.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in ['track-transfer.js','page.html','page.js','build.py','package.py','test.mjs','test-native.xy','GUIDA.md']:
  z.write(P/name,'Sostituisci-traccia/'+name)
 for path in ['Sviluppo/Shimmer/tools/codec.js','Sviluppo/Titolo-1.1.1/metadata-final.js','Sviluppo/Titolo-1.1.1/slot-transfer.js','Sviluppo/Export-WAV/picker.js','Sviluppo/Export-WAV/dependencies/decoder.b64']:
  z.write(R/path,'dependencies/'+Path(path).name)
 z.write(old/'LICENSE-MPL-2.0.txt','LICENSE-MPL-2.0.txt')
 z.write(old/'LICENSE-LZFSE.txt','LICENSE-LZFSE.txt')
# Compact, fully self-contained eight-tool hub. Emulator and PDF remain separate downloads.
include=[p for p in D.iterdir() if p.is_file() and p.suffix!='.zip' and p.name not in ['SHA256SUMS','Bloomy.html']]
with zipfile.ZipFile(D/'Bloomy-Tools-2.2.0.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in include:z.write(f,'Bloomy-Tools-2.2.0/'+f.name)
 z.writestr('Bloomy-Tools-2.2.0/Bloomy.html','<!doctype html><meta charset="utf-8"><script>location.replace("index.html")</script><a href="index.html">Bloomy</a>')
public=['index.html','Bloomy.html','Sostituisci-traccia.html','Bloomy-Tools-2.2.0.zip','Sorgenti-Sostituisci-traccia-1.0.zip','README.md','MANIFEST.json','VERIFICA-STRUMENTI.md']
sums={line.split('  ',1)[1]:line.split('  ',1)[0] for line in (old/'SHA256SUMS').read_text().splitlines() if '  ' in line}
sums.pop('SHA256SUMS',None)
for name in public:sums[name]=hashlib.sha256((D/name).read_bytes()).hexdigest()
(D/'SHA256SUMS').write_text(''.join(v+'  '+k+'\n' for k,v in sorted(sums.items())));public.append('SHA256SUMS')
for zfile in ['Bloomy-Tools-2.2.0.zip','Sorgenti-Sostituisci-traccia-1.0.zip']:
 with zipfile.ZipFile(D/zfile) as z:assert z.testzip() is None
(P/'PUBLICATION-FILES.json').write_text(json.dumps([{'path':n,'local':str((D/n).resolve()),'bytes':(D/n).stat().st_size,'sha256':hashlib.sha256((D/n).read_bytes()).hexdigest()} for n in public],indent=2)+'\n')
(P/'index.html').write_text(html)
print('Ready',len(public),'public files; hub',len(html),'bytes; tools ZIP', (D/'Bloomy-Tools-2.2.0.zip').stat().st_size,'bytes')
