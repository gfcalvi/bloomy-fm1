/* MPL-2.0. Bloomy: merge one saved project into a freshly read device archive.
 * Uses the existing journalled all-object restore; untouched objects are byte-preserved.
 * It never writes a sample bank or replaces the shared preset library. */
globalThis.SlotTransfer=(()=>{
'use strict';
const eq=(a,b)=>a===b||(!a?.length&&!b?.length)||!!a&&!!b&&a.length===b.length&&a.every((v,i)=>v===b[i]);
const u32=(b,p)=>new DataView(b.buffer,b.byteOffset,b.byteLength).getUint32(p,true);
function slot(s){if(!Number.isInteger(s)||s<1||s>5)throw Error('Scegli uno slot da 1 a 5.');return Five.base(s)}
function settings(a){
 if(!a||a.length<62||u32(a,0)!==0x384d4f4c||![21,22,23,24].includes(u32(a,4)))throw Error('Impostazioni progetto incomplete o non supportate.');
 if(u32(a,4)===24)BloomyMetadata.parse(a);
 const n=u32(a,58);if(n<1||(u32(a,4)===24?62+n+4+a[62+n+2]!==a.length:n!==a.length-62))throw Error('Impostazioni compresse non valide.');
 const compressedEnd=62+n;let src=62,pos=0;const out=new Uint8Array(13*357);
 while(src<compressedEnd){const c=a[src++];if(c<128){const n=c+1;if(src+n>compressedEnd||pos+n>out.length)throw Error('Progetto troncato.');out.set(a.subarray(src,src+n),pos);src+=n;pos+=n;}else{const n=(c&127)+3;if(src+2>compressedEnd)throw Error('Progetto troncato.');const d=a[src]+256*a[src+1]+1;src+=2;if(d>pos||pos+n>out.length)throw Error('Compressione progetto non valida.');for(let i=0;i<n;i++){out[pos]=out[pos-d];pos++;}}}
 if(pos!==out.length)throw Error('Dimensione dei parametri progetto non valida.');
 const refs=new Set();for(let t=0;t<8;t++){const p=out.subarray(t*357,t*357+341),e=p[0];if(e===6||e===7)refs.add(p[1]);if(e===8)for(let k=0;k<11;k++){const o=52+k*20;if(p[o]===10||p[o]===22)refs.add(p[o+1]);}}
 return {tempo:new DataView(a.buffer,a.byteOffset,a.byteLength).getUint16(20,true)/10,format:u32(a,4),samples:[...refs].sort((a,b)=>a-b)};
}
function info(m,s){const id=slot(s),a=m.objects[id];return a?.length?{slot:s,empty:false,...settings(a)}:{slot:s,empty:true}}
function sample(b,k){const o=64+k*40,n=u32(b,o+20),adp=u32(b,o+12),ck=u32(b,o+16),blk=new DataView(b.buffer,b.byteOffset,b.byteLength).getUint16(4,true)===2?64:128;return {meta:b.slice(o+20,o+40),adpcm:b.slice(adp,adp+Math.ceil(n/2)),checkpoints:b.slice(ck,ck+Math.ceil(n/blk)*4)}}
function compatibleBank(source,device,refs=[]){
 if(device)Bloomy.checkBank(device);if(source)Bloomy.checkBank(source);
 const n=device?device[6]:0;
 if(refs.some(k=>k>=n))throw Error('Il progetto richiede campioni non presenti sull’FM-1. Carica prima un progetto con campioni compatibili. Il banco del dispositivo non verrà sostituito.');
 if(!source||!source[6])return {missing:!source,kept:true};
 if(!device||source[6]>device[6])throw Error('Banco campioni incompatibile: mancano campioni sul dispositivo. Nessun dato è stato scritto.');
 // Every source index must retain the same data and playback metadata. Extra device samples are fine.
 for(let k=0;k<source[6];k++){const a=sample(source,k),b=sample(device,k);if(!eq(a.meta,b.meta)||!eq(a.adpcm,b.adpcm)||!eq(a.checkpoints,b.checkpoints))throw Error('Banco campioni incompatibile allo slot campione '+(k+1)+'. Caricamento bloccato per conservare gli altri brani.');}
 return {missing:false,kept:true};
}
function merge(device,incoming,source,destination){
 Bloomy.validate(device);Bloomy.validate(incoming);if(destination>device.slots||source>incoming.slots)throw Error('Slot fuori dal formato sorgente o destinazione.');const from=slot(source),to=slot(destination),summary=info(incoming,source);
 if(summary.empty)throw Error('Lo slot sorgente è vuoto.');
 for(let i=0;i<7;i++)if(!incoming.objects[from+i]?.length)throw Error('Il progetto sorgente è incompleto.');
 const bank=compatibleBank(incoming.bank,device.bank,summary.samples);
 const objects=Object.fromEntries(Object.entries(device.objects).map(([k,v])=>[k,new Uint8Array(v)]));
 for(let i=0;i<7;i++)objects[to+i]=new Uint8Array(incoming.objects[from+i]);
 const model=Bloomy.validate({slots:device.slots,objects,bank:device.bank?new Uint8Array(device.bank):null}),image=Bloomy.loomWrite({slots:device.slots,objects,bank:null});
 for(const id of Five.ids(device.slots))if(id<to||id>=to+7)if(!eq(device.objects[id],model.objects[id]))throw Error('Verifica di conservazione fallita.');
 return {model,image,source,destination,summary,bank,libraryDiffers:!eq(device.objects[1],incoming.objects[1]),preserved:Array.from({length:device.slots},(_,i)=>i+1).filter(s=>s!==destination)};
}
function sameArchive(a,b){if(a.slots!==b.slots)return false;for(const id of Five.ids(a.slots))if(!eq(a.objects[id],b.objects[id]))return false;return eq(a.bank,b.bank)}
function verify(expected,actual){if(!sameArchive(expected,actual))throw Error('La scrittura è stata accettata, ma la rilettura non corrisponde. Conserva il backup e rileggi il dispositivo prima di riprovare.');return true}
async function readFile(bytes,decoder){
 if(bytes.length>3*1048576)throw Error('File troppo grande (massimo 3 MiB).');
 const first=new TextDecoder().decode(bytes.subarray(0,80)).replace(/^\uFEFF/,'').trimStart();
 if(first.startsWith('{')){let p;try{p=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes))}catch(e){throw Error('File JSON non valido.');}if(p?.format==='bloomy-project'){const m=Picker.read(bytes);if(m.empty)throw Error('Il file progetto è vuoto.');info(m,1);return {...m,sourceName:m.name||'Progetto',sourceSlots:[1]}}}
 const m=await Bloomy.read(bytes,decoder);if(!m.projects.length)throw Error('Il file non contiene progetti salvati.');for(const s of m.projects)info(m,s);return {...m,sourceSlots:[...m.projects]};
}
return {eq,info,settings,compatibleBank,merge,sameArchive,verify,readFile};})();
