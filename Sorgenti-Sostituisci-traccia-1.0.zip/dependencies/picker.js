globalThis.Picker=(()=>{
const E=new TextEncoder(),D=new TextDecoder('utf-8',{fatal:true});
const equal=(a,b)=>a===b||!!a&&!!b&&a.length===b.length&&a.every((v,i)=>v===b[i]);
function extract(bytes,slot,name='Progetto'){
 if(!Number.isInteger(slot)||slot<1||slot>5)throw Error('Slot non valido.');
 const m=Bloomy.loomRead(bytes), objects={};
 if(m.objects[1])objects[1]=m.objects[1];
 for(let i=0;i<7;i++){const b=m.objects[Five.base(slot)+i];if(b)objects[2+i]=b;}
 return E.encode(JSON.stringify({format:'bloomy-project',version:1,name:String(name).slice(0,120),sourceSlot:slot,backup:Bloomy.b64(Bloomy.loomWrite({objects,bank:m.bank?Five.bankto(m.bank,m.slots,3):null,slots:3}))}));
}
function read(bytes){
 if(bytes.length>600000)throw Error('File progetto troppo grande.');
 const p=JSON.parse(D.decode(bytes));
 if(p.format!=='bloomy-project'||p.version!==1||typeof p.name!=='string'||p.name.length>120)throw Error('Formato progetto non riconosciuto.');
 const m=Bloomy.loomRead(Bloomy.un64(p.backup));
 if(m.projects.some(s=>s!==1))throw Error('Il file singolo contiene più slot.');
 return {...m,name:p.name,empty:!m.projects.length};
}
function compose(projects,library=null,acceptLibrary=false){
 if(projects.length!==5||!projects.some(Boolean))throw Error('Carica almeno un file progetto.');
 if(library===null)library=projects.findIndex(Boolean);
 if(!Number.isInteger(library)||library<0||library>4||!projects[library])throw Error('Libreria non valida.');
 for(const p of projects)if(p)Bloomy.validate(p);
 const active=projects.filter(p=>p&&!p.empty), bank=(active[0]||projects.find(Boolean)).bank;
 if(active.some(p=>!equal(p.bank,bank)))throw Error('Banchi campioni diversi (o assenti): impossibile unire senza rimappare i campioni. Usa progetti con lo stesso banco LSMP.');
 const presets=projects[library].objects[1];
 if(active.some(p=>!equal(p.objects[1],presets))&&!acceptLibrary)throw Error('Librerie preset/kit diverse: scegli quale conservare e conferma la sostituzione della libreria condivisa.');
 const objects={};if(presets)objects[1]=presets;
 projects.forEach((p,s)=>{if(!p)return;for(let i=0;i<7;i++)if(p.objects[2+i])objects[Five.base(s+1)+i]=p.objects[2+i];});
 const bytes=Bloomy.loomWrite({objects,bank:bank?Five.bankto(bank,3,5):null,slots:5});Bloomy.loomRead(bytes);return bytes;
}
return {extract,read,compose,equal};})();