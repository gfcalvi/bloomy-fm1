# Blue Edition r9.6 - 0.9.6-blue96

Turing indipendente monofonica per ogni traccia non drum,16celle max. SEQ/Turing: bianco14Freeze, bianco15Capture, bianco16On/Off; bianchi1-3banchi. Capture durante PLAY si applica al confine del giro e sovrascrive il pattern attivo (e le sue lane), mantenendo Freeze. Nessuno Stop imposto. Timbro/mix/LFO e gli altri pattern sono conservati.

Formato progetto23, preset/kit14; legge9.5 ma i nuovi progetti non vanno riaperti con9.5. Usare il suo backup originale per rollback.16voci, buffer e riserva pool invariati. Hardware/iPad non provati.

Build ./build.sh --release 0.9.6-blue96; web ./build.sh --release 0.9.6-blue96 --web, poi python3 tools/pin_browser.py per aggiornare i pin SHA256 dell'emulatore. Sorgenti rfm1 e adattatore isolato nel pacchetto RemoteFM1. I log e le identita autorevoli sono in Ripartenza-r9.6.
