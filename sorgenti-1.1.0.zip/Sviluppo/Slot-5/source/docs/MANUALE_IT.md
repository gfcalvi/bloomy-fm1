# LOOM-8 Blue
## Manuale utente in italiano
Firmware 0.9.3-blue9 • Revisione r9 • 30 ottobre 2026

Guida operativa con esempi, procedure e riferimenti. Per la versione Blue del firmware LOOM-8 su hardware FM-1 e nel relativo emulatore browser.

Questa guida descrive il software incluso nel pacchetto r9. Le modifiche Blue sono state verificate mediante compilazione, emulazione e prove software; il comportamento sul dispositivo fisico richiede la verifica dell’utilizzatore. I nomi visualizzati sullo schermo restano in inglese: qui vengono spiegati in italiano.

---
# 1. Orientarsi e iniziare
LOOM-8 combina otto tracce, un sequencer a step, strumenti di sintesi e campionamento, effetti e strumenti per la performance. Una traccia contiene suono, impostazioni di esecuzione e otto pattern. Le scene richiamano combinazioni di pattern e mute; la Song dispone le scene in sequenza.

La Blue r9 conserva le funzioni precedenti e aggiunge divisioni musicali al delay, velocità puntate all’arpeggio, pan per step, un interruttore Ping-Pong e due LFO aggiuntivi per ogni traccia melodica compatibile. La r9 introduce inoltre il generatore Random/Euclidean e l’Evolver melodico, con protezione, Freeze, Reset e Capture.

## Comandi fondamentali
| Comando | Funzione pratica |
| --- | --- |
| ALGORITHM | Sceglie la traccia; nei menu modifica il valore della riga selezionata. |
| SELECT | Cambia pagina; nei menu seleziona la riga. |
| SEL | Apre azioni contestuali o conferma una scelta. |
| HOME | Torna indietro o apre Arrange; da Arrange permette di raggiungere Song. |
| PLAY | Avvia o ferma il sequencer. La partenza normale riparte dallo step 1. |
| SEQ | Apre Steps; ruotando SELECT scorre Bar, Generator ed Evolver sulle tracce compatibili. Tenuto premuto permette di preparare le note da inserire. |
| EDIT / ENV / FX / LFO / ARP / GLO | Apre il gruppo di parametri corrispondente. SELECT ne scorre le pagine. |
| REC | Registrazione a step da fermo; tenuto durante la riproduzione registra note o movimenti. |
| SAVE | Salva immediatamente il progetto corrente. |
| OCT − / OCT + | Cambia ottava nelle pagine sonore, pagina di step nel sequencer e banco di scene in Arrange. |

I quattro encoder sono chiamati Knob 1–4 da sinistra a destra. I tasti bianchi sono numerati 1–16, i neri 1–11, sempre da sinistra. Le loro funzioni cambiano con la pagina: leggere le etichette e il suggerimento nel footer. Una pressione lunga di circa un secondo sui comandi che prevedono aiuto mostra una scheda contestuale.

HOME + REC annulla l’ultima operazione; HOME + PLAY la ripristina. È disponibile un livello di annullamento: non sostituisce una copia di sicurezza.

## Primo avvio: un groove in pochi minuti
1. Aprire SEQ e scegliere T1 con ALGORITHM. In un nuovo progetto T1 è normalmente un kit.
2. Scegliere la cassa con il primo tasto nero e attivare gli step bianchi 1, 5, 9 e 13.
3. Scegliere il rullante con il secondo tasto nero e attivare 5 e 13. Il kit può contenere più strumenti sullo stesso step.
4. Scegliere il charleston con il terzo tasto nero e inserire gli step dispari.
5. Passare a T2. Tenere SEQ, suonare una nota, rilasciare SEQ e attivare alcuni step bianchi.
6. Premere PLAY, regolare i livelli in GLO e premere SAVE quando il risultato è pronto.

I suoni iniziali dei nuovi progetti possono cambiare: il firmware crea una combinazione di preset. Se il risultato non corrisponde al timbro desiderato, scegliere un preset dalla pagina dello strumento.

---
# 2. Progetti, tracce, pattern e scene
| Oggetto | Capacità e significato |
| --- | --- |
| Progetti | 3 slot interni. Contengono sequenze, suoni e impostazioni. |
| Tracce | 8 strumenti, ciascuno con il proprio ruolo e pattern. |
| Pattern | 8 per traccia, fino a 64 step ciascuno. |
| Step melodico | Fino a 4 note, con attributi e due slot per i trick. |
| Scene | 32 combinazioni di pattern, mute e contesto Conductor. |
| Preset sonori utente | 16 slot, distinti dai progetti e dai kit utente. |
| Kit utente | 8 slot per kit completi. |

Una scena conserva i riferimenti ai pattern: due scene possono suonare lo stesso pattern. Se si modifica quel pattern, cambiano entrambe. Per creare una variazione indipendente, copiare il pattern in uno slot vuoto e assegnarlo alla nuova scena.

I suoni delle tracce non sono fotografie separate per ogni scena. Cambiare il timbro di una traccia influenza le scene che usano quella traccia. Le scene sono particolarmente adatte a intro, strofa, ritornello e variazioni di arrangiamento.

## Salvataggio e compatibilità
SAVE salva subito. Il salvataggio automatico avviene dopo circa tre secondi senza modifiche, quando il trasporto è fermo e non c’è più audio: fermare il sequencer lasciando una coda lunga non significa avere già salvato.

Nelle pagine del sequencer, tenere SAVE e scegliere uno dei primi tre tasti bianchi per salvare in uno slot progetto; le destinazioni occupate richiedono conferma. Nelle pagine sonore, SAVE con i tasti bianchi può invece salvare un preset: controllare sempre il contesto prima di confermare.

Blue r9 usa il formato progetto 19 e importa i progetti precedenti supportati, compresi quelli Blue r5 e r6. Il formato 19 è condiviso con r7 e r8: i progetti restano leggibili da entrambe. La r6 e le versioni più vecchie non aprono il formato 19. Prima di aggiornare conservare una copia dei dati e del firmware precedente.

---
# 3. Scrivere e modificare i pattern
## Inserimento e attributi degli step
Nella pagina Steps, un tocco su un tasto bianco attiva o disattiva lo step. Per preparare una nota o un accordo, tenere SEQ, suonare i tasti, rilasciare SEQ e quindi inserire gli step. Il materiale preparato resta disponibile per i successivi inserimenti.

Tenere uno step per modificare i suoi attributi con i quattro knob: Velocity, Length, Chance e Pitch. Velocity controlla l’intensità; Length la durata; Chance la probabilità o condizione di esecuzione; Pitch l’altezza. Nei kit la velocity riguarda lo strumento selezionato.

Tenendo uno step e premendo un tasto successivo si può estendere la durata fino a quel punto. Per modificare più step, tenerli premuti insieme e girare il knob: le variazioni sono relative ai valori esistenti.

Tenere uno step e premere SEL per accedere alla gestione delle note, inclusa la rimozione della singola nota e la copia dello step. Tenere uno step e toccare SEQ attiva l’editing dell’accordo; toccare nuovamente SEQ per uscire.

## Lunghezza, Pace e groove
Senza step premuti, la pagina Steps offre Pattern, Length, Pace e Groove. Qui Pace indica la durata temporale di uno step, espressa rispetto ai sedicesimi: non è la scala musicale del Conductor.

Un pattern di 16 step con scala di un sedicesimo dura una battuta di 4/4. Lo stesso pattern con step più lunghi dura di più. Pattern di lunghezze differenti possono creare polimetrie fra le tracce.

OCT − e OCT + cambiano il gruppo di 16 step visualizzato. Visualizzare una pagina non imposta automaticamente un loop su quella pagina. Nella pagina Bar, tenere SEQ e usare i primi quattro tasti neri per scegliere le battute; tenere due estremi per delimitare un loop. Premere due volte lo stesso tasto per limitare il loop a una battuta.

Bar offre anche Quant per la registrazione, durata predefinita delle nuove note, Groove e Shape. Shape regola l’interpolazione dei movimenti registrati, non cambia la forma d’onda dell’oscillatore.

## Copia e trasformazioni
SEL apre le azioni del pattern: copia, incolla, cancellazione di note o lock, rotazione, trasposizione e raddoppio della lunghezza. COPY TO EMPTY trova un pattern vuoto, vi copia il contenuto e aggiorna il riferimento della scena corrente.

Esempio: creare la scena B partendo da A, selezionare la traccia del basso e usare COPY TO EMPTY. Aggiungere due note finali. La scena A mantiene il basso originale; B usa la variante. Ripetere sulle altre tracce soltanto quando serve una variazione indipendente.

---
# 4. Registrare note e automazioni
## Registrazione dal vivo
REC + PLAY avvia la registrazione dall’inizio del pattern, con count-in se impostato. Durante la riproduzione, tenere REC per registrare mentre si suona. REC + PLAY consente la registrazione agganciata; REC la interrompe.

Tenere REC da fermo o nelle pagine Steps/Bar per impostare Click, Count, Quant e Mode. Overdub aggiunge gli eventi al materiale presente. Replace cancella gli eventi degli step attraversati dalla testina e li sostituisce: scegliere consapevolmente questa modalità prima di registrare.

Usare la quantizzazione per una prima stesura precisa; ridurla quando si vogliono conservare anticipi e ritardi dell’esecuzione. Il groove modifica il carattere ritmico e va valutato insieme alla quantizzazione.

## Registrazione a step
Da fermo, toccare REC per entrare nello Step Record. Suonare una nota o un accordo e rilasciare i tasti per avanzare. OCT + inserisce una pausa; OCT − torna indietro. Premere REC per terminare.

## Motion recording e Parameter Lock
Per registrare un movimento, aprire la pagina del parametro, avviare il sequencer, tenere REC e girare il knob. Il pattern riproduce il movimento registrato. Questa modalità è utilizzabile anche con i nuovi LFO A e B.

Per un valore puntuale, tenere uno step, aprire EDIT, ENV, FX o LFO e girare il controllo desiderato. Il parametro appare evidenziato come lock; il simbolo «−» indica l’assenza di lock. Un lock vale dal trigger fino al successivo step eseguito che ne stabilisce un altro o ripristina il valore di base.

SEL insieme al movimento del knob cancella il lock selezionato; senza step tenuti può cancellare il movimento del parametro nel pattern. Controllare sempre la pagina e gli step selezionati. Le nuove pagine LFO A/B vanno automatizzate mediante REC; l’editing diretto con step tenuto resta limitato alle pagine LFO originali.

---
# 5. Pan per step: la funzione Blue
Il pan della traccia resta il centro di riferimento. Il nuovo attributo per step aggiunge un offset temporaneo nel momento in cui lo step viene suonato.

1. Aprire SEQ e tenere premuto lo step da modificare.
2. Premere GLO mantenendo lo step premuto.
3. Girare il Knob 3, indicato come PAN +/−.
4. Scegliere un valore da −63 a +63. Zero è neutro.
5. Rilasciare lo step e ascoltare la sequenza.

Un valore negativo sposta verso sinistra, uno positivo verso destra. Il risultato si somma al pan globale e alle altre modulazioni e viene limitato agli estremi disponibili. Il pan globale salvato non viene riscritto.

L’offset termina al successivo step effettivamente eseguito senza quell’offset oppure con Stop. Uno step saltato dalla probabilità non equivale necessariamente a un nuovo trigger. Le code già presenti sulla stessa traccia possono seguire lo spostamento: non è un pan separato per ogni voce polifonica.

Per togliere l’attributo, riportare il valore a zero oppure tenere SEL e girare Knob 3 sugli step selezionati. CLEAR LOCKS può non eliminarlo, perché il pan per step viene trattato come attributo della nota.

## Esempio: hi-hat alternato
Impostare il pan generale al centro. Su quattro step successivi assegnare −30, +30, −20 e +20. Usare valori moderati per un movimento leggibile anche con cuffie; controllare che riverbero e altre modulazioni non nascondano l’alternanza.

---
# 6. Strumenti e gestione del suono
EDIT apre le pagine del motore e delle modalità di esecuzione. PRESETS permette di scegliere i preset disponibili nel contesto corrente; SEL contiene la selezione del motore e le operazioni sul suono. Il firmware include 85 preset di fabbrica.

| Motore | Carattere e impiego suggerito |
| --- | --- |
| Knit | Oscillatori analogici virtuali: bassi, lead, pad e unisono. |
| Rayon | Sintesi FM a due operatori: timbri metallici, campane e tastiere. |
| Jacquard | Wavetable: scansioni timbriche, texture e suoni in evoluzione. |
| Bellows | Organo: registri, pedale e movimento del rotore. |
| Cane | Modelli fisici adatti a corde pizzicate e risonanze. |
| Voile | Modelli di voce e fiato, colori ariosi ed espressivi. |
| Sample | Riproduzione di campioni con inizio, lunghezza e modalità di lettura. |
| Slice | Riproduzione ritmica di porzioni di un campione. |
| Kit | Undici strumenti percussivi per traccia. |
| MIDI | Controllo di strumenti esterni e parametri MIDI. |

I knob principali dipendono dal motore. Nei nuovi LFO A/B le destinazioni mostrano direttamente i nomi dei quattro controlli del motore selezionato: per esempio Wave su Knit e Scan su Jacquard. La tabella completa è nel capitolo 26.

## Modalità di esecuzione
Poly permette note sovrapposte. Mono privilegia una nota alla volta. Legato permette transizioni fra note secondo il comportamento del motore. Le pagine Play comprendono anche portamento, pitch bend e volume; le pagine successive includono l’ottava.

In Knit, l’unisono può arrivare a sette voci per nota e aumenta il consumo di voci disponibili. Se accordi e code diventano irregolari, ridurre unisono, durata e sovrapposizione prima di aumentare la complessità della sequenza.

## Inviluppi e filtro
ENV comprende l’ADSR del suono, il filtro e l’inviluppo del filtro. Attack è il tempo di salita, Decay il passaggio al Sustain, Sustain il livello mantenuto, Release il rilascio dopo la nota.

Cutoff stabilisce la zona di intervento del filtro, Resonance ne enfatizza il bordo, Env regola l’azione dell’inviluppo e Keytrack collega il filtro all’altezza. PRESETS nella pagina del filtro seleziona il tipo disponibile.

Esempio per un basso breve: attacco rapido, sustain basso e decay corto; abbassare il cutoff e aumentare moderatamente l’inviluppo del filtro. Allungare poi la nota solo quanto serve a collegare il groove.

## Character
FX apre anche il carattere del suono: Off, Drive, Fold, Crush, Ring, Tilt, Tape e Sampler. I controlli comprendono tipo, quantità, tono e mix. Mix a zero elimina il contributo dell’effetto.

Character è distinto dai due effetti send. Sulle voci melodiche opera dopo il filtro; nei kit il carattere agisce sul bus, mentre le mandate percussive precedono questo trattamento. Un segnale inviato agli effetti può quindi avere un colore diverso dal segnale diretto.

---
# 7. Kit e percussioni
Una traccia Kit contiene undici strumenti richiamati dai tasti neri. Il layout iniziale comprende cassa, rullante, charleston chiuso e aperto, clap, tom e altre percussioni. Il modello può essere cambiato per ciascun tasto.

EDIT modifica i parametri del modello selezionato. Le pagine successive comprendono modello, casualizzazione, pan, volume e mandate. Nei pattern, tenere uno step e premere altri tasti neri per aggiungere o togliere strumenti su quello step.

Sono disponibili dieci kit di fabbrica: Loom, Nylon, Elastane, Wire, Burlap, Sequin, Frayed, Denim, Linen e Velvet; gli otto slot utente consentono di salvare kit personalizzati.

## Durata, filtro e choke
ENV comprende inviluppo del singolo suono, filtro del singolo suono e trattamento del kit. Con Decay disattivato, il modello può mantenere la propria durata naturale. Le pagine del kit comprendono anche attacco, ritardo e variazione della durata.

Nel menu SEL sono disponibili One-shot, Gated, Loop e gruppi Choke. Un choke interrompe un altro suono dello stesso gruppo: è utile per chiudere il charleston aperto quando parte quello chiuso. Il kit iniziale usa questo collegamento fra i due charleston.

Le mandate FX sono regolabili per singolo strumento del kit. Per un rullante con riverbero e cassa asciutta, selezionare ciascun suono e assegnare valori diversi nella pagina Sends.

Il salvataggio di un kit comprende i suoi suoni, inviluppi, filtri e impostazioni pertinenti. Mix, pan generale e impostazioni della traccia restano parte del contesto della traccia.

---
# 8. Campioni e slicing
Sample offre scelta del campione, punto iniziale, lunghezza e modalità One-shot, Loop, Reverse o Ping-pong. Quest’ultima riguarda la lettura avanti/indietro del campione ed è indipendente dal Ping-Pong del delay.

La Root Note identifica la nota alla quale il campione suona alla velocità originale. Salire di un’ottava raddoppia la velocità e dimezza la durata. Il campionatore non esegue un time-stretch indipendente dall’intonazione.

Nelle modalità cicliche la pagina Loop permette di definire il tratto ripetuto. Una lunghezza loop pari a zero usa le informazioni disponibili nel campione; il motore applica un breve crossfade alle giunzioni previste.

## Slice
Il motore Slice divide il materiale in 4, 8, 16 o 32 parti. Le note cromatiche consecutive selezionano le slice a partire dalla Root Note. Se la Root è F3 e si usano otto slice, la prima parte è F3 e le successive proseguono cromaticamente fino a C4.

Non trattare le note delle slice come una melodia da quantizzare: l’altezza del tasto è prima di tutto un indice. Per questo il passaggio a Slice disattiva normalmente il follow del Conductor.

Se si specifica il numero di battute del loop, da 1 a 16, la velocità si adatta al BPM mediante ricampionamento, con conseguente variazione di altezza. Senza questa indicazione, il materiale mantiene la propria velocità di riferimento.

Poly sovrappone le slice; Mono interrompe la precedente; Legato permette passaggi che conservano la posizione di lettura prevista. Gate e durata del materiale influenzano il risultato: una slice può continuare secondo il proprio gate anche con una nota breve.

## Caricare e organizzare i campioni
Il pacchetto browser comprende la pagina /samples/. Usare un browser compatibile con USB, come Chrome o Edge, collegare il dispositivo e scegliere Connect. Si possono aggiungere file, rinominare o sostituire gli slot, regolare Root Note e numero di battute, quindi inviare il banco.

Il banco codificato dispone di circa 214 KB e 32 slot utente. I campioni di fabbrica occupano parte dello spazio. Ridurre frequenza di campionamento e durata aiuta a inserire più materiale; non confondere la capienza totale con lo spazio libero dopo il caricamento della libreria di fabbrica.

Prima di sostituire il banco eseguire un backup. I pattern richiamano gli slot: sostituire il contenuto di uno slot cambia il suono dei progetti che lo usano. Se i campioni di fabbrica mancano, usare le azioni del gestore per aggiungere la libreria LOOM o i break.

---
# 9. Arpeggiatore e strum
ARP apre il player della traccia. La prima pagina comprende Player, Speed, Pattern e Range; le successive comprendono Length, Style, Glide, Stereo e Hold. Il player lavora anche sugli accordi degli step durante la loro durata.

| Divisioni disponibili per Speed | Significato |
| --- | --- |
| 1/4, 1/8, 1/16, 1/32, 1/64 | Suddivisioni regolari. |
| 1/4T, 1/8T, 1/16T, 1/32T | Terzine: durata pari a due terzi della divisione regolare. |
| 1/8D, 1/4D | Puntate: durata pari a una volta e mezza la divisione regolare. |

Nella Blue le due divisioni puntate sono in fondo all’elenco, dopo 1/64, per conservare la corrispondenza delle impostazioni precedenti. Continuare quindi a girare Speed oltre le divisioni più veloci per raggiungerle.

I disegni comprendono salita, discesa, rimbalzo e casuale; Range estende il materiale su più ottave. Length influenza l’articolazione; Glide collega le altezze; Stereo distribuisce il movimento secondo il player.

Strum costruisce un accordo a partire da una nota usando tonalità e scala globali. È anche possibile preparare un insieme di note e trasporlo. Hold mantiene il materiale del player fino alla successiva sostituzione: se sembra che una nota non finisca, controllare questa funzione.

## Esempio a 70 BPM
Un quarto dura circa 857,14 ms. 1/8D dura 642,86 ms e 1/4D dura 1.285,71 ms. Provare un accordo lungo almeno una battuta, Speed 1/8D e Pattern Up; passare poi a 1/4D per una scansione più lenta. La nota o l’accordo devono durare abbastanza da lasciare eseguire il player.

---
# 10. Delay musicale e Ping-Pong
Il delay della Blue è disponibile nel banco FX I. FX II usa la memoria del riverbero: non è un secondo banco delay indipendente. Per sentirlo, servono una mandata non nulla e un livello di ritorno FX attivo.

| Time | Durata rispetto a un quarto |
| --- | --- |
| 1/32 | 1/8 |
| 1/32D | 3/16 |
| 1/16 | 1/4 |
| 1/16D | 3/8 |
| 1/8 | 1/2 |
| 1/8D | 3/4 |
| 1/4 | 1 |
| 1/2 | 2 |

Time mostra la divisione musicale. Fine rifinisce la durata attorno a questa divisione: **50 è il valore neutro**. Lasciarlo a 50 conserva il tempo esatto selezionato. Non è un secondo ritardo che si aggiunge a Time. L’escursione è circa −25% / +24,6%.

La memoria consente circa 1.004,3 ms di ritardo. Se la durata richiesta, compreso Fine, supera questo valore, il firmware la dimezza ripetutamente fino a farla rientrare. La scritta Time continua a indicare la divisione scelta: un’impostazione lunga a BPM basso può quindi produrre una ripetizione più rapida di quanto suggerisce l’etichetta.

La linea delay lavora a 11.025 Hz; il segnale diretto conserva la frequenza audio di 44,1 kHz. Il ritorno ritardato risulta quindi più scuro e ha una banda utile di circa 5,5 kHz.

## Impostazione consigliata per 1/8D a 70 BPM
1. Aprire FX, selezionare il banco FX I e scegliere il delay.
2. Impostare il tempo generale a 70 BPM.
3. Portare Time a 1/8D e Fine a 50.
4. Alzare moderatamente la mandata della traccia e il ritorno FX I.
5. Regolare il feedback finché le ripetizioni hanno la lunghezza desiderata.

Il risultato è circa 642,86 ms, entro la memoria disponibile anche lungo l’escursione di Fine. Non occorre cambiare la durata degli step della traccia a 3/16 per ottenere questo intervallo.

Il delay non offre 1/4D nella lista Time: quella divisione è stata aggiunta all’arpeggiatore e agli LFO A/B. A 70 BPM richiederebbe circa 1.285,71 ms, oltre la memoria della linea delay.

## Interruttore Ping-Pong
Nella pagina grafica del delay il riquadro PING-PONG mostra On oppure Off. Premere il primo tasto nero (BLACK KEY 1) per commutarlo immediatamente, senza aprire SEL. I quattro knob restano Time, Fine, Repeats e Tone. L’impostazione viene salvata nel progetto. Il comando nel menu SEL rimane disponibile come percorso alternativo.

ON alterna il percorso del feedback fra sinistra e destra, conservando il comportamento stereo delle versioni Blue precedenti. OFF porta le ripetizioni al centro su entrambi i canali. Non si tratta di un’inversione della polarità elettrica del segnale. Il passaggio fra le modalità preserva la coda mediante una breve transizione del routing.

Per verificare l’effetto usare cuffie o due diffusori, un colpo isolato e abbastanza feedback da sentire almeno tre ripetizioni. Su una somma mono il movimento laterale scompare.

---
# 11. Riverbero, mandate e master
FX comprende Character, Sends, FX I, FX II e Throws. Le mandate alimentano gli effetti in parallelo al suono diretto. Un effetto non si sente se la mandata è a zero, il ritorno è abbassato o il banco è in mute.

Il menu SEL degli effetti comprende filtri passa-alto e passa-basso e la mandata da FX I a FX II. Questa connessione permette di riverberare le ripetizioni del delay. Usare valori contenuti: due code lunghe in cascata possono rendere il mix poco leggibile.

Il riverbero offre undici modalità, fra cui Plate, Room, Studio S/M/L, Hall e varianti Echo. PRESETS scorre i modelli. Cambiare modello svuota la coda. Le etichette dei knob cambiano: Plate usa anche Motion, mentre altri modelli espongono Decay.

## Mix e trattamento generale
GLO apre Mix, equalizzazione master, colore, uscita, LFO globale e Setup. Mix regola mandate, pan e livello. I tasti neri consentono mute e solo secondo il gesto indicato dalla pagina.

L’equalizzatore è piatto al valore centrale 64. Master Color offre Off, Tape e Sampler, con quantità, tono e mix. Master Out distingue livello percussivo e melodico, compressione e Pump. Il livello master 100 corrisponde al riferimento unitario.

Pump abbassa temporaneamente il materiale seguendo una sorgente ritmica. Una cassa può far pulsare le parti melodiche mantenendo le percussioni in primo piano. Una sorgente melodica o il metronomo può invece agire sull’insieme previsto dal routing. Una cassa in mute può continuare a pilotare il detector: controllare la sorgente se il pumping sembra inspiegabile.

---
# 12. LFO: panoramica e scelta
Un LFO genera una variazione lenta che modula un parametro. Nella Blue convivono il LFO locale originale, il LFO globale e i nuovi LFO A e B. A/B sono indipendenti per ogni traccia melodica di sintesi, Sample o Slice; non sono disponibili sulle tracce Kit o MIDI/CC.

Il LFO originale conserva il suo funzionamento. Il globale, raggiungibile da GLO, può coinvolgere più tracce selezionate. A/B servono a creare movimenti per traccia e a inviare la stessa sorgente a più destinazioni con quantità indipendenti.

Premere LFO e usare SELECT: dopo le due pagine originali compaiono LFO A, A Routes 1–2, A Routes 3–4, poi LFO B e le due pagine di routing corrispondenti.

## Forma, velocità, fase e riavvio
| Controllo | Utilizzo |
| --- | --- |
| Shape | Off, Sine, Triangle, Saw Up, Saw Down, Square, Random, Drift. |
| Rate | Divisione sincronizzata oppure velocità libera, circa 0,02–20 Hz. |
| Phase | Punto iniziale della forma d’onda; 180° sposta di mezzo ciclo. |
| Restart | Free, Retrigger oppure Transport. |

Random produce un valore casuale bipolare mantenuto fino al cambio successivo, come un Sample & Hold. Drift collega valori casuali con un movimento più morbido. Sine e Triangle sono adatte a oscillazioni regolari; Saw e Square a cambi più marcati.

Le divisioni sincronizzate sono 2/1, 1/1, 1/2, 1/4D, 1/4, 1/8D, 1/8, 1/16D, 1/16, 1/32 e 1/64, seguite dalla regione libera. Una divisione D è puntata anche qui.

Free lascia scorrere l’oscillatore. Retrigger lo riavvia a ogni nota della traccia. Transport lo riavvia con Play. Per un movimento che attraversa più note scegliere Free o Transport; Retrigger con note molto ravvicinate può far ascoltare sempre solo l’inizio dell’onda.

## Destinazioni e profondità
Ogni LFO ha quattro assegnazioni. Nella pagina Routes 1–2 i knob sono Dest 1, Depth 1, Dest 2, Depth 2; nella successiva si modificano 3 e 4.

Le destinazioni comprendono Pan, Pitch, Pitch Scale, Cutoff, Reso, Volume, FX I, FX II, Character, i quattro parametri del motore con i loro nomi effettivi, Attack, Decay, Sustain, Release e Filter Env. Off disabilita quella rotta.

Depth va da −100% a +100%; **0% è neutro**. Una profondità negativa inverte il contributo della stessa sorgente. Le assegnazioni si sommano alle altre modulazioni e il risultato viene limitato all’intervallo del parametro. Un parametro già vicino al limite può quindi muoversi meno in una direzione.

A/B partono con Shape Off e profondità neutre, così un progetto importato non riceve automaticamente nuove modulazioni. Per sentire un effetto occorre scegliere una forma attiva, una destinazione e una profondità diversa da zero.

## Controfase e destinazioni multiple
Esempio: usare LFO A Sine, Rate 1/2, Route 1 Pan +40%, Route 2 Cutoff −25%. Quando il valore dell’onda aumenta, il contributo al pan cresce e quello al cutoff diminuisce.

Per modulazioni regolari fra due LFO impostare la stessa frequenza, lo stesso Restart e una differenza di Phase di 180°. Per ottenere valori casuali esattamente opposti, usare invece due route dello stesso LFO Random con profondità di segno contrario. Due LFO Random indipendenti, anche a 180°, non generano coppie casuali complementari.

Si possono assegnare più route allo stesso parametro; i contributi si sommano. È utile per combinare una lenta oscillazione con un movimento rapido, ma può anche portare facilmente al limite della destinazione.

---
# 13. Pitch casuale quantizzato alla scala
Pitch crea una variazione continua di altezza. Pitch Scale inserisce una quantizzazione delle note alla tonalità e scala globali del Conductor. Alla profondità massima una singola rotta copre nominalmente circa un’ottava in ciascuna direzione; più rotte possono sommarsi.

La quantizzazione considera la nota finale con le modulazioni musicali di pitch previste. Funziona anche quando quella traccia non segue gli accordi del Conductor. Le espressioni continue come pitch bend, vibrato e wow del nastro mantengono invece il proprio comportamento continuo.

## How to: una melodia casuale in Do maggiore
1. Nel Conductor impostare Key C e Scale Major.
2. Su una traccia sintetica creare un pattern con note lunghe, per esempio C3 ripetuto ogni quarto.
3. Aprire LFO B e impostare Random, Rate 1/8D, Restart Transport.
4. Aprire B Routes 1–2: Dest 1 Pitch Scale, Depth 1 circa +25%.
5. Avviare e aumentare lentamente la profondità per estendere il registro.
6. Salvare il progetto dopo aver scelto una combinazione utile.

Il risultato varia tra note consentite dalla scala, con intervallo casuale aggiornato alla velocità dell’LFO. Se la profondità è piccola si possono sentire poche note ripetute: la quantizzazione produce gradini, non un glissando. Una nota di base esterna alla scala può essere corretta già con una rotta Pitch Scale attiva a profondità non nulla.

Per un pitch stabile con solo movimento stereo, lasciare le destinazioni Pitch e Pitch Scale disattivate e usare Pan. Per un effetto più continuo scegliere Drift con Pitch; per note musicali a gradini scegliere Random con Pitch Scale.

Le impostazioni A/B sono salvate nel progetto. Il preset sonoro utente non costituisce un archivio completo di queste nuove modulazioni: salvare sempre anche il progetto.

---
# 14. Conductor: tonalità e armonia
Il Conductor definisce la tonalità e la scala globali e può guidare gli accordi delle tracce collegate. Selezionare COND con ALGORITHM e usare EDIT per Key, Scale e impostazioni di collegamento.

La pagina di routing permette di abilitare il follow sulle tracce tramite i tasti neri 1–8. I kit non seguono l’armonia. Il menu offre comportamento diatonico o sola trasposizione, secondo l’obiettivo musicale.

Gli step del Conductor contengono gli accordi della progressione. Impostando la durata dello step a quattro sedicesimi si ottiene un cambio per quarto; con sedici sedicesimi, uno per battuta.

## Guidare la progressione con una traccia
Nella pagina Follow selezionare la traccia guida. La sua nota più bassa o la radice dell’accordo pilota il contesto armonico; la traccia guida continua a suonare il materiale scritto. Può guidare anche se in mute. Durante questa modalità la progressione a step del Conductor lascia il controllo alla traccia guida.

Distinguere tre concetti: Scale nel Conductor è una scala musicale; Pace in Steps è una durata; Pitch Scale nei nuovi LFO è una destinazione che usa la scala musicale globale.

---
# 15. Scene e Song
HOME apre Arrange. I tasti bianchi richiamano le scene 1–16; OCT + raggiunge 17–32. Selezionare una scena vuota parte dal contesto corrente, con riferimenti condivisi ai pattern.

Durante la riproduzione, una scena viene normalmente accodata al cambio previsto; una seconda pressione può forzare il passaggio immediato. Premere la scena corrente annulla un richiamo in attesa. SCENES SWITCH permette la sincronizzazione a battuta o alla fine del pattern T1.

I tasti neri 1–8 gestiscono i mute delle tracce. Le scene conservano anche mute e informazioni del Conductor; per i primi quattro kit possono includere i mute dei singoli strumenti. Tenere il tasto della traccia kit e agire sui bianchi per i suoi suoni.

## Costruire una Song
Da Arrange passare alla vista Song con HOME o SELECT secondo la pagina. Inserire scene con i tasti bianchi. I knob scelgono posizione, scena, durata in battute e comportamento loop/fine. Le azioni SEL permettono inserimento, duplicazione, cancellazione e pulizia della Song.

Una battuta della Song equivale sempre a sedici sedicesimi, anche se alcune tracce usano lunghezze o valori Pace differenti. PLAY parte dalla posizione selezionata; l’azione PLAY SONG permette la partenza dall’inizio.

Esempio: scena 1 per 4 battute di intro, scena 2 per 8 battute, scena 3 per 8 battute e scena 2 per altre 8. Provare prima le transizioni in Arrange, poi scrivere la sequenza Song.

---
# 16. Trick, Weave e Throws
## Trick per step
Tenere uno step e premere ARP per impostare due trick. I primi due knob scelgono tipo e quantità del primo, gli altri due il secondo. Questi interventi trasformano l’esecuzione senza richiedere nuove note nel pattern.

Fra le possibilità: Pulse ripete nel tempo, Hold prolunga, Multiply crea ripetizioni dentro lo step, Velocity cambia l’accento, Ramp Up/Down sposta le note, Random Note usa la scala, Glide e Bend alterano i passaggi, Tonality cambia il trattamento armonico, Jump muove la lettura e le funzioni Skip applicano condizioni a trigger, trick o lock. Flam aggiunge un colpo di grazia.

Chance e condizioni possono impedire l’esecuzione di uno step: anche i trick di quello step possono quindi non intervenire. Per un ratchet regolare iniziare con Multiply e probabilità sempre attiva; aggiungere casualità solo dopo aver verificato il ritmo di base.

## Weave
Le pagine finali di ARP permettono di combinare la traccia corrente con un’altra sorgente: WITH sceglie la traccia, PATTERN il pattern, RULE il tipo di intreccio e PLAYS la condizione di attivazione.

Le regole alternano battute o step oppure combinano il ritmo di una traccia con le altezze dell’altra. È una trasformazione dal vivo: KEEP AS PATTERN permette di fissare il risultato in un pattern vuoto.

La traccia ausiliaria WEAVE offre trigger dedicati e Latch. REC può registrare gli interventi per ripeterli nel brano. Prima di fissare un intreccio, verificare la durata e il materiale sorgente di entrambe le tracce.

## Throws
FX comprende la pagina Throws; esiste anche la traccia ausiliaria THROW. I tasti richiamano interventi come Mute, Stutter, Repeat, Echo, Build, Floor, Jumble, Warble, Pan, Octave, Chop e Ring.

Gli interventi momentanei terminano al rilascio e rientrano sulla griglia. Latch permette di mantenerli. REC può registrarli. LOOP THROWS può conservare la posizione di un loop e produrre uno slittamento intenzionale: disattivarlo se si desidera il rientro consueto.

---
# 17. MIDI, Bluetooth e connessioni
GLO Setup contiene le impostazioni di connessione. Con SELECT scegliere la riga e con SEL confermare o avviare la ricerca prevista; HOME torna indietro. Mettere prima il dispositivo esterno nella modalità di associazione appropriata.

Bluetooth audio introduce una latenza percepibile e durante l’uso può disattivare l’uscita fisica locale. Per suonare e registrare con precisione, verificare il risultato con l’uscita cablata. Bluetooth MIDI e audio sono funzioni diverse: collegarne una non implica aver collegato l’altra.

Una sola connessione Bluetooth MIDI è utilizzabile alla volta. Il nome del dispositivo comprende FM-1 e un identificativo. Sul Mac il collegamento MIDI Bluetooth si gestisce anche da Configurazione MIDI Audio. Se richiesto, il PIN viene mostrato dal dispositivo.

## Clock
Receive segue un clock MIDI in ingresso e torna al clock interno quando il segnale manca per circa mezzo secondo. Send usa il clock interno e lo invia. Internal usa il tempo locale senza seguire né trasmettere il clock.

Se il BPM sembra ignorare la regolazione locale, controllare Receive e la presenza di un clock esterno. Evitare di creare due sorgenti master in competizione.

## Canali e controlli principali
| Canale MIDI | Destinazione |
| --- | --- |
| 1–8 | Tracce T1–T8. |
| 9 | FX I. |
| 10 | FX II. |
| 11 | Master e scene. |
| 12–16 | Suonano l’ultimo strumento selezionato, senza uscita corrispondente. |

Sulle tracce melodiche i CC principali sono 7 Level, 10 Pan, 91 Send I, 93 Send II, 74 Cutoff, 71 Resonance, 73 Attack, 72 Release, 75 Decay, 5 Glide e 1 quantità del LFO originale. CC 9 controlla il mute, attivo da 64 in su. Nei kit alcuni CC hanno significati specifici: non applicare automaticamente la mappa melodica al bus percussivo.

Sul canale 11, Program Change 0–31 o note 36–67 richiamano le scene 1–32 secondo la regola SCENES SWITCH. L’uscita scene è una funzione separata e non riflette automaticamente i messaggi ricevuti.

MIDI OUT e l’impostazione NOTES governano l’invio delle tracce interne; il motore MIDI è dedicato agli strumenti esterni. CC OUT invia i movimenti manuali dei controlli mappati, non tutte le automazioni, i lock o i cambi preset. I messaggi ricevuti non vengono semplicemente rimandati in uscita.

L’ingresso TRS MIDI è solo ingresso e non gestisce SysEx. Per l’uscita usare USB o Bluetooth. La modalità USB Host richiede alimentazione adeguata, normalmente un hub alimentato: FM-1 non fornisce alimentazione alla periferica. In Host non è contemporaneamente disponibile il collegamento USB al computer per audio, campioni o backup.

---
# 18. Backup, emulatore e aggiornamento
Il pacchetto Blue r9 contiene il firmware, i sorgenti, un emulatore browser e le pagine di installazione, campioni e backup. Avviare Avvia-LOOM-8-Blue.command dal pacchetto; il server locale usa la porta 8878.

| Pagina locale | Scopo |
| --- | --- |
| http://localhost:8878/emu/ | Emulatore della versione inclusa. |
| http://localhost:8878/install/ | Installazione del firmware sul dispositivo compatibile. |
| http://localhost:8878/samples/ | Gestione del banco campioni. |
| http://localhost:8878/backup/ | Copia e ripristino dei dati salvati. |

L’emulatore è utile per imparare i menu e verificare un’impostazione. Non sostituisce il controllo di connessioni, latenza, carico e comportamento dell’hardware. Non assumere che i dati presenti nell’emulatore siano già nel dispositivo fisico.

## Procedura di backup
1. Sul dispositivo premere SAVE e attendere la conclusione del salvataggio.
2. Collegare il dispositivo al computer nella modalità USB appropriata.
3. Aprire /backup/ con un browser compatibile e collegarsi al dispositivo.
4. Esportare i dati, includendo i campioni quando necessario.
5. Conservare il file con data, versione firmware e una breve descrizione.

Il backup fotografa i dati salvati: modifiche ancora solo in memoria possono non esserci. Il ripristino può sostituire tutti e tre i progetti, i preset utente, i kit e i campioni inclusi. Leggere la conferma sul dispositivo; SEL conferma e HOME annulla. Eseguire queste operazioni a trasporto fermo.

## Aggiornare conservando il lavoro
Conservare prima un backup e una copia della versione precedente. Usare il file 0.9.3-blue9 del pacchetto r9 con la sua pagina di installazione, seguendo le istruzioni presentate. Dopo il riavvio controllare un progetto rappresentativo, le impostazioni FX e le connessioni.

Non risalvare subito l’unica copia di un progetto importante: conservare l’esportazione precedente: il formato 19 non è leggibile dalla r6 e dai firmware più vecchi.

---
# 19. How to: ricette operative
## Un basso con accenti e aperture del filtro
1. Scegliere Knit su una traccia melodica e una modalità Mono.
2. Inserire quattro o otto note brevi in un pattern di 16 step.
3. Tenere alcuni step e aumentare Velocity per creare gli accenti.
4. Tenere uno step, aprire ENV e impostare un cutoff più aperto come lock.
5. Lasciare gli altri step senza lock per far tornare il filtro al valore base.

Risultato: un basso ritmico con aperture localizzate. Se il filtro sembra sempre aperto, controllare la durata delle note, i lock sugli step successivi e le eventuali modulazioni LFO.

## Delay puntato senza cambiare la griglia
1. Lasciare il pattern con il valore Pace desiderato, per esempio un ottavo.
2. Impostare FX I Delay, Time 1/8D, Fine 50.
3. Inviare una sola traccia al delay e usare poco feedback all’inizio.
4. Aggiungere gradualmente feedback e mandata per integrare le risposte nel groove.

Risultato: la sequenza mantiene la propria griglia, le ripetizioni seguono l’ottavo puntato. A 70 BPM l’intervallo è circa 643 ms. Controllare il limite di memoria se si scende molto di BPM o si selezionano divisioni più lunghe.

## Due scene con una vera variazione di batteria
1. Preparare la scena 1 e passare a una scena vuota.
2. Sulla traccia Kit usare COPY TO EMPTY.
3. Aggiungere un fill negli ultimi quattro step del nuovo pattern.
4. Richiamare alternativamente le due scene per verificare che il fill compaia solo nella seconda.
5. Salvare e assegnare le scene alle sezioni della Song.

Risultato: due arrangiamenti con pattern di batteria indipendenti. Se il fill appare in entrambe, verificare che le scene non richiamino ancora lo stesso numero di pattern.

## Pan vivo e filtro in movimento opposto
1. Scegliere una traccia melodica con note lunghe e pan generale centrale.
2. Impostare LFO A Sine, Rate 1/2, Restart Transport.
3. Assegnare Pan +35% e Cutoff −20% sulle prime due route.
4. Regolare il cutoff di base circa a metà della zona utile del suono.
5. Aggiungere LFO B Drift molto lento su Character con profondità contenuta.

Risultato: movimento stereo periodico, filtro correlato in senso opposto e una variazione timbrica non periodica. Se si desidera ripetibilità temporale usare forme regolari al posto di Drift.

## Arpeggio lento in 1/4D
1. Preparare un accordo sostenuto su una traccia melodica.
2. Aprire ARP e selezionare il player arpeggiatore.
3. Girare Speed oltre 1/64 fino a 1/4D.
4. Scegliere Up o Bounce e un Range di una o due ottave.
5. Allungare l’accordo o usare Hold se il player si interrompe troppo presto.

Risultato: scansione a quarti puntati; a 70 BPM ogni avanzamento dista circa 1,286 secondi. Il limite di memoria del delay non riguarda questa velocità dell’arpeggiatore.

## Un break riordinato senza cambiare campione
1. Caricare un loop nella pagina campioni e impostarne correttamente Root Note e battute.
2. Scegliere il motore Slice e otto suddivisioni.
3. Inserire note cromatiche che selezionino prima le slice in ordine.
4. Duplicare il pattern e cambiare l’ordine delle note nella copia.
5. Provare Mono per tagli netti oppure Poly per sovrapposizioni.

Risultato: una variante ritmica ottenuta dagli stessi frammenti. Se cambia anche l’altezza seguendo il BPM, è il comportamento del ricampionamento, non un guasto.

## Un fill con ratchet e probabilità
1. Duplicare il pattern di batteria in uno slot vuoto.
2. Scegliere uno step del rullante, tenerlo e aprire ARP.
3. Assegnare Multiply al primo slot trick e partire da poche ripetizioni.
4. Ridurre Velocity se il fill sovrasta il resto del kit.
5. Regolare Chance solo dopo aver verificato la versione senza casualità.

Risultato: un fill compatto con variazioni controllate. Salvare una scena dedicata per poterlo richiamare soltanto quando serve.

## Preparare un set dal vivo
Creare poche scene chiaramente distinte e verificare i passaggi. Bilanciare il master ascoltando anche le sezioni più dense, non soltanto l’intro. Provare Throws e mute senza registrazione, poi registrare solo gli interventi che devono ripetersi. Salvare, esportare un backup e controllare i collegamenti prima dell’esecuzione.

---
# 20. Risolvere i problemi
| Sintomo | Controllo e rimedio |
| --- | --- |
| La traccia non suona | Verificare mute/solo, volume, note, Chance, motore scelto e presenza del campione. Controllare anche routing e uscita audio. |
| Il delay non si sente | Controllare tipo FX I, mandata della traccia, livello del ritorno e mute del banco. Nei kit controllare la mandata del singolo suono. |
| Il delay è più veloce del previsto | La durata richiesta può superare 1.004,3 ms ed essere stata dimezzata. Riportare Fine a 50 e verificare BPM e divisione. |
| Fine non sembra neutro | Il riferimento è 50. Valori più alti o più bassi modificano la divisione selezionata. |
| Non trovo 1/8D o 1/4D in ARP | Continuare oltre 1/64: le aggiunte Blue sono in fondo alla lista. |
| Non trovo 1/4D nel delay | È previsto: il delay non include quella divisione. ARP e LFO A/B la includono. |
| LFO A/B non fa nulla | Attivare Shape, scegliere una destinazione e portare Depth oltre 0%. Verificare di essere su una traccia compatibile. |
| Il movimento LFO riparte troppo spesso | Controllare Restart: Retrigger riparte a ogni nota. Provare Free o Transport. |
| Due Random non sono opposti | Usare due route dello stesso Random con segni contrari; due generatori indipendenti non sono complementari. |
| Pitch Scale fa salti bruschi | È la quantizzazione. Ridurre Depth o scegliere Pitch per un movimento continuo. |
| Pan resta spostato | Controllare offset per step, step realmente eseguiti, pan globale e LFO. Stop interrompe l’offset temporaneo. |
| Modifico una scena e cambia anche un’altra | Condividono il pattern o il suono della traccia. Copiare il pattern con COPY TO EMPTY per variazioni indipendenti. |
| Il salvataggio automatico non arriva | Fermare il trasporto e attendere il silenzio completo; per sicurezza premere SAVE. |
| Il progetto non si apre nel vecchio firmware | Un salvataggio r9 usa formato 19. Ripristinare il backup precedente compatibile. |
| Il browser non vede il dispositivo | Usare un browser con supporto USB, il collegamento al computer e un cavo dati; uscire da USB Host e verificare altre applicazioni collegate. |
| L’audio Bluetooth arriva in ritardo | Verificare con uscita cablata: il trasporto Bluetooth audio introduce latenza. |

Se il comportamento resta insolito, salvare una copia, provare un pattern semplice su una sola traccia e disattivare temporaneamente modulazioni, trick e player. Riattivare le funzioni una alla volta per trovare la causa senza perdere il progetto originale.

---
# 21. Riferimento rapido e glossario
| Valore neutro | Contesto |
| --- | --- |
| Fine = 50 | Nessuna correzione della divisione del delay. |
| PAN +/− = 0 | Nessun offset di pan nello step. |
| Depth = 0% | Nessun contributo della rotta LFO A/B. |
| EQ = 64 | Valore centrale piatto dell’equalizzatore master. |
| Master Level = 100 | Livello unitario di riferimento. |

BPM: quarti al minuto. D: divisione puntata, pari a una volta e mezza il valore regolare. T: terzina, pari a due terzi del valore regolare. Per esempio, a 120 BPM un quarto dura 500 ms, un ottavo 250 ms, un ottavo puntato 375 ms.

Parameter Lock: valore associato a uno step. Motion: movimento di un parametro registrato nel pattern. Depth: intensità e segno di una modulazione. Phase: posizione nell’onda periodica. Retrigger: riavvio al nuovo evento di nota. Sample & Hold: valore casuale mantenuto fra due aggiornamenti.

Send: quantità inviata a un effetto parallelo. Return: livello del segnale che torna dall’effetto. Feedback: porzione delle ripetizioni reinviata alla linea delay. Choke: interruzione reciproca fra suoni dello stesso gruppo. Root Note: nota di riferimento del campione. Slice: frammento di un campione. Scene: richiamo di pattern e stato di arrangiamento.

## Cosa conservare insieme al progetto
Conservare il file di backup, il pacchetto firmware corrispondente, il banco campioni quando necessario e questo manuale. Usare nel nome della copia la data e la revisione, per esempio «Brano_A_2026-10-30_Blue-r9». I tre slot interni non sono un archivio storico.

## Fonti, versione e attribuzioni
Guida realizzata sulla base dei sorgenti e del manuale LOOM-8 inclusi nel pacchetto Blue r9, con integrazione delle modifiche Blue. Il progetto originale LOOM-8 è di Charles Vestal; il codice principale dei file applicativi è distribuito secondo MPL-2.0; alcuni componenti hanno altre licenze, inclusa GPL-3.0. Sono conservati i relativi avvisi nei sorgenti. Fare riferimento ai file di licenza dei sorgenti per i termini applicabili.

Riferimenti locali nel pacchetto r9: source/docs/MANUAL.md per la guida originale, LEGGIMI.md per le note Blue, BUILD-INFO.json e SHA256SUMS per l’identificazione della build. Questa è una guida operativa riorganizzata in italiano, non una dichiarazione di compatibilità con release successive.


---
# 22. Generatore Random / Euclidean
Il generatore crea una nuova frase per la traccia selezionata. È disponibile sulle tracce melodiche di sintesi e Sample, incluso Bellows; non sui Kit, su Slice, su MIDI/CC o sulle tracce ausiliarie. La generazione ritmica per singoli strumenti del kit non è inclusa nella r9.

Il materiale viene scritto nel primo pattern vuoto della stessa traccia. Il pattern di partenza resta disponibile: non serve una copia completa di tutte le sequenze in memoria. Dopo la generazione, la scena corrente viene impostata per usare la nuova variante. Premere PLAY per ascoltarla, oppure scegliere nuovamente il pattern di partenza per tornare all’originale.

## Aprire e configurare il generatore
1. Fermare il trasporto con PLAY e scegliere una traccia compatibile con ALGORITHM.
2. Premere SEQ: si apre Steps. Ruotare l’encoder SELECT di due posizioni: Bar, poi Generator. Non premere SEL.
3. Usare i tasti bianchi 1, 2 e 3 per scegliere il banco di quattro controlli e regolare i knob.
4. Osservare il candidato nella griglia grafica: le note originali non sono ancora state sostituite.
5. Premere il tasto bianco 16 per GENERATE TO EMPTY.
6. Premere PLAY per ascoltare il nuovo pattern e SAVE per conservarlo.

La pagina grafica si controlla direttamente con i knob. SELECT ruota fra Steps, Bar, Generator ed Evolver; ALGORITHM cambia traccia. Il menu tradizionale SEQ → SEL → GENERATOR resta disponibile come alternativa: soltanto in quel menu SELECT sceglie le righe e ALGORITHM modifica i valori.

| Parametro | Significato |
| --- | --- |
| LOW / HIGH | Estremi del registro, comuni al generatore e all’Evolver di quel pattern. |
| METHOD | Random oppure Euclidean. |
| DENSITY % | Probabilità indipendente di inserire una nota su ogni step, usata da Random. |
| PULSES | Numero di impulsi euclidei, limitato alla lunghezza del pattern. |
| ROTATION | Spostamento ciclico degli impulsi euclidei. |
| ROOT WEIGHT % | Probabilità di favorire la tonica, quando presente nell’ottava e nel registro scelti. |
| NOTE LENGTH | Durata della nota in quarti di step: 2/4 step equivale a mezzo step. |
| VELOCITY | Intensità delle nuove note, da 1 a 127. |
| SEED | Numero da 0 a 65535 che determina la sequenza casuale riproducibile. |

Il generatore usa Key e Scale globali del Conductor. Stesso seed, impostazioni, scala, lunghezza e sorgente protetta producono lo stesso materiale. GENERATE TO EMPTY non incrementa automaticamente il seed: modificarlo per ottenere una nuova proposta casuale.

## Differenze fra i due metodi
Random con Density 50% non garantisce otto note su sedici: ogni step viene valutato indipendentemente. Euclidean con cinque impulsi su sedici crea invece cinque posizioni distribuite nel ciclo. Rotation sposta le posizioni senza cambiarne il numero.

La garanzia sul numero euclideo vale per step non protetti e un registro contenente note della scala. Gli step protetti mantengono il materiale sorgente, quindi il totale può cambiare. Un registro senza note valide produce pause sugli step non protetti. La nota MIDI 0 è riservata alla rappresentazione del silenzio.

## Che cosa viene conservato
Il nuovo pattern eredita lunghezza, griglia, groove, loop e gli attributi esistenti della sorgente. Sui passi non protetti vengono sostituite le note; dove viene generato un attacco, si impostano anche durata e velocity selezionate. È un generatore monofonico: le nuove posizioni contengono una sola nota.

Lock, condizioni e trick vengono conservati: possono cambiare o impedire l’esecuzione dei trigger generati. Anche il pan per step e le automazioni restano presenti. Per un primo esperimento prevedibile usare una sorgente senza trick, probabilità restrittive o automazioni complesse.

Le impostazioni generative vengono copiate nella variante quando presenti, mentre l’Evolver della variante parte Off e gli scostamenti vengono azzerati. Le protezioni vengono mantenute. Le impostazioni LFO, il timbro e il mix della traccia continuano a essere condivisi fra i suoi pattern.

Se tutti gli otto pattern hanno note, compare NO EMPTY PATTERN. Liberare consapevolmente uno slot oppure usare un’altra traccia. Il termine “vuoto” significa senza note: uno slot può comunque avere automazioni o essere richiamato da altre scene. Verificare il progetto prima di riutilizzarlo.

---
# 23. Evolver melodico
L’Evolver modifica lentamente le altezze delle note già presenti, senza aggiungere o togliere trigger. Usa piccoli scostamenti in gradi della scala globale; le note scritte restano la base originale. Gli accordi ricevono lo stesso scostamento per step, con possibili adattamenti agli estremi del registro.

## Impostare l’evoluzione
1. Da Steps ruotare l’encoder SELECT di tre posizioni: Bar, Generator, Evolver. Non premere SEL.
2. Nel banco 1 Motion impostare Mode, Cycles, Chance e Range.
3. Premere il bianco 2: nel banco Limits regolare Return, Low, High e Seed.
4. Portare Mode su On da fermo: la prima attivazione riserva le risorse necessarie.
5. Avviare PLAY. Il primo ciclo mantiene lo stato iniziale.
6. Osservare le note evolute nella griglia e premere il bianco 14 per Freeze quando emerge una variante utile.

| Parametro | Comportamento |
| --- | --- |
| MODE Off | Suona le note originali e sospende le mutazioni; conserva gli scostamenti per un successivo riutilizzo. |
| MODE On | Applica gli scostamenti e permette nuove mutazioni. |
| MODE Freeze | Applica gli scostamenti correnti senza modificarli né avanzare il generatore casuale. |
| EVERY CYCLES | Intervallo: 1, 2, 4, 8, 16 o 32 cicli del pattern della traccia. |
| CHANCE % | Probabilità di aggiornamento di uno step idoneo nel ciclo previsto. |
| RANGE DEGREES | Distanza massima dall’originale: da 0 a 12 gradi della scala in ciascuna direzione. |
| RETURN % | In un aggiornamento accettato, probabilità di azzerare lo scostamento di quello step. |
| LOW / HIGH | Registro usato per contenere le note mutate; condiviso con Generator. |
| SEED | Inizializzazione del generatore casuale proprio di quel pattern. |

Ogni mutazione ordinaria muove lo scostamento di un grado verso l’alto o il basso, fino al limite RANGE DEGREES. RANGE non è un salto casuale dell’intera ampiezza a ogni aggiornamento. Return favorisce il ritorno all’originale durante gli aggiornamenti; non è un reset immediato dell’intera frase.

## Tempo, ripetizioni e interazioni
L’intervallo usa i cicli del pattern, non i secondi né le battute della Song. Un pattern di sedici sedicesimi dura normalmente una battuta; con altre lunghezze e valori Pace, un ciclo può durare diversamente. Trick Jump e loop possono influire sul conteggio dei passaggi.

L’aggiornamento è distribuito: ogni step viene valutato quando suona nel ciclo previsto. Non tutte le note cambiano contemporaneamente all’inizio del ciclo. Le code già avviate mantengono la propria altezza; i successivi attacchi ricevono il nuovo risultato.

Gli step silenziosi, protetti, esclusi dalla probabilità, coperti da Hold/Pulse o non eseguiti in mute non generano una nuova mutazione. Ratchet e ripetizioni riutilizzano lo stato disponibile. Durante la registrazione REC le nuove mutazioni sono sospese. Quando Weave sostituisce il materiale della traccia, l’Evolver non trasforma quel materiale incrociato.

Stop sospende il lavoro e conserva gli scostamenti. Una nuova partenza da Play ricomincia il conteggio dei cicli, ma non cancella la variante corrente. Non vengono recuperate mutazioni arretrate per il tempo passato in Off, Freeze o su un altro pattern.

## Proteggere una nota o un accordo
Da fermo, nella pagina Evolver premere il bianco 3 per il banco Protect. Knob 1 sceglie lo step e Knob 2 abilita/disabilita la protezione; Knob 3 mostra la prima nota base e Knob 4 la prima nota evoluta, entrambi di sola lettura. In alternativa, tenere lo step in Steps, premere SEL, scegliere PROTECT STEP e confermare con SEL. La voce mostra On oppure Off. Ripetere per invertire la protezione; con più step tenuti si applica a tutti la scelta derivata dal primo step.

La protezione riporta subito lo step alla sua nota base rispetto all’Evolver e ne impedisce la mutazione. Il generatore conserva l’intero step protetto, compresi accordo e attributi. Non blocca invece l’editing manuale, il Conductor, i trick o gli LFO: questi restano strumenti separati.

## Reset e Capture
Il bianco 15 della pagina Evolver esegue RESET EVOLUTION da fermo: azzera tutti gli scostamenti e reimposta la sequenza casuale al seed. Mantiene le protezioni e il Mode corrente: se resta On, le mutazioni potranno ricominciare dopo la ripartenza.

Il bianco 16 della pagina Evolver esegue CAPTURE TO EMPTY, sempre da fermo: crea nel primo pattern vuoto una versione con le note evolute scritte come nuove note base. Nella copia l’Evolver parte Off; l’originale resta disponibile con il proprio stato. Il risultato include gli scostamenti dell’Evolver, non il rendering di Conductor, arpeggiatore, LFO, Weave o trick.

Capture conserva lock e attributi copiati. Per congelare completamente una performance bisogna valutare anche gli altri processi attivi: Freeze dell’Evolver non congela i nuovi LFO A/B o gli effetti.

---
# 24. How to: generare e far evolvere una frase
## Una melodia casuale riproducibile
1. Impostare nel Conductor C Minor e scegliere una traccia Knit.
2. Preparare un pattern di 16 step senza lock o trick per iniziare.
3. Aprire Generator: LOW C3, HIGH C5, METHOD Random, DENSITY 50%, ROOT WEIGHT 40%, VELOCITY 90.
4. Lasciare NOTE LENGTH a 2/4 step e scegliere SEED 1729.
5. Eseguire GENERATE TO EMPTY e ascoltare con PLAY.
6. Per un’altra proposta, cambiare il seed e generare in un altro slot vuoto.

Risultato: una frase monofonica nella scala globale. Tornando allo stesso seed e alla stessa sorgente si può ricreare la stessa proposta. Le impostazioni vengono salvate nel progetto, non nel preset sonoro.

## Cinque impulsi su sedici con una nota guida
Impostare METHOD Euclidean, PULSES 5 e ROTATION 0. Per una linea su una singola altezza, scegliere LOW e HIGH sulla stessa nota appartenente alla scala. Generare e ascoltare. Cambiare Rotation per spostare la distribuzione; mantenere Pulses a 5 per conservare il numero di attacchi, in assenza di protezioni e condizioni.

## Basso che cambia lentamente ma mantiene gli appoggi
1. Scrivere una frase con una nota importante sul primo step e alcune note interne.
2. Da fermo proteggere il primo step con PROTECT STEP.
3. Aprire Evolver: EVERY CYCLES 4, CHANCE 25%, RANGE DEGREES 2, RETURN 20%.
4. Scegliere un registro adatto al basso e portare MODE su On.
5. Avviare e lasciare scorrere diversi cicli.
6. Quando emerge una variante utile, aprire Evolver e passare da On a Freeze.
7. Fermare il trasporto, eseguire CAPTURE TO EMPTY e salvare.

Risultato: gli appoggi protetti restano stabili rispetto all’Evolver; le altre note compiono piccoli passi nella scala. Il nuovo pattern catturato può essere usato da una scena dedicata.

## Evoluzione più evidente per verificarne il funzionamento
Per una prova breve usare EVERY CYCLES 1, CHANCE 100%, RETURN 0% e RANGE DEGREES 2. Il primo giro conserva lo stato iniziale; dai successivi gli step idonei si muovono. Tornare poi a probabilità più basse per un risultato meno insistente.

Se non si sente alcun cambiamento, verificare Mode, tipo di traccia, protezioni, numero di cicli trascorsi, Chance, Range e ampiezza LOW/HIGH. Un solo tasto valido nel registro può impedire variazioni udibili anche se lo stato interno evolve.

---
# 25. Memoria, salvataggio e limiti della r9
Le funzioni nuove usano il pool esistente di 96 corsie del progetto. Un pattern con sola configurazione Generator usa una corsia; l’Evolver richiede una corsia di configurazione e una per scostamenti/protezioni. Una sola protezione può richiedere soltanto la corsia per step. Queste risorse sono condivise con Parameter Lock, motion, pan e attributi percussivi.

LANES FULL indica che non c’è spazio per l’operazione. Eliminare soltanto lock o pattern che non servono, dopo un backup. GENERATE e CAPTURE verificano lo spazio per copiare le corsie prima di scrivere la nuova variante; se non basta, non creano una copia parziale.

Il codice dei motori audio, incluso Bellows, resta disponibile. Il risparmio di memoria deriva dall’uso di scostamenti compatti e dei pattern vuoti per le varianti, senza una seconda copia completa di tutti i pattern.

Il progetto salva configurazione, protezioni, scostamenti e stato casuale raggiunto. SAVE va eseguito dopo Stop e al termine delle code, secondo la normale gestione della memoria flash. Un riavvio conserva la variante salvata, ma non riprende una nota o un ciclo di playback a metà.

La r9 usa lo stesso formato progetto 19 di r7 e r8: i progetti possono essere scambiati fra queste revisioni. Importa anche i formati precedenti supportati, inclusa r6/formato 18. Le funzioni evolutive sono disattivate sui progetti importati dalla r6 o da versioni più vecchie; i progetti r7 conservano le proprie impostazioni. Un salvataggio in formato 19 non è leggibile dalla r6: conservare il backup precedente per un eventuale ritorno.

L’editor Steps mostra le note base. Per conservare le note evolute come materiale direttamente editabile usare Capture. Le modulazioni continue e le trasformazioni di playback possono ancora modificare ciò che si ascolta dopo la cattura.

Questa prima implementazione include generazione melodica ed evoluzione delle altezze. Evoluzione della densità ritmica, generazione per kit, evoluzione autonoma di velocity/pan/durata e timbro restano sviluppi successivi. I controlli manuali, i trick e gli LFO già disponibili continuano a coprire parte di questi impieghi.


---
# 26. Destinazioni degli engine e Pace nella r8
Le destinazioni generiche Synth 1–4 dei LFO A/B ora mostrano i nomi dei quattro knob del motore selezionato. Le associazioni erano già operative: la r8 le rende riconoscibili senza cambiare gli identificativi salvati o il calcolo della modulazione. I progetti r7 mantengono quindi le stesse assegnazioni e lo stesso suono.

| Motore | Quattro destinazioni degli engine, nell’ordine |
| --- | --- |
| Knit | Wave, Detune, Voices, Width. |
| Rayon | Bright, Ratio, Edge, Tine. |
| Jacquard | Table, Scan, Bend, Ripple. |
| Bellows | Stops, Pedal, Rotor, Rate. |
| Cane | Model, Timbre, Color, Damp. |
| Voile | Model, Timbre, Color, Breath. |
| Sample | Sample, Start, Length, Mode. |
| Slice | Sample, Slices, Slice Pitch, Gate. |

Slice Pitch identifica il pitch del motore Slice ed è distinto dalla destinazione generale Pitch. Le selezioni discrete, come Model, Table, Voices o Mode, producono cambi a gradini secondo il motore; Scan, Bright, Timbre, Color e Wave sono adatte a esplorazioni timbriche continue. Il comportamento dei campioni e dei punti di lettura resta quello previsto dai rispettivi motori.

## How to: muovere Scan su Jacquard
1. Selezionare Jacquard e scegliere una tabella nella pagina EDIT.
2. Impostare un valore Scan intermedio e una nota sostenuta nel pattern.
3. Aprire LFO, raggiungere LFO A e scegliere Sine, Rate 1/2 e Restart Transport.
4. Nella pagina A Routes 1–2 scegliere Scan come Dest 1 e partire da Depth +20%.
5. Avviare e regolare la profondità. Con una seconda route si può muovere Cutoff con profondità negativa.

Lo stesso percorso permette di scegliere Bright su Rayon, Timbre su Cane, Color su Voile e Wave su Knit. Cambiare motore segue le normali operazioni di inizializzazione del suono: verificare e reimpostare le route dopo il cambio. Il mantenimento degli identificativi riguarda i progetti e le assegnazioni già salvate, non introduce una nuova modalità di cambio motore.

## Pace identifica il passo temporale della traccia
Nel sequencer, il terzo controllo della pagina Steps e la corrispondente voce SEL si chiamano PACE. Il termine viene usato anche nei messaggi e negli aiuti della pagina Bar. I valori e il funzionamento sono gli stessi del precedente controllo temporale Scale.

Pace 1 indica un sedicesimo per step; Pace 2 indica un ottavo; Pace 3 tre sedicesimi; Pace 4 un quarto; Pace 1/2 un trentaduesimo. Con sedici step e Pace 1 il pattern dura una battuta di 4/4; con Pace 2 dura due battute. Cambiare Pace modifica quindi anche la durata reale dei cicli usati da Every Cycles nell’Evolver.

Scale nel Conductor e Pitch Scale negli LFO mantengono invece il loro nome: riguardano le note ammesse dalla scala musicale. La r9 aggiorna le etichette e conserva il byte temporale del progetto, senza conversioni o cambi di velocità nei pattern esistenti.


---
# 27. Le nuove pagine SEQ: comandi e grafica
Sulle tracce melodiche di sintesi e Sample, premere SEQ e ruotare l’encoder SELECT scorre Steps → Bar → Generator → Evolver → Steps. Non serve premere SEL. Su Kit, Slice, MIDI e tracce ausiliarie restano le pagine compatibili già previste: il motore generativo melodico non viene applicato agli indici delle slice o ai bit dei kit.

Ogni pagina generativa ha tre banchi selezionabili dai primi tre tasti bianchi. Il banco corrente appare nell’angolo superiore destro. Il cambio banco non cambia pagina, traccia, pattern o contenuto musicale: mostra un altro gruppo di controlli sugli stessi quattro knob.

| Generator | Knob 1 / Knob 2 / Knob 3 / Knob 4 |
| --- | --- |
| Bianco 1: Main | Method / Density oppure Pulses / Rotation / Seed. |
| Bianco 2: Pitch | Low / High / Root Weight / Note Length. |
| Bianco 3: Feel | Velocity / Note Length / Root Weight / Seed. |

Note Length, Root Weight e Seed compaiono in più banchi per comodità: sono gli stessi valori, non due impostazioni indipendenti. Rotation agisce sul metodo Euclidean; Density agisce sul metodo Random. Con Euclidean il secondo knob cambia automaticamente etichetta in Pulses.

Il bianco 15 aumenta il Seed di uno, a trasporto fermo: la grafica propone un altro candidato. Il bianco 16 scrive il candidato nel primo pattern vuoto e seleziona la variante per la scena corrente. Dopo la scrittura il nuovo pattern contiene vere note modificabili in Steps; non è un’anteprima temporanea che sparisce uscendo dalla pagina.

| Evolver | Knob 1 / Knob 2 / Knob 3 / Knob 4 |
| --- | --- |
| Bianco 1: Motion | Mode / Cycles / Chance / Range. |
| Bianco 2: Limits | Return / Low / High / Seed. |
| Bianco 3: Protect | Step / Protect / Base / Evolved. Gli ultimi due sono letture della prima nota. |

Il bianco 14 commuta Freeze e On. Da Off, la pressione tenta di attivare Freeze; se non sono ancora state riservate le corsie necessarie, attivare prima da fermo. Il bianco 15 esegue Reset da fermo. Il bianco 16 cattura la variante in un pattern vuoto, sempre da fermo. Per Off usare il controllo Mode nel banco Motion.

## Leggere la grafica
Ogni casella è uno step; una casella senza segno di nota rappresenta una pausa. La griglia usa una, due, tre o quattro righe secondo la lunghezza del pattern. L’altezza del segno nella casella rappresenta la prima nota dello step nel registro Low–High. Negli accordi la grafica mostra la prima nota, non tutte le voci di un piano roll.

In Generator il segno colorato mostra il candidato calcolato con i parametri correnti. Non scrive note finché non si preme il bianco 16. La preview usa un calcolo locale: guardarla non avanza il generatore casuale dell’Evolver.

In Evolver il segno tenue indica la nota base e quello colorato la nota evoluta. Quando coincidono si vede soprattutto il segno colorato. Il piccolo indicatore chiaro sulla sommità della casella segnala la protezione. Una sottolineatura individua lo step selezionato nel banco Protect o il playhead durante la riproduzione.

La grafica non rappresenta il risultato finale di Conductor, arpeggiatore, LFO di pitch o trick: mostra la generazione e lo scostamento dell’Evolver. Una nota può quindi essere visualizzata stabile e suonare con vibrato, oppure essere arpeggiata in più attacchi.

---
# 28. LFO: esempi ragionati e diagnosi
## Metodo di lavoro
Partire da una sola traccia, una nota lunga, pochi effetti e una sola rotta attiva. Impostare il parametro base vicino al centro della zona utile: se il valore è già al massimo, metà della modulazione può essere limitata. Aggiungere la seconda rotta e il secondo LFO dopo aver riconosciuto il primo movimento.

Shape genera il movimento; Rate ne determina la velocità; Phase sceglie il punto iniziale; Restart decide quando ricomincia; Destination e Depth stabiliscono dove e quanto si sente. Una Depth del 25% non significa che il knob rimane al 25%: è l’ampiezza del contributo rispetto al valore base.

## Esempio 1: un pad Jacquard che attraversa la wavetable
Scegliere Jacquard, una tabella dal contenuto variato e Scan intorno a metà corsa. Inserire un accordo lungo. In LFO A impostare Sine, Rate 2/1, Phase 0 e Restart Transport; nella prima rotta scegliere Scan con Depth +20%. Suonare per almeno due battute e ascoltare il timbro cambiare senza modificare le note.

Con Saw Up il percorso procede in una direzione e torna bruscamente al punto iniziale; con Triangle sale e scende. Se il movimento sembra fermo, aumentare la durata dell’accordo o scegliere Free: Retrigger su note brevi può far ripetere soltanto l’inizio del ciclo. Se il cambiamento è troppo estremo, ridurre Depth prima di cambiare la tabella.

## Esempio 2: Bright su Rayon, apertura controllata
Scegliere Rayon e abbassare Bright finché il suono è morbido. LFO A Triangle a 1/1, Restart Transport, destinazione Bright +15%. Una seconda rotta Cutoff +10% può accompagnare l’aumento di brillantezza; iniziare senza la seconda rotta per distinguere il contributo FM da quello del filtro.

Bright e Volume non sono equivalenti: un timbro più ricco può sembrare più forte pur avendo lo stesso livello. Bilanciare il volume base dopo la scelta timbrica. Ratio è una scelta con un proprio comportamento per intervalli: modulandola il risultato può essere meno continuo di Bright.

## Esempio 3: Cane con timbro irregolare ma note stabili
Selezionare Cane e un modello adatto al materiale. Usare LFO A Drift lento, per esempio nella regione libera intorno a 0,1 Hz, su Timbre +10%; assegnare Color −8% alla seconda rotta. Lasciare Pitch e Pitch Scale disattivati.

Drift cerca nuovi valori casuali con transizioni morbide. Il risultato non è una ripetizione periodica identica a ogni ciclo. Una profondità negativa usa il medesimo segnale in senso opposto: quando aumenta il contributo a Timbre, diminuisce quello a Color. L’effetto dipende dal modello, quindi confrontare più modelli mantenendo piccole le profondità.

## Esempio 4: Voile, colore e respiro
Su Voile scegliere una nota sostenuta e lavorare sul bilanciamento Color/Breath di base. LFO A Sine a 1/2 su Color +12%; LFO B Drift molto lento su Breath +8%. Il primo porta un moto riconoscibile, il secondo evita che ogni giro sia identico.

Per una frase con aperture diverse su ogni nota usare Retrigger e una fase iniziale scelta consapevolmente. Per un tappeto continuo usare Free o Transport, evitando il riavvio a ogni attacco. I due LFO sono indipendenti: non aspettarsi che il Drift raggiunga sempre gli stessi valori del seno.

## Esempio 5: Knit, Wave e stereo
Impostare Knit con unisono moderato, Wave a metà zona e Width contenuto. LFO A Sine a 1/1: rotta 1 Wave +10%, rotta 2 Pan +25%. Il cambiamento di forma d’onda segue il movimento stereo. Se il suono diventa troppo stretto o aggressivo agli estremi, ridurre Wave Depth o spostare il suo valore base.

Per far muovere il filtro nel senso opposto usare una terza rotta Cutoff −15%. Le quattro rotte appartengono allo stesso LFO: sono correlate allo stesso istante, anche con intensità diverse. Non è necessario usare due oscillatori per ottenere destinazioni multiple.

## Esempio 6: controfase periodica e random complementare
Per due seni regolari impostare A e B con identici Rate e Restart Transport; Phase A a 0°, B a 180°. Assegnare una rotta di ciascuno al parametro desiderato. Se li si somma alla stessa destinazione con identica profondità, possono annullarsi: è un risultato atteso, non un LFO guasto.

Per un random esattamente opposto, usare invece due rotte dello stesso LFO Random, una positiva e una negativa. Due LFO Random separati hanno stati casuali indipendenti e una differenza di fase di 180° non li rende complementari. Il segno negativo inverte il valore; non aggiunge un ritardo temporale.

## Esempio 7: piccoli cambi di intonazione nella scala
Nel Conductor impostare C Minor. Su un pattern di note lunghe usare LFO B Random a 1/8D, destinazione Pitch Scale e Depth +10% per iniziare. Portare la profondità a +25% soltanto se serve un registro più ampio. Con pochi tasti della scala raggiungibili si sentiranno ripetizioni: la quantizzazione genera gradini.

Pitch Scale quantizza il pitch musicale risultante alla scala globale, anche se la traccia non segue gli accordi. Una nota base esterna alla scala può quindi cambiare già a una piccola profondità non nulla. Per vibrato continuo scegliere Pitch; per note casuali a gradini scegliere Pitch Scale. Bend e altri trattamenti continui possono ancora produrre scostamenti espressivi.

## Esempio 8: imparare a riconoscere il riavvio
Preparare otto note uguali corte. Su Cutoff usare Saw Up lento e una profondità evidente. Con Restart Retrigger ogni nota ricomincia dallo stesso punto: il filtro può sembrare un inviluppo ripetuto. Con Free il movimento attraversa tutte le note. Con Transport i diversi avvii del brano riallineano il disegno al Play.

Non aumentare subito Rate per compensare una durata troppo corta: decidere prima se si vuole un movimento per nota o una traiettoria che attraversa la frase. È la differenza più utile da chiarire quando un LFO sembra non fare ciò che ci si aspetta.

---
# 29. Generator: dalla proposta alla frase utilizzabile
## Preparazione comune
Scegliere una traccia melodica compatibile e una sorgente semplice. Impostare nel Conductor la tonalità e la scala; in Steps scegliere Length e Pace. Il generatore eredita queste impostazioni, oltre a groove, loop, trick e condizioni. Per la prima prova partire senza automazioni e senza protezioni.

Aprire Generator ruotando SELECT da Steps di due posizioni. La pagina non sostituisce la traccia mentre si gira un parametro: mostra un candidato. Il bianco 16 scrive una nuova variante nel primo pattern vuoto e ne aggiorna il riferimento nella scena corrente. Il pattern originale resta disponibile con il proprio numero.

## Esempio 1: cinque note distribuite su sedici
Impostare Length 16 e Pace 1. In Generator, banco Main: Method Euclid, Pulses 5, Rotation 0, Seed 1729. Nel banco Pitch scegliere Low C3, High C4, Root Weight 40 e Length 2/4; nel banco Feel scegliere Velocity 90.

La griglia mostra cinque posizioni attive quando nessuno step è protetto. Premere il bianco 16 e PLAY. L’insieme ha cinque trigger distribuiti nel ciclo; le altezze appartengono alla scala globale. La regolarità della distribuzione non implica una scala cromatica né cinque suoni diversi.

Tornare a Generator sulla variante e cambiare Rotation per spostare l’accento della figura. Se non si desidera creare un altro pattern, studiare prima la preview e generare una sola volta dopo aver scelto la rotazione.

## Esempio 2: una frase rarefatta con Random
Usare Method Random, Density 25%, Low C4 e High C5. Su sedici step, il numero medio atteso è quattro note, ma un singolo candidato può averne di più o di meno. La distribuzione è probabilistica per step: Density non imposta un numero esatto.

Da fermo premere il bianco 15 per aumentare il seed e confrontare più proposte nella griglia. Annotare un seed interessante oppure generare la variante per ascoltarla. A parità di sorgente, protezioni, scala e impostazioni, tornare al medesimo seed ricrea il medesimo candidato.

## Esempio 3: ostinato su una sola nota
Scegliere una nota appartenente alla scala, per esempio C3, e impostare Low e High entrambi a C3. Euclidean con 7 impulsi su 16 crea un ostinato ritmico su quella nota. Random con Density 60% crea una distribuzione meno regolare mantenendo la stessa altezza.

Il generatore non inventa altre note per riempire un registro troppo stretto. Se Low/High non comprendono alcuna nota valida della scala, le posizioni non protette diventano pause. Per una linea a due o tre note scegliere un intervallo che contenga esattamente quelle note della scala.

## Esempio 4: mantenere un accordo iniziale e generare la risposta
Scrivere l’accordo sul primo step in Steps. Aprire Evolver, banco Protect, scegliere Step 1 e mettere Protect On. Tornare a Generator. Provare Random a Density 35% e un registro sopra l’accordo. La prima casella conserva l’accordo intero; le altre ricevono nuove note singole.

La protezione conserva anche gli attributi dello step sorgente. Il generatore resta monofonico sulle posizioni nuove: non armonizza automaticamente tutte le note. Il numero finale di trigger può differire da Pulses perché gli step protetti vengono conservati invece di essere riscritti.

## Esempio 5: call and response con due scene
Preparare una frase breve e creare una seconda scena. Sulla traccia selezionata usare Generator per scrivere la risposta in un pattern vuoto. Verificare che la scena A richiami il pattern originale e la B quello nuovo; se condividono ancora il medesimo numero di pattern, correggere il riferimento prima di modificare le note.

Ridurre Density o Pulses nella risposta per lasciare spazio; usare un registro più alto per distinguerla. Il suono della traccia resta condiviso fra le scene. Per cambiare timbro soltanto in alcune parti servono le automazioni o una diversa traccia, non soltanto un’altra scena.

## Esempio 6: generazione e arpeggiatore
Generare una sequenza di note relativamente lunghe, poi attivare Strum o Arp. Il generatore scrive le note base; il player le trasforma durante l’esecuzione. Se si desidera ascoltare chiaramente il candidato appena creato, spegnere temporaneamente il player.

Un ratchet, una condizione A:B o un arp possono far ascoltare un numero di attacchi diverso dalle caselle attive della preview. La grafica non è errata: mostra il materiale generato prima di queste trasformazioni. Controllare anche Hold del player quando sembra che le note proseguano oltre la durata prevista.

## Esempio 7: passare dal generato all’editing manuale
Dopo la scrittura premere SEQ per tornare a Steps. Modificare velocity, durata o qualche altezza come su un normale pattern. Proteggere gli step migliori prima di una nuova generazione. In questo modo le proposte successive lavorano attorno a punti scelti manualmente.

Ogni scrittura richiede un pattern senza note e può richiedere corsie per copiare le automazioni. Fermarsi quando gli slot stanno finendo, ascoltare le varianti e conservare quelle utili. Un pattern senza note può essere richiamato da altre scene o avere ancora lock: controllarlo prima di considerarlo sacrificabile.

---
# 30. Evolver: conservare identità e creare variazioni
## Capire i quattro livelli di controllo
Cycles decide quando uno step può essere rivalutato; Chance decide se l’aggiornamento avviene; Range limita la distanza cumulativa dall’originale; Return decide se un aggiornamento accettato torna allo scostamento zero. Non sono quattro modi equivalenti di impostare la quantità di random.

L’originale rimane nei dati del pattern. L’Evolver conserva uno scostamento per step e lo applica al nuovo attacco. Una mutazione ordinaria compie un passo di un grado della scala, non un salto casuale su tutto il registro. Uno stesso step può quindi allontanarsi lentamente e poi tornare indietro.

## Esempio 1: prova evidente senza perdere la frase
Scrivere quattro note su sedici step. Banco Motion: Mode On, Cycles 1, Chance 100, Range 2. Banco Limits: Return 0 e un registro abbastanza largo da contenere le variazioni. Avviare e ascoltare almeno tre giri.

Il primo giro mantiene lo stato iniziale. Dal successivo, gli step idonei vengono aggiornati quando vengono triggerati. Gli attacchi non cambiano tutti insieme all’inizio del giro. Alcune variazioni successive possono annullarsi o raggiungere un limite: anche con Chance 100 non è garantito che ogni giro sembri completamente diverso.

Da fermo premere il bianco 15 per Reset e ripartire. Lo scostamento viene azzerato e il generatore casuale reimpostato al seed; non vengono cambiati timbro, mix o LFO. Se Mode resta On, l’evoluzione riprenderà dopo il nuovo primo ciclo.

## Esempio 2: basso conservativo
Proteggere la prima nota della frase e, se necessario, un secondo appoggio. Impostare Cycles 4, Chance 25, Range 2, Return 20 e un registro adatto al basso. Lasciare suonare a lungo: questa impostazione è intenzionalmente lenta e non deve cambiare ogni battuta.

A 70 BPM, sedici step con Pace 1 durano circa 3,43 secondi. Quattro cicli durano circa 13,71 secondi: i primi aggiornamenti arrivano durante il giro successivo a quei quattro cicli completati. Con Pace 2 il ciclo dura il doppio e anche l’intervallo reale di evoluzione raddoppia.

Se il pattern ha una lunghezza diversa, un loop ridotto o trick Jump, non usare automaticamente il conteggio delle battute della Song come equivalente di Cycles. Il riferimento resta il ciclo del pattern di quella traccia.

## Esempio 3: ritorni frequenti al tema
Usare Cycles 1, Chance 50, Range 4 e Return 70. Le variazioni possono allontanarsi, ma molti aggiornamenti accettati riportano lo step alla base. Return 100 non significa ripristino immediato: il ritorno avviene soltanto quando lo step raggiunge un aggiornamento idoneo e supera Chance.

Per tornare subito alla frase base senza cancellare la variante usare Mode Off. Per cancellare gli scostamenti usare Reset da fermo. Per continuare ad ascoltare la variante senza nuove mutazioni usare Freeze. Sono tre operazioni con conseguenze diverse.

## Esempio 4: fermare una variante nel punto giusto
Mentre il pattern evolve, premere il bianco 14 nella pagina Evolver. Mode passa a Freeze e le note evolute correnti continuano a essere suonate. Lasciare scorrere un altro giro per valutare la frase completa: l’ultimo aggiornamento può essere avvenuto su uno step diverso da quello che si stava ascoltando.

Fermare PLAY e premere il bianco 16. Capture crea una nuova versione con gli scostamenti scritti nelle note base; nella copia l’Evolver è Off. Tornare a Steps e rifinire la variante. Salvare il progetto dopo aver controllato quale pattern usa la scena.

## Esempio 5: protezione durante la rifinitura
Nel banco Protect scegliere uno step con Knob 1. Knob 3 e Knob 4 mostrano la prima nota originale ed evoluta: servono a capire lo scostamento prima di catturare. Mettere Protect On con Knob 2 riporta quello step alla base rispetto all’Evolver e gli impedisce nuove mutazioni.

Se si vuole rendere permanente proprio la nota evoluta di quello step, non proteggerla prima di averla catturata: la protezione la riporta alla base. Usare prima Freeze e Capture, poi proteggere la nota nella copia. La protezione non blocca i normali interventi manuali o le modulazioni esterne all’Evolver.

## Esempio 6: una sequenza armonica a più voci
Inserire alcuni accordi. Ogni step riceve un unico scostamento in gradi della scala, applicato alle sue note. Le voci tendono quindi a muoversi insieme, ma ai limiti Low/High possono essere contenute o avvicinate. Non è un algoritmo di voice leading che ottimizza separatamente ogni voce.

Usare Range 1 o 2, Return moderato e un registro largo per mantenere la riconoscibilità. Se un accordo diventa troppo compresso agli estremi, allargare Low/High o ridurre Range. La grafica e le letture Base/Evolved mostrano soltanto la prima nota: ascoltare l’intero accordo.

## Esempio 7: pausa evolutiva durante una performance
Usare Freeze per mantenere un ritornello mentre il resto del brano cambia scena. Tornare a On quando si desiderano nuove mutazioni. La sospensione non accumula una coda di cambiamenti da applicare tutta al ritorno.

Un pattern inattivo conserva il proprio stato; non evolve in segreto mentre suona un altro pattern. Stop conserva gli scostamenti, ma una ripartenza da Play ricomincia il conteggio dei cicli. Il salvataggio conserva lo stato raggiunto, non la posizione di una nota a metà esecuzione.

## Esempio 8: perché non cambia niente?
Controllare prima Mode, Cycles e il numero di giri realmente completati. Poi verificare Chance, Range, protezioni e registro. Gli step vuoti o non eseguiti non producono nuove mutazioni; mute, condizioni e registrazione possono sospenderle. Weave, quando fornisce materiale incrociato, non riceve questa trasformazione melodica.

Un registro con una sola nota utile può rendere indistinguibili scostamenti interni diversi. Un LFO di pitch o un arpeggiatore può invece nascondere l’effetto dell’Evolver. Per diagnosticare, provare una nota breve ripetuta, player Off, LFO di pitch spenti e Cycles 1 / Chance 100 / Return 0.

---
# 31. Combinare i processi e lavorare senza confusione
## Chi cambia che cosa
Generator scrive nuove note in un nuovo pattern. Evolver cambia temporaneamente l’altezza dei nuovi attacchi rispetto alla base. LFO A/B muovono i parametri assegnati nel tempo. Arp e Strum trasformano il materiale del player; Conductor guida il contesto musicale; gli effetti trattano il segnale audio.

Per costruire una parte complessa, introdurre questi livelli uno alla volta. Prima scegliere il ritmo generato, poi l’evoluzione delle note, poi il movimento timbrico e infine gli effetti. Questo ordine permette di riconoscere la causa di un cambiamento e di riprodurre il risultato quando serve.

## Ricetta: trama ambient a 70 BPM
Generare su Jacquard una frase di sedici step, Pace 2, Random a Density 25%, registro C3–C5 e durata 4/4 step. Scegliere una scala globale adatta, per esempio C Minor. Ascoltare il pattern senza arp e scegliere un seed utile.

Attivare Evolver con Cycles 4, Chance 20, Range 2 e Return 30. Aggiungere LFO A Sine lento su Scan +15% e LFO B Drift su Pan +15%. Usare FX I Delay a 1/8D, Fine 50, feedback moderato e Ping-Pong On; inviare una piccola quantità al riverbero.

L’evoluzione è lenta perché il pattern con Pace 2 dura due battute. I cambi timbrici degli LFO continuano fra un aggiornamento delle note e il successivo. Freeze dell’Evolver ferma soltanto nuove mutazioni melodiche: Scan e Pan continuano a muoversi.

## Ricetta: ostinato con centro stabile e contorno mobile
Generare cinque impulsi euclidei su sedici con Low/High sulla stessa nota. Dopo la scrittura, allargare il registro dei limiti per l’Evolver e proteggere uno o due appoggi. Usare Cycles 2, Chance 35, Range 1 e Return 50.

Con Knit assegnare un LFO lento a Wave con profondità contenuta e un altro al Pan. L’ostinato inizialmente monofonico può acquisire piccole variazioni di altezza; gli appoggi protetti restano la base dell’Evolver. Se si desidera una sola altezza permanente, lasciare invece l’Evolver Off e usare soltanto i movimenti timbrici.

## Ricetta: trovare tre sezioni da una stessa idea
Scrivere o generare una frase iniziale. Farla evolvere e catturare una prima variante. Tornare al pattern sorgente, riprendere On, attendere e catturare una seconda variante. Assegnare originale e due catture a tre scene distinte.

Le catture sono materiale scritto, quindi si possono rifinire senza dipendere dal punto casuale raggiunto durante la performance. Il timbro resta condiviso sulla traccia: per differenziare il suono delle sezioni registrare automazioni appropriate o usare un’altra traccia.

## Checklist pratica prima di salvare
Fermare il trasporto, verificare il pattern selezionato e il riferimento della scena, ascoltare la variante e premere SAVE. Se si vuole tornare a una base precisa, annotare numero del pattern, seed, scala e impostazioni principali. Esportare un backup dopo le sessioni importanti.

Il formato 19 resta condiviso fra r7, r8 e r9. Le pagine e i banchi dell’interfaccia non richiedono un nuovo formato musicale. Per tornare alla r6 serve invece un backup precedente compatibile. Le prove software non sostituiscono la verifica del comportamento e del carico sul dispositivo fisico.

---
# 32. Schermate di riferimento

![Delay 1/8D a 70 BPM](assets/Delay-1-8D-70BPM.png)

![Arpeggiatore 1/4D](assets/arp_1_4d_70.png)

![Pan per step](assets/step_pan_left.png)

![Ping-Pong attivo](assets/pingpong_on.png)

![LFO A](assets/xmod_a.png)

![Assegnazioni LFO A](assets/xmod_a_routes.png)

![Pitch Scale](assets/xmod_b_scale.png)

![LFO dopo riavvio](assets/xmod_reloaded.png)

# 33. Generator ed Evolver: menu alternativi

![Generator Euclidean](assets/generator_euclidean.png)

![Nuovo pattern generato](assets/generated_pattern.png)

![Evolver attivo](assets/evolver_on.png)

![Evolver congelato](assets/evolver_freeze.png)

# 34. Engine e Pace sullo schermo

![Scan su Jacquard](assets/jacquard_scan.png)

![Bright su Rayon](assets/rayon_bright.png)

![Timbre su Cane](assets/cane_timbre.png)

![Color su Voile](assets/voile_color.png)

![Wave su Knit](assets/knit_wave.png)

![Pace temporale](assets/track_pace.png)

![Scale musicale](assets/conductor_scale.png)

# 35. Le pagine grafiche della r9

![Generator Main](assets/generator_main.png)

![Generator Pitch](assets/generator_pitch.png)

![Evolver Freeze](assets/evolver_freeze_graphic.png)

![Evolver Protect](assets/evolver_protect.png)

![Delay Ping-Pong On](assets/delay_graphic_on.png)

![Delay Ping-Pong Off](assets/delay_graphic_off.png)

