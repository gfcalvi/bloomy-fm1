/* SPDX-License-Identifier: MPL-2.0 */
/* Included in seq.c after the scale helpers. All mutation work is bounded per encountered step;
 * ratchets/pulse repeats never advance evolution. Each pattern owns its persisted RNG. */
const uint8_t EV_DEFAULT[EV_NFIELD] = {0,2,25,2,15,48,84,193,6,0,0,0,0,0,50,5,0,40,2,90};
const uint8_t EV_MAX[EV_NFIELD] = {2,5,100,12,100,127,127,255,255,255,255,255,255,1,100,64,63,100,64,127};
int evo_get(const lane_t *L,int t,int p,int f)
{
    int k,v;
    if(f<0 || f>=EV_NFIELD) return 0;
    k=lane_find(L,t,p,LANE_EV_CFG);
    v=k<0 ? EV_DEFAULT[f] : L[k].val[f];
    return v>EV_MAX[f] ? EV_DEFAULT[f] : v;
}
static int evo_cfg(lane_t *L,int t,int p)
{
    int k=lane_find(L,t,p,LANE_EV_CFG);
    if(k<0) {
        k=lane_alloc(L,t,p,LANE_EV_CFG);
        if(k>=0) for(int i=0;i<EV_NFIELD;i++) L[k].val[i]=EV_DEFAULT[i];
    }
    return k;
}
int evo_prepare(lane_t *L,int t,int p)
{
    int had=lane_find(L,t,p,LANE_EV_CFG), k=evo_cfg(L,t,p);
    if(k<0) return 0;
    if(lane_alloc(L,t,p,LANE_EV_STEP)<0) {
        if(had<0) lane_clear(L,k);
        return 0;
    }
    return 1;
}
int evo_set(lane_t *L,int t,int p,int f,int v)
{
    int k;
    if(t<0 || t>=NTRK || p<0 || p>=NPATT || f<0 || f>=EV_NFIELD) return 0;
    if(f==EV_MODE && v && !evo_prepare(L,t,p)) return 0;
    k=evo_cfg(L,t,p); if(k<0) return 0;
    L[k].val[f]=(uint8_t)(v<0?0:v>EV_MAX[f]?EV_MAX[f]:v);
    if(f==EV_SEED_LO || f==EV_SEED_HI) for(int i=EV_RNG0;i<=EV_RNG3;i++) L[k].val[i]=0;
    return 1;
}
int evo_protected(const lane_t *L,int t,int p,int s)
{
    int k=lane_find(L,t,p,LANE_EV_STEP),v;
    if(k<0 || s<0 || s>=NSTEP) return 0;
    v=L[k].val[s]; return v!=LOCK_NONE && (v&128)!=0;
}
int evo_protect(lane_t *L,int t,int p,int s,int on)
{
    int k,v;
    if(t<0 || t>=NTRK || p<0 || p>=NPATT || s<0 || s>=NSTEP) return 0;
    k=lane_alloc(L,t,p,LANE_EV_STEP); if(k<0) return 0;
    v=L[k].val[s]; if(v==LOCK_NONE) v=64;
    /* Protection is immediately original, even if the step was already evolved. */
    L[k].val[s]=(uint8_t)(on?192:(v&127)); return 1;
}
int evo_offset(const lane_t *L,int t,int p,int s)
{
    int k,v;
    if(s<0 || s>=NSTEP || !evo_get(L,t,p,EV_MODE)) return 0;
    k=lane_find(L,t,p,LANE_EV_STEP); if(k<0) return 0;
    v=L[k].val[s];
    if(v==LOCK_NONE || (v&128)) return 0;
    v=(v&127)-64; return v < -12 ? -12 : v>12 ? 12 : v;
}
void evo_reset(lane_t *L,int t,int p)
{
    int k=lane_find(L,t,p,LANE_EV_STEP);
    if(k>=0) for(int i=0;i<NSTEP;i++) L[k].val[i]=evo_protected(L,t,p,i)?192:LOCK_NONE;
    k=lane_find(L,t,p,LANE_EV_CFG);
    if(k>=0) for(int i=EV_RNG0;i<=EV_RNG3;i++) L[k].val[i]=0;
}
static uint32_t evo_rng(lane_t *l)
{
    uint32_t x=0;
    for(int i=0;i<4;i++) x|=(uint32_t)l->val[EV_RNG0+i]<<(i*8);
    if(!x) x=(((uint32_t)l->val[EV_SEED_HI]<<8)|l->val[EV_SEED_LO])+0x9E3779B9u;
    x^=x<<13; x^=x>>17; x^=x<<5;
    for(int i=0;i<4;i++) l->val[EV_RNG0+i]=(uint8_t)(x>>(i*8));
    return x;
}
int evo_update(patterns_t *P,int t,int p,int s,unsigned pass)
{
    int k,d,v,a;
    if(!pass || evo_get(P->lane,t,p,EV_MODE)!=1 ||
       pass% (1u<<evo_get(P->lane,t,p,EV_RATE)) || evo_protected(P->lane,t,p,s)) return 0;
    k=lane_find(P->lane,t,p,LANE_EV_CFG); if(k<0) return 0;
    if(evo_rng(&P->lane[k])%100u >= (unsigned)evo_get(P->lane,t,p,EV_CHANCE)) return 1;
    d=lane_find(P->lane,t,p,LANE_EV_STEP); if(d<0) return 1;
    v=evo_offset(P->lane,t,p,s); a=evo_get(P->lane,t,p,EV_AMOUNT);
    if(evo_rng(&P->lane[k])%100u < (unsigned)evo_get(P->lane,t,p,EV_RETURN)) v=0;
    else {
        v+=(evo_rng(&P->lane[k])&1u)?1:-1;
        if(v>a) v=a; if(v < -a) v=-a;
    }
    P->lane[d].val[s]=(uint8_t)(v+64); return 1; /* RNG also changed when no pitch changed */
}
int evo_note(const lane_t *L,int t,int p,int s,int note,int key,int scale)
{
    int d=evo_offset(L,t,p,s),lo,hi,n;
    if(!d || !note) return note;
    lo=evo_get(L,t,p,EV_LOW); hi=evo_get(L,t,p,EV_HIGH); if(hi<lo) hi=lo;
    n=scale_step(note,key,scale,d);
    /* Clamp to an actual scale note inside the requested range. Empty ranges keep original. */
    for(int i=lo;i<=hi;i++) if(in_scale(i,key,scale_mask(scale))) {
        int last=i;
        for(int j=i;j<=hi;j++) if(in_scale(j,key,scale_mask(scale))) {
            last=j; if(j>=n) {
                if(n<i) return i;
                return j;
            }
        }
        return last;
    }
    return note;
}
void evo_generate(tpat_t *out,const tpat_t *src,const lane_t *L,int t,int p,int key,int scale)
{
    uint8_t notes[128]; int count=0,lo=evo_get(L,t,p,EV_LOW),hi=evo_get(L,t,p,EV_HIGH);
    int len=src->len<1?1:src->len>NSTEP?NSTEP:src->len;
    int pulses=evo_get(L,t,p,GEN_PULSES),rot=evo_get(L,t,p,GEN_ROTATE)%len;
    uint32_t rng=(uint32_t)evo_get(L,t,p,EV_SEED_LO)|((uint32_t)evo_get(L,t,p,EV_SEED_HI)<<8);
    rng+=0x9E3779B9u;
    if(hi<lo) hi=lo;
    for(int n=lo;n<=hi;n++) if(n && in_scale(n,key,scale_mask(scale))) notes[count++]=(uint8_t)n;
    *out=*src;
    if(pulses>len) pulses=len;
    for(int s=0;s<len;s++) {
        int play,idx=(s-rot+len)%len,note;
        if(evo_protected(L,t,p,s)) continue;
        rng_next(&rng);
        play=evo_get(L,t,p,GEN_METHOD)? ((idx*pulses)%len < pulses) :
             ((rng%100u)<(unsigned)evo_get(L,t,p,GEN_DENSITY));
        for(int j=0;j<SN;j++) out->st[s].note[j]=0;
        if(!play || !count) continue;
        note=notes[rng_next(&rng)%(unsigned)count];
        if(rng_next(&rng)%100u<(unsigned)evo_get(L,t,p,GEN_ROOT)) {
            int root=key+12*((note-key)/12);
            if(root>=lo && root<=hi && root>0) note=root;
        }
        out->st[s].note[0]=(uint8_t)note;
        out->st[s].vel=(uint8_t)evo_get(L,t,p,GEN_VELOCITY);
        out->st[s].len=(uint8_t)evo_get(L,t,p,GEN_LENGTH);
    }
}

/* r9.6: independent 16-cell, monophonic stochastic loops. Track-wide pat=255
 * keeps a scene/pattern switch, copy, clear or Generator from replacing the loop. */
static const uint8_t TM_DEF[TM_NFIELD]={0,10,16,50,48,84,50,90,2,0,0,0};
static const uint8_t TM_MAX[TM_NFIELD]={2,100,16,100,127,127,100,127,64,11,9,15};
__attribute__((minsize)) int tm_lane(const lane_t *L,int t) { return lane_find(L,t,255,LANE_TURING); }
__attribute__((minsize)) int tm_get(const lane_t *L,int t,int f)
{
    int k=tm_lane(L,t);
    return k<0 || L[k].val[f]>TM_MAX[f] ? TM_DEF[f] : L[k].val[f];
}
__attribute__((minsize)) void tm_draw(uint8_t *v,int pos,uint32_t *rng)
{
    int lo=v[TM_LOW],hi=v[TM_HIGH],count=0,note=0,pick;
    if(hi<lo) hi=lo;
    if(rng_next(rng)%100u < v[TM_DENSITY]) {
        for(int n=lo;n<=hi;n++) if(n && in_scale(n,v[TM_KEY],scale_mask(v[TM_SCALE]))) count++;
        pick=count?(int)(rng_next(rng)%(unsigned)count):0;
        for(int n=lo;n<=hi;n++) if(n && in_scale(n,v[TM_KEY],scale_mask(v[TM_SCALE])) && !pick--) {note=n;break;}
        if(note && rng_next(rng)%100u<v[TM_ROOT]) {
            int root=v[TM_KEY]+12*((note-v[TM_KEY])/12);
            if(root>0 && root>=lo && root<=hi && in_scale(root,v[TM_KEY],scale_mask(v[TM_SCALE]))) note=root;
        }
    }
    v[16+pos]=(uint8_t)note; v[32+pos]=v[TM_DUR]; v[48+pos]=v[TM_VEL];
}
__attribute__((minsize)) int tm_set(lane_t *L,int t,int p,int f,int v,int key,int scale)
{
    int k=tm_lane(L,t);
    if(t<0 || t>=NTRK || f<0 || f>=TM_POS) return 0;
    if(k<0) {
        k=lane_alloc(L,t,255,LANE_TURING); if(k<0) return 0;
        /* lane_alloc publishes all-FF: invalid mode stays OFF until initialization ends. */
        for(int i=1;i<TM_NFIELD;i++) L[k].val[i]=TM_DEF[i];
        {static const uint8_t map[]={TM_LOW,EV_LOW,TM_HIGH,EV_HIGH,TM_DENSITY,GEN_DENSITY,TM_ROOT,GEN_ROOT,TM_VEL,GEN_VELOCITY,TM_DUR,GEN_LENGTH};
        for(int i=0;i<12;i+=2)L[k].val[map[i]]=(uint8_t)evo_get(L,t,p,map[i+1]);}
        L[k].val[TM_KEY]=(uint8_t)key; L[k].val[TM_SCALE]=(uint8_t)scale;
        L[k].val[12]=0; L[k].val[13]=0;
        for(int i=0;i<16;i++) {L[k].val[16+i]=0;L[k].val[32+i]=2;L[k].val[48+i]=90;}
        __asm__ volatile("" ::: "memory"); L[k].val[TM_MODE]=0;
    }
    if(v<0)v=0;if(v>TM_MAX[f])v=TM_MAX[f];
    if((f==TM_LEN || f==TM_VEL || f==TM_DUR) && !v)v=1;
    if(f==TM_LOW && v>L[k].val[TM_HIGH])v=L[k].val[TM_HIGH];
    if(f==TM_HIGH && v<L[k].val[TM_LOW])v=L[k].val[TM_LOW];
    if(f==TM_MODE && v && !L[k].val[12]) {
        uint32_t rng=(uint32_t)evo_get(L,t,p,EV_SEED_LO)+256u*(uint32_t)evo_get(L,t,p,EV_SEED_HI)+0x9E3779B9u*(uint32_t)(t+1);
        for(int i=0;i<16;i++)tm_draw(L[k].val,i,&rng);
        L[k].val[12]=1;
    }
    if(f==TM_MODE && v!=2)L[k].val[13]=0;
    L[k].val[f]=(uint8_t)v; return 1;
}

/* Called at a Turing loop boundary in the audio owner, or while stopped.
 * No scratch pattern and no concurrent partial overwrite of a playing pattern. */
__attribute__((minsize)) int tm_capture(patterns_t *P,int t,int pat)
{
    int k=tm_lane(P->lane,t);tpat_t *tp;uint8_t *v,*z;
    if(k<0 || pat<0 || pat>=NPATT || P->lane[k].val[TM_MODE]!=2)return 0;
    v=P->lane[k].val;tp=&P->pat[t][pat];
    z=(uint8_t*)tp->st;for(unsigned i=0;i<sizeof tp->st;i++)z[i]=0;
    tp->len=v[TM_LEN];tp->lstart=tp->lend=0;
    for(int i=0;i<tp->len;i++) {
        tp->st[i].note[0]=v[16+i];tp->st[i].vel=v[48+i];
        tp->st[i].len=v[32+i]>4?4:v[32+i]; /* the actual one-gate-at-a-time duration */
    }
    for(int i=0;i<NLANE;i++)if(P->lane[i].used && P->lane[i].trk==t && P->lane[i].pat==pat)lane_clear(P->lane,i);
    v[13]=2;return 1;
}
