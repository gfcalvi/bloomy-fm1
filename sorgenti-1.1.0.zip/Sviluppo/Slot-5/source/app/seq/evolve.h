/* SPDX-License-Identifier: MPL-2.0 */
#pragma once
/* Stored in one config lane and one step lane per participating pattern. No new pattern array. */
enum { EV_MODE, EV_RATE, EV_CHANCE, EV_AMOUNT, EV_RETURN, EV_LOW, EV_HIGH,
       EV_SEED_LO, EV_SEED_HI, EV_RNG0, EV_RNG1, EV_RNG2, EV_RNG3,
       GEN_METHOD, GEN_DENSITY, GEN_PULSES, GEN_ROTATE, GEN_ROOT, GEN_LENGTH, GEN_VELOCITY, EV_NFIELD };
extern const uint8_t EV_DEFAULT[EV_NFIELD], EV_MAX[EV_NFIELD];
int evo_get(const lane_t *L, int trk, int pat, int field);
int evo_set(lane_t *L, int trk, int pat, int field, int value);
int evo_prepare(lane_t *L, int trk, int pat);
int evo_protected(const lane_t *L, int trk, int pat, int step);
int evo_protect(lane_t *L, int trk, int pat, int step, int on);
int evo_offset(const lane_t *L, int trk, int pat, int step);
void evo_reset(lane_t *L, int trk, int pat);
int evo_note(const lane_t *L, int trk, int pat, int step, int note, int key, int scale);
int evo_update(patterns_t *P, int trk, int pat, int step, unsigned pass);
/* Out must differ from source. Generator preserves protected steps, explicit locks copied by caller. */
void evo_generate(tpat_t *out, const tpat_t *src, const lane_t *L, int trk, int pat, int key, int scale);

/* One 64-byte track-wide record in the existing lane pool: no pattern overwritten.
 * 16 notes, 16 stored durations, 16 stored velocities. Byte controls are live-safe. */
enum { TM_MODE, TM_MUTATE, TM_LEN, TM_DENSITY, TM_LOW, TM_HIGH, TM_ROOT,
       TM_VEL, TM_DUR, TM_KEY, TM_SCALE, TM_POS, TM_NFIELD };
int tm_lane(const lane_t *L, int t);
int tm_get(const lane_t *L, int t, int f);
int tm_set(lane_t *L, int t, int p, int f, int v, int key, int scale);
void tm_draw(uint8_t *v, int pos, uint32_t *rng);

int tm_capture(patterns_t *P, int t, int pat); /* replaces only that pattern; Turing stays frozen */
