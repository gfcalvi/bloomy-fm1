/* SPDX-License-Identifier: MPL-2.0 */
/* Blue's independent control oscillators. No audio-rate work and no heap allocations. */
#ifndef LOOM_XMOD_H
#define LOOM_XMOD_H
#include <stdint.h>
#include "fastmath.h"
#define XM_LFOS 2
#define XM_FIELDS 12
#define XM_ROUTES 4
#define XM_SLOTS 8
#define XM_SYNC 11
enum { XM_OFF, XM_SINE, XM_TRI, XM_UP, XM_DOWN, XM_SQUARE, XM_RANDOM, XM_DRIFT, XM_SHAPES };
enum { XD_OFF, XD_PAN, XD_PITCH, XD_SCALE, XD_CUT, XD_RES, XD_VOLUME, XD_SEND1, XD_SEND2, XD_CHAR,
       XD_E1, XD_E2, XD_E3, XD_E4, XD_A, XD_D, XD_S, XD_R, XD_FENV, XD_LAYER_LEVEL, XD_LAYER_CUT, XD_LAYER_PITCH, XM_DESTS };
typedef struct { float ph, rnd, smooth; uint32_t rng; uint8_t reset, shape, phase; } xm_state_t;
typedef struct {
    xm_state_t state[8][XM_LFOS];
    int16_t out[8][XM_SLOTS][XM_DESTS]; /* Q4 knob units, sum first, clamp only at destination */
    uint8_t lock[8][XM_LFOS * XM_FIELDS];
    uint8_t layer_lock[8][6];
    uint8_t quant[8], active[8], key;
    uint16_t mask;
} xm_bank_t;
static inline uint32_t xm_rng(uint32_t *v)
{
    uint32_t x = *v ? *v : 0x9E3779B9u;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5; return *v = x;
}
static inline float xm_random(xm_state_t *s)
{
    return 2.0f * (float)(xm_rng(&s->rng) >> 8) * (1.0f / 16777216.0f) - 1.0f;
}
static inline float xm_hz(int rate, float bpm)
{
    static const float beats[XM_SYNC] = {8,4,2,1.5f,1,0.75f,0.5f,0.375f,0.25f,0.125f,0.0625f};
    return rate < XM_SYNC ? bpm / (60.0f * beats[rate < 0 ? 0 : rate]) :
        0.02f * fm_exp2f((float)(rate - XM_SYNC) * (9.96578428f / 116.0f));
}
static inline float xm_wave(int shape, float ph, float rnd, float smooth)
{
    switch (shape) {
    case XM_SINE: return fm_sin_turns(ph);
    case XM_TRI: return ph < 0.5f ? ph * 4.0f - 1.0f : 3.0f - ph * 4.0f;
    case XM_UP: return 2.0f * ph - 1.0f;
    case XM_DOWN: return 1.0f - 2.0f * ph;
    case XM_SQUARE: return ph < 0.5f ? 1.0f : -1.0f;
    case XM_RANDOM: return rnd;
    case XM_DRIFT: return smooth;
    default: return 0.0f;
    }
}
static inline float xm_tick(xm_state_t *s, const uint8_t *cfg, float bpm, float dt)
{
    int sh = cfg[0] < XM_SHAPES ? cfg[0] : XM_OFF;
    float dp = xm_hz(cfg[1], bpm) * dt;
    if (!sh) { s->shape = 0; return 0.0f; }
    if (s->reset || !s->shape) {
        s->ph = (float)cfg[2] * (1.0f / 128.0f);
        s->rnd = xm_random(s); s->smooth = s->rnd; s->reset = 0;
    } else if (cfg[2] != s->phase) {
        s->ph += ((float)cfg[2] - (float)s->phase) * (1.0f / 128.0f);
        if (s->ph < 0) s->ph += 1;
        if (s->ph >= 1) s->ph -= 1;
    }
    s->shape = (uint8_t)sh; s->phase = cfg[2];
    /* Evaluate before advancing: retrigger starts at the exact requested phase. */
    s->smooth += (s->rnd - s->smooth) * fm_minf(4.0f * dp, 1.0f);
    { float v = xm_wave(sh, s->ph, s->rnd, s->smooth);
      s->ph += dp;
      while (s->ph >= 1.0f) { s->ph -= 1.0f; s->rnd = xm_random(s); }
      return v;
    }
}
/* Nearest absolute scale note, including root. Tie goes down. Does not touch bends/vibrato. */
static inline float xm_quantize(float note, int key, uint16_t mask)
{
    int n = (int)fm_floorf(note);
    if(n<1)n=1; if(n>127)n=127;
    int best = n;
    float distance = 1000.0f;
    if (!mask) return note;
    for (int k = n - 12; k <= n + 13; k++) {
        int pc = ((k - key) % 12 + 12) % 12;
        float d = fm_fabsf(note - (float)k);
        if (k >= 1 && k <= 127 && (mask >> pc & 1u) && d < distance) { best = k; distance = d; }
    }
    return (float)(best < 1 ? 1 : best > 127 ? 127 : best);
}
#endif
