/* SPDX-License-Identifier: MPL-2.0 */
/* Tweed: shared pure-synthesis core. Existing per-voice storage only, no allocation.
 * s: carrier phase, inharmonic phase, pitch transient, amplitude, attack ramp.
 * c: base increment, excess increment, chirp multiplier, amplitude multiplier.
 * Frequency falls exponentially to base in 0.25 ms (tau); amplitude -60dB in
 * 12 ms..2 s. Two inharmonic sines, ratio sqrt(2), bounded below Nyquist.
 * Transcendentals run at control rate only; phase never exceeds one turn. */
#pragma once
#include "fastmath.h"
static inline void tweed_coeff(float *c, float hz, float depth, float decay)
{
    float base = fm_clampf(hz, 12.0f, 11000.0f) * (1.0f / 44100.0f);
    c[0] = base;
    c[1] = fm_minf(base * (fm_exp2f(7.0f * depth) - 1.0f), 0.30f - base);
    c[2] = 0.9133007f; /* exp(-1 / (44100 * 0.00025)) */
    c[3] = fm_expf(-6.9077553f / (44100.0f * (0.012f * fm_exp2f(7.38082f * decay))));
}
static inline void tweed_trigger(float *s)
{ s[0]=s[1]=s[4]=0.0f; s[2]=s[3]=1.0f; }
static inline float tweed_tick(float *s, const float *c)
{
    float inc = c[0] + c[1] * s[2];
    float y = (0.72f * fm_sin_turns(s[0]) + 0.28f * fm_sin_turns(s[1])) * s[3] * s[4];
    s[0] += inc; if(s[0]>=1.0f) s[0]-=1.0f;
    s[1] += inc * 1.41421356f; if(s[1]>=1.0f) s[1]-=1.0f;
    s[2] *= c[2]; s[3] *= c[3];
    if(s[4]<1.0f) s[4]=fm_minf(1.0f,s[4]+0.125f);
    if(s[2]<1e-12f) s[2]=0.0f;
    if(s[3]<1e-6f) s[3]=0.0f;
    return y;
}
