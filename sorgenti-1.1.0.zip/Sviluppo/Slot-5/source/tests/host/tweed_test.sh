#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
mkdir -p build/host build/gen
"${PYTHON:-python3}" tools/gen_presets.py build/gen/presets.h
${CC:-cc} -O2 -ffp-contract=off -std=c11 -Wall -Wextra -Werror -DPLAT_HOST -Iapp/dsp -Ibase/include -Ibuild/gen -o build/host/tweed_test tests/host/tweed_test.c app/dsp/synth.c app/dsp/drumline.c app/dsp/digisophie.c app/dsp/sample.c -lm
build/host/tweed_test
