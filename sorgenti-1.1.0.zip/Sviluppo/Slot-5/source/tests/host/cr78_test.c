/* SPDX-License-Identifier: MPL-2.0 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "sample.h"
#include "synth.h"
#include "drumline.h"
static _Alignas(16) uint8_t mem[DRUMLINE_BYTES];
static uint8_t par[NTP];static float l[256],r[256],a[256],b[256];
int main(void){
 int bad=0;
 if(smp_slots()!=56||smp_factory()!=16)bad++;
 for(int k=0;k<8;k++){
  char path[128];snprintf(path,sizeof path,"build/gen/cr78-%d.pcm",k);FILE*f=fopen(path,"rb");if(!f)return 2;
  const smp_t*s=smp_get(SMP_CR78_BASE+k);smp_cache_t c;smp_cache_reset(&c);
  int same=1;int16_t exp;uint32_t count=0;
  while(fread(&exp,2,1,f)){if(!s||count>=s->n||smp_one(&c,s,(int32_t)count)*32768.0f!=(float)exp)same=0;count++;}fclose(f);
  if(!s||count!=s->n||s->root!=60)same=0;
  /* Random access (checkpoints), reverse, and after a dropped user bank. */
  smp_user_drop();smp_cache_reset(&c);f=fopen(path,"rb");
  for(int32_t j=(int32_t)count-1;j>=0;j-=17){fseek(f,2*j,SEEK_SET);if(fread(&exp,2,1,f)!=1||smp_one(&c,s,j)*32768.0f!=(float)exp)same=0;}fclose(f);
  sound_default(par,EG_DRUMLINE);par[TP_DRUM(0,DP_MODEL)]=DM_SAMPLE;par[TP_DRUM(0,DP_K1)]=(uint8_t)(SMP_CR78_BASE+k);
  par[TP_DRUM(0,DP_K2)]=64;par[TP_DRUM(0,DP_K3)]=par[TP_DRUM(0,DP_K4)]=0;
  drumline_init((drumline_t*)mem,par);drumline_hit((drumline_t*)mem,0,100,0,0,0);float pk=0;
  for(int block=0;block<260;block++){
   memset(l,0,sizeof l);memset(r,0,sizeof r);memset(a,0,sizeof a);memset(b,0,sizeof b);
   drumline_render((drumline_t*)mem,l,r,a,b,256);
   for(int j=0;j<256;j++){if(!isfinite(l[j])||!isfinite(r[j]))same=0;pk=fmaxf(pk,fmaxf(fabsf(l[j]),fabsf(r[j])));}
  }
  if(pk<0.001f||pk>1.0f||drumline_sounding((drumline_t*)mem))same=0;
  printf("%s slot%d %s: decoded PCM, reverse, no user bank, drum playback peak%.3f\n",same?"PASS":"FAIL",48+k,s?s->name:"missing",(double)pk);bad+=!same;
 }
 return bad!=0;
}
