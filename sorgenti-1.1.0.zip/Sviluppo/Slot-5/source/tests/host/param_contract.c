/* Snapshot the UI parameter contract, independently of storage representation. */
#define main dsp_fingerprint_main
#include "dsp_hash.c"
#undef main
int main(void) {
    uint8_t p[NTP];
    for (int e=0;e<NENGINE;e++) {
        sound_default(p,e);
        for(int j=0;j<NTP;j++) {
            const tp_info_t *q=tp_info_par(j,p);
            printf("%d %d %s %u %u %u %u",e,j,q->name,q->lo,q->hi,q->def,q->kind);
            if(q->names) for(int v=0;v<=q->hi;v++) printf("|%s",q->names[v]);
            puts("");
        }
    }
    return 0;
}
