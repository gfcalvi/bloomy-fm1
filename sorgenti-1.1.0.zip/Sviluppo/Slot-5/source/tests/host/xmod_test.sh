#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
mkdir -p build/host
${CC:-cc} -O2 -std=c99 -Wall -Wextra -Werror -DPLAT_HOST -Ibase/include -Iapp/dsp tests/host/xmod_test.c -o build/host/xmod_test
build/host/xmod_test
