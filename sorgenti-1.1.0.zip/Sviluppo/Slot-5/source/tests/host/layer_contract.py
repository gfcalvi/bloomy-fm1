"""Compare original metadata, allowing only the explicitly added r9.5 controls."""
import sys
from pathlib import Path
old=Path('tests/fixtures/blue93-param-contract.txt').read_text().splitlines()
new=Path(sys.argv[1]).read_text().splitlines()
assert len(old)==len(new)
changed=[]
for a,b in zip(old,new):
 e,p=map(int,b.split()[:2])
 if a==b:continue
 # New destinations extend existing route destination enums; IDs 0..18 stay in order.
 if 'layer level|layer cutoff|layer pitch' in b:
  assert b.replace('0 21 0 3','0 18 0 3').removesuffix('|layer level|layer cutoff|layer pitch')==a,(a,b)
 elif e in [0,5] and p in range(52,58):pass
 elif e==5 and p in range(34,38):pass
 else:raise AssertionError((a,b))
 changed.append((e,p))
print('PASS: reviewed r9.5 metadata changes only:',len(changed))
