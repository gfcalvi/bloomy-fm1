#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
mkdir -p build/host
${CC:-cc} -O2 -ffp-contract=off -std=c99 -Wall -Wextra -Werror -DPLAT_HOST -Iapp -Ibase/include -o build/host/evolve_test tests/host/evolve_test.c app/seq/seq.c app/seq/pattern.c
build/host/evolve_test
