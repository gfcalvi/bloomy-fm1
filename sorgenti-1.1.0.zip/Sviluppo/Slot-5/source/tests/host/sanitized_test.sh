#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
PY="${PYTHON:-python3}"
D="$(pwd)/app/build/tests/sanitizer-build"
mkdir -p "$D"
printf '#!/bin/sh\nexec cc -fsanitize=address,undefined -fno-sanitize-recover=all -fno-omit-frame-pointer "$@"\n' > "$D/cc.sh"
chmod +x "$D/cc.sh"
CC="$D/cc.sh" sh build.sh --release 0.9.4-blue94 --host
cp app/build/host/loom_host "$D/loom_host_sanitize"
"$PY" tests/host/sanitized_scenarios.py "$D/loom_host_sanitize"
