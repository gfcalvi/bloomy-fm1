#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
mkdir -p build/host build/gen
"${PYTHON:-python3}" - <<'PY'
from pathlib import Path
import sys,wave,struct,json
sys.path.insert(0,'tools');import sampleio as s
p=Path('app/samples/cr78')
for i,r in enumerate(json.loads((p/'PROVENANCE.json').read_text())):
 with wave.open(str(p/r['file'])) as w:
  x=struct.unpack('<'+'h'*w.getnframes(),w.readframes(w.getnframes()))
 a,_=s.ima_encode(x);d=s.ima_decode(a,len(x));Path(f'build/gen/cr78-{i}.pcm').write_bytes(struct.pack('<'+'h'*len(d),*d))
PY
${CC:-cc} -O2 -std=c11 -Wall -Wextra -Werror -DPLAT_HOST -Iapp/dsp -Ibase/include -Ibuild/gen -o build/host/cr78_test tests/host/cr78_test.c app/dsp/synth.c app/dsp/drumline.c app/dsp/digisophie.c app/dsp/sample.c -lm
build/host/cr78_test
