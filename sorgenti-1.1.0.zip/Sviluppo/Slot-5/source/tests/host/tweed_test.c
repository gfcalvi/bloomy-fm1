/* SPDX-License-Identifier: MPL-2.0 */
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "synth.h"
#include "drumline.h"
#include "tweed.h"
static _Alignas(16) unsigned char smem[SYNTH_BYTES], dmem[DRUMLINE_BYTES], snapshot[DRUMLINE_BYTES];
static uint8_t par[NTRK+1][NTP];
static float l[256],r[256],a[256],b[256],ref[256];
static int bad;
#define CHECK(msg,ok) do { printf("%s %s\n",(ok)?"PASS":"FAIL",msg);bad|=!(ok); } while(0)
static void clear(void){memset(l,0,sizeof l);memset(r,0,sizeof r);memset(a,0,sizeof a);memset(b,0,sizeof b);}
static float peak(void){float p=0;for(int i=0;i<256;i++){if(!isfinite(l[i])||!isfinite(r[i]))return 1e9f;p=fmaxf(p,fmaxf(fabsf(l[i]),fabsf(r[i])));}return p;}
static void s_init(int lock) {
 for(int i=0;i<=NTRK;i++)sound_default(par[i],EG_TWEED);
 synth_init((synth_t*)smem,par);
 if(lock>=0)synth_lock((synth_t*)smem,0,TP_E2,lock);
 synth_note_on((synth_t*)smem,0,60,100,0,1);
 clear();synth_prepare((synth_t*)smem,256);synth_render((synth_t*)smem,0,NVOICE,l,r,a,b,256);
}
int main(void) {
 int good=1;float c[4],s[5];
 for(int p=0;p<=127;p+=31)for(int d=0;d<=127;d+=31)for(int e=0;e<=127;e+=31){
  tweed_coeff(c,440*fm_exp2f(((float)p-69)/12),d/127.0f,e/127.0f);tweed_trigger(s);
  float f0=c[0]+c[1]*s[2],energy=0;
  for(int i=0;i<132300;i++){float x=tweed_tick(s,c);good &= isfinite(x)&&fabsf(x)<=1.01f&&s[0]>=0&&s[0]<1&&s[1]>=0&&s[1]<1;energy+=x*x;}
  good &= s[3]<1e-4f && c[0]+c[1]*s[2]<=f0 && energy>0;
 }
 CHECK("Tweed extreme controls: finite, bounded phases, exponential chirp and finite decay",good);
 s_init(-1);memcpy(ref,l,sizeof l);s_init(0);CHECK("Synth Chirp parameter lock changes audio",memcmp(ref,l,sizeof l)!=0);
 s_init(-1);CHECK("Removing lock restores base sound deterministically",memcmp(ref,l,sizeof l)==0);
 s_init(127);synth_note_on((synth_t*)smem,0,60,100,0,2);clear();synth_prepare((synth_t*)smem,256);synth_render((synth_t*)smem,0,NVOICE,l,r,a,b,256);CHECK("Retrigger stays finite",peak()<1.0f);
 good=1;smp_user_drop();
 for(int model=DM_TWEED;model<=DM_LOFI;model++)for(int key=0;key<(model==DM_LOFI?5:3);key++){
  sound_default(par[0],EG_DRUMLINE);par[0][TP_DRUM(0,DP_MODEL)]=(uint8_t)model;
  for(int k=0;k<4;k++)par[0][TP_DRUM(0,DP_K1+k)]=DM_DEFAULT[model][k];
  if(model==DM_LOFI)par[0][TP_DRUM(0,DP_K1)]=(uint8_t)key;
  else par[0][TP_DRUM(0,DP_K1)]=(uint8_t)(36+key*19);
  drumline_init((drumline_t*)dmem,par[0]);drumline_hit((drumline_t*)dmem,0,100,0,0,0);
  float pk=0;
  for(int j=0;j<520;j++){clear();drumline_render((drumline_t*)dmem,l,r,a,b,256);pk=fmaxf(pk,peak());}
  good &= pk>0.001f&&pk<1.1f&&!drumline_sounding((drumline_t*)dmem);
 }
 CHECK("All hybrid samples and Tweed keys play with user bank absent, and terminate",good);
 /* Effective drum parameters are read again while the voice sounds (locks and live knobs). */
 sound_default(par[0],EG_DRUMLINE);par[0][TP_DRUM(0,DP_MODEL)]=DM_TWEED;
 for(int k=0;k<3;k++)par[0][TP_DRUM(0,DP_K1+k)]=DM_DEFAULT[DM_TWEED][k];
 drumline_init((drumline_t*)dmem,par[0]);drumline_hit((drumline_t*)dmem,0,100,0,0,0);
 clear();drumline_render((drumline_t*)dmem,l,r,a,b,32);memcpy(snapshot,dmem,sizeof dmem);
 clear();drumline_render((drumline_t*)dmem,l,r,a,b,256);memcpy(ref,l,sizeof l);good=1;
 for(int k=0;k<3;k++){
  memcpy(dmem,snapshot,sizeof dmem);par[0][TP_DRUM(0,DP_K1+k)]=120;
  clear();drumline_render((drumline_t*)dmem,l,r,a,b,256);
  good &= memcmp(ref,l,sizeof l)!=0 && peak()<1.1f;
  par[0][TP_DRUM(0,DP_K1+k)]=DM_DEFAULT[DM_TWEED][k];
 }
 CHECK("All three drum controls modulate a sounding Tweed voice",good);
 return bad;
}
