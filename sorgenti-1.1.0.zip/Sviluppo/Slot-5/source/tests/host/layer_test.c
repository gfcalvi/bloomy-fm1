/* r9.5: actual shared voice renderer, independent AR/filter and modulation. */
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "../../app/dsp/synth.c"
static uint8_t par[NTRK+1][NTP];
static struct synth sy;
static float l[256],r[256],a[256],b[256];
static float render(int n) {
 memset(l,0,sizeof l);memset(r,0,sizeof r);memset(a,0,sizeof a);memset(b,0,sizeof b);
 synth_prepare(&sy,n);synth_render_on(&sy,0,0,NVOICE,l,r,a,b,n);
 float en=0;for(int i=0;i<n;i++) {assert(isfinite(l[i])&&isfinite(r[i])&&isfinite(a[i])&&isfinite(b[i]));assert(fabsf(l[i])<20&&fabsf(r[i])<20);en+=l[i]*l[i]+r[i]*r[i];}return en;
}
static void setup(int engine,int mode,int hp,int cut,int attack,int release) {
 memset(par,0,sizeof par);sound_default(par[0],engine);par[0][TP_LAYER_MODE]=mode;par[0][TP_LAYER_TYPE]=hp;par[0][TP_LAYER_CUT]=cut;par[0][TP_LAYER_A]=attack;par[0][TP_LAYER_R]=release;
 par[0][engine==EG_KNIT?TP_X2:TP_X1]=100;par[0][engine==EG_KNIT?TP_X1:TP_X2]=76;
 par[0][TP_SEND1]=70;par[0][TP_SEND2]=65;
 synth_init(&sy,par);synth_note_on(&sy,0,60,100,0,123);
}
int main(void) {
 assert(fabsf(layer_release_seconds(1.0f)-0.060f)<0.0001f);
 assert(env_seconds(1.0f)>9.99f); /* primary ADSR unchanged */
 printf("voice=%zu synth=%zu allocation=%d xm=%zu\n",sizeof(voice_t),sizeof sy,SYNTH_BYTES,sizeof xm);
 for(int eg=0;eg<2;eg++)for(int mode=1;mode<=(eg?1:4);mode++)for(int hp=0;hp<2;hp++)for(int corner=0;corner<2;corner++) {
  setup(eg?EG_VOILE:EG_KNIT,mode,hp,corner?127:0,corner?127:0,corner?127:0);
  for(int j=0;j<30;j++)render(256);
  synth_note_off(&sy,0,123);for(int j=0;j<5000;j++)render(256);
  assert(!synth_voices_used(&sy));
 }
 /* Layer remains audible after the primary envelope has finished. */
 setup(EG_VOILE,1,0,127,0,110);par[0][TP_R]=0;
 for(int i=0;i<80;i++)render(256);
 synth_note_off(&sy,0,123);for(int i=0;i<1;i++)render(256);
 assert(synth_voices_used(&sy)>0);assert(render(256)>1e-7f);
 /* Dedicated cutoff does not share primary filter state, LP/HP complementary at same input. */
 setup(EG_KNIT,3,0,50,0,90);render(64);voice_t v=sy.v[0],w=v;
 w.layer.type=1;float lp=0,hp=0;for(int i=0;i<4096;i++){float q=layer_sample(&v);lp+=q*q;float y=layer_sample(&w);hp+=y*y;}assert(isfinite(lp)&&isfinite(hp)&&lp!=hp);
 /* All three new LFO routes address the layer; locks are separate from drum locks. */
 setup(EG_VOILE,1,0,90,20,90);
 synth_lock(&sy,0,TP_LAYER_CUT,31);assert(synth_lock_value(&sy,0,TP_LAYER_CUT)==31);
 synth_lock(&sy,0,TP_LAYER_CUT,255);assert(synth_lock_value(&sy,0,TP_LAYER_CUT)==-1);
 for(int d=XD_LAYER_LEVEL;d<=XD_LAYER_PITCH;d++) {
  par[0][TP_XMOD0]=XM_SQUARE;par[0][TP_XMOD0+4]=d;par[0][TP_XMOD0+5]=90;
  render(256);assert(xm.active[0]);assert(xm.out[0][0][d]!=0);
 }
 for(int d=XD_LAYER_LEVEL;d<=XD_LAYER_PITCH;d++) {
  struct { char num[12]; char guard[4]; char unit[6]; } text;
  memset(&text,0x5a,sizeof text);
  tp_text_i(tp_info(TP_XMOD0+4,EG_KNIT),TP_XMOD0+4,d,EG_KNIT,text.num,text.unit);
  for(int j=0;j<4;j++)assert(text.guard[j]==0x5a);
  assert(strlen(text.num)<=11);
 }
 puts("PASS layer modes/LP/HP/extremes/long AR/lifetime/locks/LFO, real voice renderer");
}
