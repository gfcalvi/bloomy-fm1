#!/usr/bin/env python3
"""Run every UI scenario and 30 simulated minutes with an ASan/UBSan host binary.
Run tests/run_tests.sh first to prepare the sample-bank fixtures.
"""
from pathlib import Path
import subprocess,os,sys,json
r=Path(__file__).resolve().parents[2]
host=Path(sys.argv[1]).resolve();out=r/"app/build/tests/sanitizers";out.mkdir(parents=True,exist_ok=True)
results={}
cases=list(sorted((r/"tests/scenarios").glob("*.xy")))+[r/"tests/fixtures/blue-memory-soak.xy"]
for p in cases:
 d=out/p.stem;d.mkdir(exist_ok=True)
 with (d/"run.log").open("w") as log:
  q=subprocess.run([str(host),str(p),str(d)],cwd=r,env=dict(os.environ,ASAN_OPTIONS="detect_leaks=0"),stdout=log,stderr=subprocess.STDOUT)
 text=(d/"run.log").read_text()
 error=any(x in text for x in ["runtime error:","ERROR: AddressSanitizer","SUMMARY: UndefinedBehaviorSanitizer"])
 results[p.stem]={"returncode":q.returncode,"sanitizer_error":error}
 print(p.stem,"PASS" if q.returncode==0 and not error else "FAIL",flush=True)
(out/"results.json").write_text(json.dumps(results,indent=2)+"\n")
assert all(v["returncode"]==0 and not v["sanitizer_error"] for v in results.values())
