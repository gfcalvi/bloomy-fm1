#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
mkdir -p app/build/tests
${CC:-cc} -O2 -ffp-contract=off -std=c99 -DPLAT_HOST -Iapp/dsp -Ibase/include -Ibuild/gen -Itests/host -o app/build/tests/param_contract tests/host/param_contract.c app/dsp/synth.c app/dsp/drumline.c app/dsp/digisophie.c app/dsp/sample.c app/dsp/fx.c
app/build/tests/param_contract > app/build/tests/param_contract.txt
"${PYTHON:-python3}" tests/host/layer_contract.py app/build/tests/param_contract.txt
echo "Parameter metadata preserves existing controls; only reviewed r9.5 additions differ"
