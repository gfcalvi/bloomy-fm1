/* Regression R94-DENSE-REVERB-001: a reused stereo voice must become mono. */
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include "../../app/dsp/synth.c"
int main(void)
{
    voice_t v = {0};
    float l[64], r[64];
    v.c.freq = 261.6256f;
    v.c.ek[2] = 3.0f;
    v.c.e[3] = 0.7f;
    knit_init(&v);
    knit_prep(&v);
    assert(v.c.stereo);
    v.engine = EG_TWEED;
    v.c.ek[0] = 60.0f;
    v.c.e[1] = 0.8f;
    v.c.e[2] = 0.6f;
    tweed_prep(&v);
    assert(!v.c.stereo);
    tweed_trigger(v.o);
    for (int i = 0; i < 64; i++) r[i] = NAN;
    eng_run(&v, l, r, 64);
    for (int i = 0; i < 64; i++) {
        assert(isfinite(l[i]) && fabsf(l[i]) <= 1.0f);
        assert(isnan(r[i])); /* Unwritten on purpose: it must never be mixed. */
    }
    puts("PASS Knit stereo -> Tweed mono, poisoned unused channel");
    return 0;
}
