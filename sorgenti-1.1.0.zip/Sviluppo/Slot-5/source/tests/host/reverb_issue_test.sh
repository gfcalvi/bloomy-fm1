#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
mkdir -p build/host
${CC:-cc} -O2 -ffp-contract=off -std=c99 -DPLAT_HOST -Iapp/dsp -Ibase/include -Ibuild/gen tests/host/tweed_reuse_test.c app/dsp/drumline.c app/dsp/digisophie.c app/dsp/sample.c -lm -o build/host/tweed_reuse_test
build/host/tweed_reuse_test
${CC:-cc} -O2 -ffp-contract=off -std=c99 -DPLAT_HOST -DMST_HEADROOM=1.0f -Iapp/dsp -Ibase/include tests/host/spu_saturation_test.c -o build/host/spu_saturation_test
build/host/spu_saturation_test
