/* SPDX-License-Identifier: MPL-2.0 */
#define main legacy_main
#include "seq_test.c"
#undef main
static void put(int t,int f,int v) { CHECK(tm_set(P.lane,t,0,f,v,0,BS_MINOR)); }
int main(void)
{
    uint8_t frozen[48],pattern[sizeof P.pat];
    cur="turing eight independent sources";reset();
    for(int t=0;t<NTRK;t++) {
        par[t][TP_ENGINE]= t==6?EG_SLICE:t==7?EG_MIDI:t==5?EG_SAMPLE:EG_KNIT;
        put(t,TM_DENSITY,100);put(t,TM_LOW,48);put(t,TM_HIGH,72);put(t,TM_KEY,0);put(t,TM_SCALE,BS_MINOR);
        put(t,TM_MUTATE,100);put(t,TM_MODE,1);
    }
    memcpy(pattern,P.pat,sizeof pattern);start();run(44100*4);
    for(int t=0;t<NTRK;t++) {
        int n=0;
        for(int i=0;i<nev;i++)if(ev[i].kind==E_ON && ev[i].trk==t) {
            int note=ev[i].a; CHECK(note>=48 && note<=72);CHECK(BRAIN_SCALE[BS_MINOR]>>((note%12+12)%12)&1u);n++;
        }
        CHECK(n>20);
    }
    CHECK(!memcmp(pattern,P.pat,sizeof pattern));
    {int k=tm_lane(P.lane,0);memcpy(frozen,P.lane[k].val+16,48);}
    put(0,TM_MODE,2);put(0,TM_LOW,84);put(0,TM_HIGH,84); /* clamp makes low=72 first, then high=84: irrelevant while frozen */
    put(0,TM_DENSITY,0);put(0,TM_DUR,64);put(0,TM_VEL,1);
    {int k=tm_lane(P.lane,1);uint8_t before[48];memcpy(before,P.lane[k].val+16,48);run(44100*4);
     CHECK(memcmp(before,P.lane[k].val+16,48)!=0);}
    CHECK(!memcmp(frozen,P.lane[tm_lane(P.lane,0)].val+16,48));
    printf("ok independent rings / freeze preserves notes rests gates velocities / patterns unchanged\n");
    cur="turing mutation zero";put(0,TM_MODE,1);put(0,TM_MUTATE,0);run(44100*2);
    CHECK(!memcmp(frozen,P.lane[tm_lane(P.lane,0)].val+16,48));
    cur="turing mono and priority";put(0,TM_MUTATE,100);put(0,TM_DENSITY,100);put(0,TM_DUR,64);
    par[0][TP_PLAYER]=PL_ARP;seq_key(&S,0,100,1,100);run(44100*2);
    {int live=0;for(int i=0;i<nev;i++)if(ev[i].trk==0) {
        if(ev[i].kind==E_ON){CHECK(++live==1);CHECK(ev[i].a!=100);}
        if(ev[i].kind==E_OFF && live)live--;
    }}
    printf("ok mutation zero / live parameter changes / monophonic gates / arp and key bypass\n");
    cur="turing pattern switch";{int k=tm_lane(P.lane,0);memcpy(frozen,P.lane[k].val+16,48);}
    put(0,TM_MODE,2);seq_cue_pattern(&S,0,1);run(44100*4);CHECK(S.ppat[0]==1);
    CHECK(!memcmp(frozen,P.lane[tm_lane(P.lane,0)].val+16,48));
    stop();{patterns_t *copy=malloc(sizeof P);CHECK(copy);memcpy(copy,&P,sizeof P);seq_init(&S,copy,par);S.clock=SEQ_CLK_INTERNAL;
    start();run(44100);CHECK(tm_get(copy->lane,0,TM_MODE)==2);CHECK(!memcmp(frozen,copy->lane[tm_lane(copy->lane,0)].val+16,48));free(copy);}
    printf("ok pattern switch / transport restart / stored state roundtrip\n");
    cur="turing drum exclusion and no free lanes";reset();par[0][TP_ENGINE]=EG_DRUMLINE;put(0,TM_MODE,1);start();run(44100);CHECK(S.tm_index[0]==255);stop();
    reset();for(int i=0;i<NLANE;i++){P.lane[i].used=1;P.lane[i].trk=0;P.lane[i].pat=0;P.lane[i].param=(uint16_t)i;}
    CHECK(!tm_set(P.lane,1,0,TM_MODE,1,0,BS_MAJOR));CHECK(tm_lane(P.lane,1)<0);
    printf("ok drums excluded / lane exhaustion is refused\n");
    cur="frozen initialization, external clock and source return";reset();
    put(0,TM_DENSITY,100);put(0,TM_LOW,60);put(0,TM_HIGH,60);put(0,TM_MUTATE,0);put(0,TM_MODE,2);
    {int k=tm_lane(P.lane,0);for(int i=0;i<16;i++)CHECK(P.lane[k].val[16+i]==60);}
    S.clock=SEQ_CLK_RECEIVE;start();
    for(int i=0;i<192;i++){seq_ext_clock(&S);run(900);}
    {int n=0;for(int i=0;i<nev;i++)if(ev[i].kind==E_ON){CHECK(ev[i].a==60);n++;}CHECK(n>20);}
    stop();put(0,TM_MODE,0);S.clock=SEQ_CLK_INTERNAL;
    P.pat[0][0].st[0].note[0]=64;P.pat[0][0].st[0].note[1]=67;
    nev=0;start();run(44100);
    {int a=0,b=0;for(int i=0;i<nev;i++)if(ev[i].kind==E_ON){a+=ev[i].a==64;b+=ev[i].a==67;}CHECK(a>0 && b>0);}
    printf("ok first freeze honors configured density / external MIDI clock / sequencer returns\n");
    cur="live frozen capture at boundary";reset();
    P.pat[0][0].st[0].note[0]=77;P.pat[0][0].st[0].note[1]=81;
    put(0,TM_DENSITY,100);put(0,TM_LOW,60);put(0,TM_HIGH,60);put(0,TM_LEN,4);put(0,TM_DUR,64);put(0,TM_MODE,2);
    {int k=tm_lane(P.lane,0),a=lane_alloc(P.lane,0,0,TP_CUT);CHECK(a>=0);P.lane[a].val[0]=15;
     memcpy(frozen,P.lane[k].val+16,48);start();run(100);
     P.lane[k].val[13]=1;run(1000);CHECK(P.pat[0][0].st[0].note[0]==77); // not the end of four steps yet
     run(44100);CHECK(S.playing==1);CHECK(P.lane[k].val[TM_MODE]==2);CHECK(P.lane[k].val[13]==2);
     CHECK(P.pat[0][0].len==4);CHECK(lane_find(P.lane,0,0,TP_CUT)<0);
     for(int i=0;i<4;i++){CHECK(P.pat[0][0].st[i].note[0]==60);CHECK(!P.pat[0][0].st[i].note[1]);CHECK(P.pat[0][0].st[i].len==4);}
     CHECK(!memcmp(frozen,P.lane[k].val+16,48));
     // Cancel a pending capture by unfreezing. It must not replay on a later Freeze.
     P.pat[0][0].st[0].note[0]=78;P.lane[k].val[13]=1;put(0,TM_MODE,1);CHECK(P.lane[k].val[13]==0);put(0,TM_MODE,2);
     run(44100);CHECK(P.pat[0][0].st[0].note[0]==78);
     stop();P.lane[k].val[13]=1;run(256);CHECK(P.pat[0][0].st[0].note[0]==60);CHECK(!S.playing);
     put(0,TM_MODE,1);CHECK(!tm_capture(&P,0,0));
    }
    printf("ok queued capture / no early rewrite / freeze retained / locks replaced / clipped gates / cancellation / stopped capture\nall Turing tests passed\n");return 0;
}
