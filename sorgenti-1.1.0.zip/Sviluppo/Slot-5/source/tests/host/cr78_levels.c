#include <stdio.h>
#include <math.h>
#include <string.h>
#include "sample.h"
#include "synth.h"
#include "drumline.h"
static _Alignas(16) unsigned char mem[DRUMLINE_BYTES];static unsigned char p[NTP];static float l[256],r[256],a[256],b[256];
int main(){for(int k=0;k<16;k++){sound_default(p,EG_DRUMLINE);int key=k<8?0:k-8;if(k<8){p[TP_DRUM(0,DP_MODEL)]=DM_SAMPLE;p[TP_DRUM(0,DP_K1)]=48+k;p[TP_DRUM(0,DP_K2)]=64;p[TP_DRUM(0,DP_K3)]=p[TP_DRUM(0,DP_K4)]=0;}drumline_init((drumline_t*)mem,p);drumline_hit((drumline_t*)mem,key,100,0,0,0);double power=0;float pk=0;for(int block=0;block<128;block++){memset(l,0,sizeof l);memset(r,0,sizeof r);memset(a,0,sizeof a);memset(b,0,sizeof b);drumline_render((drumline_t*)mem,l,r,a,b,256);for(int i=0;i<256;i++){if(!isfinite(l[i])||!isfinite(r[i]))return 1;pk=fmaxf(pk,fmaxf(fabsf(l[i]),fabsf(r[i])));if(block<20)power+=l[i]*l[i]+r[i]*r[i];}}printf("%d peak_db %.2f rms116ms_db %.2f\n",k,20*log10(pk+1e-12),10*log10(power/10240+1e-24));}return 0;}
