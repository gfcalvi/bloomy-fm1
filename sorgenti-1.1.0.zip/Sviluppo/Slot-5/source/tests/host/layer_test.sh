#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
mkdir -p build/host
${CC:-cc} -O2 -ffp-contract=off -std=c99 -DPLAT_HOST -Iapp/dsp -Ibase/include -Ibuild/gen tests/host/layer_test.c app/dsp/drumline.c app/dsp/digisophie.c app/dsp/sample.c -lm -o build/host/layer_test
build/host/layer_test
