/* SPDX-License-Identifier: MPL-2.0 */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "seq/seq.h"
static patterns_t P;
static tpat_t A,B;
static int count(const tpat_t *p) {int n=0; for(int s=0;s<p->len;s++) n+=!step_empty(&p->st[s]);return n;}
static int allowed(int n) {return BRAIN_SCALE[BS_MINOR]>>(n%12)&1;}
static void set(int f,int v) {assert(evo_set(P.lane,1,0,f,v));}
static seq_t SQ;
static uint8_t PAR[NALLTRK][NTP_ALL];
static int played,changed;
static void heard(void *ctx,int t,int n,int v,int glide,uint32_t tag)
{
 (void)ctx;(void)t;(void)v;(void)glide;(void)tag;
 assert(n>=48 && n<=84);assert(allowed(n));played++;changed+=n!=60;
}
static void integration(void)
{
 seq_sink_t sink={0};sink.note_on=heard;
 patterns_init(&P);memset(PAR,0,sizeof PAR);
 for(int t=0;t<NTRK;t++) {
  for(int i=0;i<64;i++) {P.pat[t][0].st[i].note[0]=60;P.pat[t][0].st[i].vel=90;}
  P.pat[t][0].len=64;
  assert(evo_set(P.lane,t,0,EV_MODE,1));assert(evo_set(P.lane,t,0,EV_RATE,0));
  assert(evo_set(P.lane,t,0,EV_CHANCE,100));assert(evo_set(P.lane,t,0,EV_RETURN,0));
  assert(evo_protect(P.lane,t,0,0,1));
 }
 seq_init(&SQ,&P,PAR);SQ.bpm=220;SQ.brain_scale=BS_MINOR;
 seq_start(&SQ,1);
 for(int i=0;i<30000;i++) seq_advance(&SQ,128,&sink);
 assert(played>8000 && changed>1000);
 for(int t=0;t<NTRK;t++) {
  assert(evo_offset(P.lane,t,0,0)==0);
  for(int i=0;i<64;i++) assert(P.pat[t][0].st[i].note[0]==60);
  assert(evo_set(P.lane,t,0,EV_MODE,2));
 }
 lane_t before[NLANE];memcpy(before,P.lane,sizeof before);
 for(int i=0;i<3000;i++) seq_advance(&SQ,128,&sink);
 assert(!memcmp(before,P.lane,sizeof before));
 seq_stop(&SQ);seq_advance(&SQ,128,&sink);
 printf("integration: %d notes, %d evolved; eight 64-step tracks, originals intact, Freeze PASS\n",played,changed);
}
int main(void) {
 patterns_init(&P); A=P.pat[1][0];
 /* Deterministic generator, exactly k hits across arbitrary lengths/rotations. */
 set(GEN_METHOD,1);set(EV_LOW,48);set(EV_HIGH,72);
 for(int len=1;len<=64;len++) for(int k=0;k<=len;k++) {
  A.len=len;set(GEN_PULSES,k);set(GEN_ROTATE,13);
  evo_generate(&B,&A,P.lane,1,0,0,BS_MINOR);
  assert(count(&B)==k);
  for(int s=0;s<len;s++) if(B.st[s].note[0]) {assert(allowed(B.st[s].note[0]));assert(B.st[s].note[0]>=48&&B.st[s].note[0]<=72);}
 }
 A.len=64;set(GEN_METHOD,0);set(GEN_DENSITY,50);set(EV_SEED_LO,193);set(EV_SEED_HI,6);
 evo_generate(&B,&A,P.lane,1,0,0,BS_MINOR); tpat_t C=B;
 evo_generate(&B,&A,P.lane,1,0,0,BS_MINOR);assert(!memcmp(&B,&C,sizeof B));
 set(EV_SEED_LO,194);evo_generate(&B,&A,P.lane,1,0,0,BS_MINOR);assert(memcmp(&B,&C,sizeof B));
 set(GEN_DENSITY,0);evo_generate(&B,&A,P.lane,1,0,0,BS_MINOR);assert(count(&B)==0);
 set(GEN_DENSITY,100);evo_generate(&B,&A,P.lane,1,0,0,BS_MINOR);assert(count(&B)==64);
 /* Protect preserves chords, timing and trick even with zero density. */
 A.st[0]=(step_t){{48,52,55,0},99,7,-2,SC_MULTIPLY,2,0,0,0};
 assert(evo_protect(P.lane,1,0,0,1));set(GEN_DENSITY,0);
 evo_generate(&B,&A,P.lane,1,0,0,BS_MINOR);assert(!memcmp(&A.st[0],&B.st[0],sizeof(step_t)));
 set(EV_MODE,1);set(EV_RATE,0);set(EV_CHANCE,100);set(EV_RETURN,0);set(EV_AMOUNT,4);
 assert(evo_note(P.lane,1,0,0,52,0,BS_MINOR)==52);
 for(int pass=1;pass<2000;pass++) {
  evo_update(&P,1,0,0,pass);assert(evo_offset(P.lane,1,0,0)==0);
  evo_update(&P,1,0,1,pass);int d=evo_offset(P.lane,1,0,1);assert(d>=-4&&d<=4);
  int n=evo_note(P.lane,1,0,1,60,0,BS_MINOR);assert(n>=48&&n<=72);assert(allowed(n));
 }
 /* Freeze suspends both offsets and RNG; off bypasses, neither accumulates jobs. */
 set(EV_MODE,2);lane_t snapshot[NLANE];memcpy(snapshot,P.lane,sizeof snapshot);
 for(int i=1;i<100;i++) assert(!evo_update(&P,1,0,1,i));assert(!memcmp(snapshot,P.lane,sizeof snapshot));
 int old=evo_note(P.lane,1,0,1,60,0,BS_MINOR); (void)old;
 set(EV_MODE,0);assert(evo_note(P.lane,1,0,1,60,0,BS_MINOR)==60);
 set(EV_MODE,1);set(EV_RETURN,100);evo_update(&P,1,0,1,2001);assert(evo_offset(P.lane,1,0,1)==0);
 set(EV_RETURN,0);set(EV_RATE,2);evo_reset(P.lane,1,0);
 assert(!evo_update(&P,1,0,1,0));assert(!evo_update(&P,1,0,1,1));assert(evo_update(&P,1,0,1,4));
 assert(evo_offset(P.lane,1,0,1)!=0);evo_reset(P.lane,1,0);assert(evo_offset(P.lane,1,0,1)==0);assert(evo_protected(P.lane,1,0,0));
 /* No-scale-note interval cannot create illegal/out-of-range random notes. */
 set(EV_LOW,61);set(EV_HIGH,61);set(GEN_DENSITY,100);assert(evo_protect(P.lane,1,0,0,0));
 evo_generate(&B,&A,P.lane,1,0,0,BS_MINOR);assert(count(&B)==0);
 /* Exhaustion must not enable an evolver with no offset lane, or corrupt another lane. */
 patterns_init(&P);for(int i=0;i<NLANE;i++) assert(lane_alloc(P.lane,0,0,i)>=0);
 memcpy(snapshot,P.lane,sizeof snapshot);assert(!evo_set(P.lane,1,0,EV_MODE,1));assert(!memcmp(snapshot,P.lane,sizeof snapshot));
 integration();
 puts("evolve: deterministic generation, Euclidean counts, scale/range, protection, bounds, freeze, return, rate, reset, exhaustion PASS");
}
