/* Conversion must be defined even for extreme/non-finite upstream input. */
#include <assert.h>
#include <float.h>
#include <math.h>
#include <stdio.h>
#include "../../app/dsp/fx.c"
int main(void)
{
    int16_t w[FX_RV_LEN] = {0};
    const float x[] = {0, 0.5f, -0.5f, 1, -1, FLT_MAX, -FLT_MAX, INFINITY, -INFINITY, NAN};
    const int expected[] = {0,16384,-16384,32767,-32768,32767,-32768,32767,-32768,0};
    for (unsigned i=0; i<sizeof x/sizeof *x; i++) {
        assert(spu_wr(w,0,(int)i,x[i]) == expected[i]);
        assert(w[i] == expected[i]);
    }
    for (int i=-131072; i<=131072; i++) {
        float v=(float)i/65536.0f;
        int old=(int)(v*32768.0f);
        old=old>32767?32767:old < -32768?-32768:old;
        assert(spu_wr(w,0,0,v)==old);
    }
    puts("PASS SPU finite/Inf/NaN saturation; 262145 finite values unchanged");
}
