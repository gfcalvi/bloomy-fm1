/* SPDX-License-Identifier: MPL-2.0 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "xmod.h"
#define CHECK(x) do{if(!(x)){printf("FAIL %s line %d\n",#x,__LINE__);exit(1);}}while(0)
int main(void)
{
    uint8_t c[12]={XM_SINE,4,0,0,0,64,0,64,0,64,0,64};
    xm_state_t a={0},b={0};
    CHECK(fm_fabsf(xm_hz(5,70)-70.0f/45.0f)<0.00001f);
    CHECK(fm_fabsf(xm_hz(3,70)-70.0f/90.0f)<0.00001f);
    c[2]=64;
    CHECK(fm_fabsf(xm_tick(&a,c,120,0.001f))<0.001f);
    { uint8_t cb[12]; memcpy(cb,c,sizeof cb); cb[2]=0;
    (void)xm_tick(&b,cb,120,0.001f);
    for(int i=0;i<1000;i++){
        float x=xm_tick(&a,c,120,0.001f),y=xm_tick(&b,cb,120,0.001f);
        CHECK(fm_fabsf(x+y)<0.02f); /* half-cycle separation; phase controls preserve running phases */
    }
    }
    memset(&a,0,sizeof a);a.rng=123;c[0]=XM_RANDOM;c[2]=0;
    { float prev=xm_tick(&a,c,120,0.001f);int changes=0;
      for(int i=0;i<1010;i++){float x=xm_tick(&a,c,120,0.001f);CHECK(x>=-1&&x<=1);if(x!=prev)changes++;prev=x;}
      CHECK(changes==2);
    }
    for(int key=0;key<12;key++) for(int i=0;i<1200;i++){
        float n=xm_quantize(24.0f+i*0.05f,key,0xAB5); /* major mask */
        int pc=(((int)n-key)%12+12)%12;
        if(n>1&&n<127)CHECK(0xAB5>>pc&1);
    }
    CHECK(xm_quantize(61.0f,0,0xAB5)==60.0f); /* tie down C major */
    a.reset=1;c[0]=XM_SQUARE;c[2]=64;
    CHECK(xm_tick(&a,c,120,0.001f)==-1.0f);
    puts("xmod oscillator, independent phase, dotted rates, sample-hold, retrigger and scale tests passed");
    return 0;
}
