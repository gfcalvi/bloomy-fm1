#!/usr/bin/env python3
"""Master-output scratch reuse: compare the integrated renderer with pre-refactor audio.
Eight tracks, layered engines/drums, fractional-tempo event cuts, locks, lagged/inline FX,
stop/reboot and backup/restore; exercise both simulated core scheduling paths.
"""
from pathlib import Path
import subprocess,os,hashlib
r=Path(__file__).resolve().parents[2]
expected={0:"a94f24a302545e934a7d2e7951ffc10448f8c08540b4625a81fd757c0adeaf37",1:"2a10c6a39d4cf62126284058622319f234e0f0e576e23c087b21bc9770ec5c70"}
for core,digest in expected.items():
 out=r/"app/build/tests"/f"memory-render-{core}"
 out.mkdir(parents=True,exist_ok=True)
 script=out/"run.xy";script.write_text(f"cores {core}\n"+(r/"tests/fixtures/memory-render.xy").read_text())
 with (out/"run.log").open("w") as log:
  subprocess.run([str(r/"app/build/host/loom_host"),str(script),str(out)],cwd=r,env=dict(os.environ,LOOM_LOAD="0"),stdout=log,stderr=subprocess.STDOUT,check=True)
 actual=hashlib.sha256((out/"mixed.wav").read_bytes()).hexdigest()
 assert actual==digest,(core,actual,digest)
 print(f"cores {core}: audio byte-identical to r9.3 CR78 reference; persistence/restore pass")
