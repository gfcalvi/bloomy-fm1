/* SPDX-License-Identifier: MPL-2.0 */
#define main existing_synth_tests
#include "synth_test.c"
#undef main
int main(void) {
 reset();breaks_attach();
 for(int k=0;k<NPRESETS;k++) {
  load_preset(0,k);float pk=0;note_test(PRESETS[k].name,0,&pk,0);
  printf("LEVEL %s|%d|%.4f\n",PRESETS[k].name,PRESETS[k].par[TP_VOLUME],(double)db(pk));
 }
 return 0;
}
