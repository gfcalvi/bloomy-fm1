# SPDX-License-Identifier: MPL-2.0
"""Blue expansion: 30 factory sounds per voice engine, constant data in XIP.
Original recipes untouched. Names and parameter ranges checked by generator.
These are voicing starting points; hardware audition still required."""
from copy import deepcopy
import lib
from lib import P
NAMES = ['grain','shard','drop','wire','pin','coil','snap','dust','glass','tick',
         'zap','pulse','spark','bolt','pebble','flake','crackle','plink','knock','chip',
         'bead','spike','rattle','stone','spray','click','ping','clink','sleet','zip']
for n,name in enumerate(NAMES):
 P('tw '+name,'drum','tweed',dict(pitch=24+(n*7)%73,chirp=(n*29)%128,decay=12+(n*17)%100,unused=0),
   amp=(0,95,127,80),volume=112,filter=('dynamic',127,0,64,64),octave=0,
   genres=('experimental','glitch'))
PREFIX=dict(knit='kn',rayon='ra',jacquard='ja',bellows='be',cane='ca',voile='vo')
for eng,pre in PREFIX.items():
 base=[p for p in lib.PRESETS if p['engine']==eng]
 for n in range(30-len(base)):
  p=deepcopy(base[n%len(base)]);p['name']=pre+' '+NAMES[n]
  k=list(p['knobs']); delta=8+6*(n//len(base))
  if eng=='knit': k[1]=min(127,k[1]+delta);k[3]=min(127,k[3]+2*delta)
  elif eng=='rayon': k[0]=min(127,k[0]+delta);k[3]=min(127,k[3]+delta)
  elif eng=='jacquard': k[1]=(k[1]+delta)%128;k[3]=min(127,k[3]+delta)
  elif eng=='bellows': k[2]=1+(k[2]+n)%8;k[3]=1+(k[3]+n//2)%8
  elif eng=='cane': k[1]=min(127,k[1]+delta);k[2]=min(127,k[2]+delta)
  elif eng=='voile': k[1]=min(127,k[1]+delta);k[2]=max(0,k[2]-delta)
  p['knobs']=k
  p['volume']=round(min(100,p['volume'])*(0.75 if eng=='knit' else 1.0))
  a,d,su,re=p['amp'];p['amp']=(a,min(127,d+delta),su,min(127,re+delta))
  lib.PRESETS.append(p)

# Reference C4/velocity100 one-second render: new presets peak-normalised toward -17dBFS.
# Only volume is adjusted; existing factory recipes are never changed.
import json
from pathlib import Path
levels=json.loads(Path(__file__).with_name('blue_levels.json').read_text())
for p in lib.PRESETS:
 if p['name'] in levels:p['volume']=levels[p['name']]
