#!/usr/bin/env python3
"""Pin and verify emulator assets. Run after --web, or automatically from make_pages.py."""
from pathlib import Path
import hashlib,re,sys
root=Path(sys.argv[1]);index=root/'index.html';s=index.read_text()
wasm=hashlib.sha256((root/'app.wasm').read_bytes()).hexdigest()
worklet=hashlib.sha256((root/'worklet.js').read_bytes()).hexdigest()
s=s.replace('LOOM-8 Blue r9 — browser emulator','LOOM-8 Blue r9.4 — verified emulator').replace('<h1>LOOM-8 Blue r9</h1>','<h1>LOOM-8 Blue r9.4</h1>')
s=re.sub(r'// BLUE_ASSET_PIN_BEGIN.*?// BLUE_ASSET_PIN_END\n','',s,flags=re.S)
constants='// BLUE_ASSET_PIN_BEGIN\nconst BLUE_WASM_SHA256 = "'+wasm+'";\nconst BLUE_WORKLET_SHA256 = "'+worklet+'";\n// BLUE_ASSET_PIN_END\n'
s=s.replace('async function switchOn() {',constants+'async function switchOn() {',1)
s=s.replace('fetch("app.wasm")','fetch(`app.wasm?v=${BLUE_WASM_SHA256}`, { cache: "no-store" })')
s=s.replace('ac.audioWorklet.addModule("worklet.js")','ac.audioWorklet.addModule(`worklet.js?v=${BLUE_WORKLET_SHA256}`)')
needle='    node = new AudioWorkletNode(ac, "xy",'
if '// BLUE_VERIFY_BEGIN' not in s:
 verify="""    // BLUE_VERIFY_BEGIN
    const loadedHash = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", wasm)), b => b.toString(16).padStart(2,"0")).join("");
    if (loadedHash !== BLUE_WASM_SHA256) {
      await ac.close();
      throw new Error("Modulo emulatore non corrispondente alla release. Chiudi il vecchio server e riapri questa copia: nessun dato salvato è stato cancellato");
    }
    // BLUE_VERIFY_END
"""
 s=s.replace(needle,verify+needle,1)
s=s.replace('status.textContent = ac.sampleRate === 44100 ? "On." : `On (the browser runs audio at ${ac.sampleRate} Hz).`;','status.textContent = `On · firmware Blue r9.4 verificato · WASM ${loadedHash.slice(0,12)} · ${ac.sampleRate} Hz`;')
assert 'cache: "no-store"' in s and 'loadedHash !== BLUE_WASM_SHA256' in s
index.write_text(s)
(root/'BUILD-ASSETS.json').write_text(__import__('json').dumps({'web_patch':'r9.4','firmware':'0.9.4-blue94','wasm_sha256':wasm,'worklet_sha256':worklet},indent=2)+'\n')
print('Pinned WASM',wasm)
