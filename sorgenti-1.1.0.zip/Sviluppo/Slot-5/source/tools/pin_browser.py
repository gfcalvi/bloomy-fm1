#!/usr/bin/env python3
from pathlib import Path
import hashlib,re
r=Path(__file__).resolve().parents[1];e=r/'app/build/emu'
for p in [r/'app/web/emu/index.html',e/'index.html']:
 s=p.read_text()
 for field,file in [('WASM','app.wasm'),('WORKLET','worklet.js')]:
  h=hashlib.sha256((e/file).read_bytes()).hexdigest()
  s=re.sub(r'(const BLUE_'+field+r'_SHA256 = ")[a-f0-9]+',lambda m:m[1]+h,s)
 p.write_text(s)
