#include <assert.h>
#include "../device/fm1_flash_ok.h"
static unsigned reads; static unsigned read_id(void){reads++;return 0xB36014u;}
int main(void){
assert(fm1b_flash_jedec_ok(0x856014u));assert(fm1b_flash_jedec_ok(0xB36014u));
assert(!fm1b_flash_jedec_ok(0));assert(!fm1b_flash_jedec_ok(0xffffffu));
assert(!fm1b_flash_jedec_ok(0xB36013u));assert(!fm1b_flash_jedec_ok(0xB36015u));
assert(!fm1b_flash_jedec_ok(0xEF4014u));assert(!fm1b_flash_jedec_ok(0x856015u));
assert(fm1b_flash_jedec_ok(read_id()));assert(reads==1);return 0;}
