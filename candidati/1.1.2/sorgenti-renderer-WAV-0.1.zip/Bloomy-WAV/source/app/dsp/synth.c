/* SPDX-License-Identifier: MPL-2.0 */
/* LOOM-8 voices: sixteen voices playing fourteen engines (synth.h), each with two ADSRs, a filter (six
 * types), a character stage (five types: drive, fold, crush, ring, tilt), a steal fade and sends; per track an LFO, a mono stack, parameter locks and
 * performance offsets.
 *
 * Time runs in SY_CHUNK (64-sample) chunks: at a chunk boundary a voice reads its track's parameters
 * (the knob, or its lock, plus the LFO's offset on the destination) and turns them into the units the
 * sample loop wants (increments, envelope rates, gains); inside the chunk only the per-sample state
 * moves, and the filter's coefficients refresh every 16 samples. A render of any length splits itself
 * at those boundaries, and every voice carries its own position in the chunk, so a block rendered as
 * 100 + 156 frames equals one of 256, and voices 0..8 on one core and 8..16 on the other never share a
 * word that either writes: the track-level values they read (LFO, pump, wobble) are computed into
 * per-chunk slots by synth_prepare() before the block is split. The LFO's fade envelope is the
 * voice's own (it counts from its note), so it scales the track's slot values per voice.
 *
 * Levels: an engine's raw cycle peaks near 1; the amp envelope, velocity (0.25 + 0.75 vel^2), the
 * preset volume ((v/127)^2) and the mix level (v/127) bring a default note to about -9 dBFS, so a
 * chord of six leaves the master's limiter something to do but not much. Float, no libm (fastmath.h),
 * no malloc, no stack buffer over 128 bytes in the render path (the audio interrupt's stack).
 *
 * knit's unison is NuSaw's (the NuSaw plugin, Copyright (c) Charles Vestal, MIT; through its FM-1 port, fm1-nusaw):
 * the detune offsets and curve, the pans, the keytracked high-pass. cane and voile are Mutable Instruments Braids'
 * models (Copyright 2012 Emilie Gillet, MIT), ported in dsp/braids.h (MIT), included below. */
#include "synth.h"
#include "fastmath.h"
#include "drumline.h"
#include "sample.h"
#include "wavetables.h"

#include "xmod.h"
#include "tweed.h"
static xm_bank_t xm; /* one audio engine, prepared before either rendering core reads it */
#define SUB 16                                /* filter coefficient refresh, steal fade steps */
#define NCK 8                                 /* chunk slots a prepare may cover (n <= 512) */
#define STEAL_RATE (1.0f / (0.015f * SY_SR))  /* the 15 ms steal fade, per sample */
#define INV_SR (1.0f / SY_SR)
#define CHUNK_S ((float)SY_CHUNK / SY_SR)     /* a chunk in seconds */
#define BRIGHT_SLEW 0.13f                    /* a chunk's share of the way: about 10 ms to 1 / e */
#define SLEW_SNAP 0.002f                     /* nearer than this: there (the engine's prep stops being redone) */
/* the engine knobs that glide (~10 ms, BRIGHT_SLEW) rather than step a chunk at a time, bit i = TP_E1 + i: the
 * continuous ones; a choice (a model, a table, a ratio, the voices, the organ's switches, a sample) jumps */
static const uint8_t E_GLIDE[NENGINE] = {
    0xB, /* knit: wave, detune, width (not the voices) */  0xD, /* rayon: bright, edge, tine (not the ratio) */
    0xE, /* jacquard: scan, bend, ripple (not the table) */ 0x0, /* bellows: four switches */
    0xE, /* cane: timbre, color, damp */ 0xE,               /* voile: timbre, color, breath */
    0x0, 0x0, 0x0, 0x0, 0x7};                                   /* sample, slice (where a note starts), the kit, midi */
static inline float glide_to(float from, float to)
{
    float d = to - from;
    return d < SLEW_SNAP && d > -SLEW_SNAP ? to : from + d * BRIGHT_SLEW;
}
#define LD_PITCH (-2)                         /* the LFO destination "pitch" (no TP_* holds it) */
#define LD_NONE (-1)
/* the sample loops must be inlined into their callers (the compiler folds their constant arguments
 * away); left to itself it outlines the bigger ones, at a call with thirty spills a sub-block */
#if defined(__GNUC__) || defined(__clang__)
#define SY_INLINE static inline __attribute__((always_inline))
#else
#define SY_INLINE static inline
#endif

/* ------------------------------------------------------------------ names --- */
const char *const RL_NAME[NRL] = {"bass", "lead", "pad", "keys", "pluck", "bell", "stab", "strings", "brass", "voice",
                                  "chord", "fx", "drum", "loop"};
const char *const EG_NAME[NENGINE] = {"knit", "rayon", "jacquard", "bellows", "cane", "voile", "sample", "slice",
                                      "kit", "midi", "tweed"};
const char *const EG_KNOB[NENGINE][4] = {
    {"wave", "detune", "voices", "width"}, {"bright", "ratio", "edge", "tine"},     {"table", "scan", "bend", "ripple"},
    {"stops", "pedal", "rotor", "rate"},   {"model", "timbre", "color", "damp"},   {"model", "timbre", "color", "breath"},
    {"sample", "start", "length", "mode"}, {"sample", "slices", "pitch", "gate"},  {"-", "-", "-", "-"},
    {"cc", "cc", "cc", "cc"}, {"pitch", "chirp", "decay", "-"}};                   /* (midi: each knob named by its CC, tp_info_par) */
/* each engine's plain sound (INIT), 0..127; bellows' four are discrete 1..8, knit's voices 1..7, the Braids engines'
 * models a name each (synth.h NCANE ...) */
static const char *const VMODE_N[3] = {"poly", "mono", "legato"};
static const char *const FTYPE_N[NFT] = {"lp24", "ladder", "lp12", "hp12", "bp12", "off"};   /* FT_DYNAMIC: no
                                                                          * filter on a synth track; the kit's
                                                                          * bus filter (on/off of its own) on a
                                                                          * drum track, never shown by this name */
static const char *const LTYPE_N[NLT] = {"off", "wave", "wobble", "drift", "pump"};
static const char *const VSHAPE_N[4] = {"square", "sine", "ramp", "saw"};
static const char *const TSHAPE_N[5] = {"sine", "saw", "expo", "square", "blip"};
static const char *const LDEST_N[NLD] = {"synth", "envelope", "filter", "voice", "synth free", "env free", "filter free",
                                         "voice free"};
static const char *const DUCK_N[11] = {"track 1", "track 2", "track 3", "track 4", "track 5", "track 6", "track 7",
                                       "track 8", "conductor", "throws", "metro"};
static const char *const PLAYER_N[NPL] = {"off", "arp", "strum", "hold"};
static const char *const ARPSPD_N[11] = {"1/4", "1/4T", "1/8", "1/8T", "1/16", "1/16T", "1/32", "1/32T", "1/64", "1/8D", "1/4D"};
static const char *const ARPPAT_N[6] = {"up", "down", "bounce", "bounce+", "played", "random"};
static const char *const ARPLEN_N[3] = {"short", "medium", "long"};
static const char *const ARPSTY_N[6] = {"off", "pedal", "thirds", "double", "skip", "swap"};
static const char *const ARPGLD_N[3] = {"off", "low", "high"};
static const char *const ARPSTE_N[3] = {"mono", "narrow", "wide"};
static const char *const MPAT_N[4] = {"up", "down", "updown", "random"};
static const char *const BRAIN_N[3] = {"no", "diatonic", "transp"};
static const char *const BEND_N[9] = {"off", "1", "2", "3", "4", "5", "6", "7", "octave"};
static const char *const WTNAME_N[WT_NTABLE] = {"shapes", "nasal", "grit", "vocal", "spiral", "fold", "octaves",
                                                "glass", "chirp"};
static const char *const SYNC_N[LS_SYNC_N] = {"2/1", "1", "1/2", "1/4", "1/8", "1/16", "1/32", "1/64"};
static const float SYNC_BEATS[LS_SYNC_N] = {8.0f, 4.0f, 2.0f, 1.0f, 0.5f, 0.25f, 0.125f, 0.0625f};
static const char *const ENVP_N[4] = {"attack", "decay", "sustain", "release"};
static const char *const FLTP_N[4] = {"cutoff", "reso", "env", "keytrack"};
static const char *const AMPP_N[4] = {"volume", "pitch", "pan", "character"};
static const char *const OCT_N[5] = {"-2", "-1", "0", "+1", "+2"};
static const char *const CTYPE_N[NCT] = {"off", "drive", "fold", "crush", "ring", "tilt", "tape", "sampler"};
static const char *const SMODE_N[NSM] = {"one-shot", "loop", "reverse", "ping-pong"};
static const char *const SLICES_N[SL_NCOUNT] = {"4", "8", "16", "32"};
static const char *const DFTYPE_N[NDF] = {"off", "lp", "hp", "bp"};
static const char *const CANE_N[NCANE] = {"pluck", "bow", "reed", "flute", "bell", "drum"};   /* (dsp/braids.h) */
static const char *const VOILE_N[NVOILE] = {"vosim", "vowel", "choir", "whisper"};
/* ring: the modulator's ratios to the note, tone / 8 */
static const float RING_R[16] = {0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.414f, 1.5f, 1.75f, 2.0f, 2.5f, 2.76f, 3.0f, 3.5f,
                                 4.0f, 5.0f, 7.0f};
static const char *const RING_N[16] = {"0.25:1", "0.5:1", "0.75:1", "1:1", "1.25:1", "1.41:1", "1.5:1", "1.75:1", "2:1",
                                       "2.5:1", "2.76:1", "3:1", "3.5:1", "4:1", "5:1", "7:1"};   /* (as stack's ratio) */
/* the LFO's module / knob to a parameter index */
static const int16_t LD_TP[4][4] = {{TP_E1, TP_E2, TP_E3, TP_E4},
                                    {TP_A, TP_D, TP_S, TP_R},
                                    {TP_CUT, TP_RES, TP_FENV, TP_KTRK},
                                    {TP_VOLUME, LD_PITCH, TP_PAN, TP_CAMT}};

/* --------------------------------------------------------------- structs --- */
enum { ENV_OFF, ENV_ATTACK, ENV_DECAY, ENV_SUSTAIN, ENV_RELEASE };
typedef struct { uint8_t stage; float level; } env_t;

/* a voice's chunk configuration: the parameters in sample-loop units */
typedef struct {
    float freq;                       /* Hz, after glide, bend, vibrato */
    float amp_ar, amp_dc, amp_sl, amp_rc, flt_ar, flt_dc, flt_sl, flt_rc;
    float cut_oct;                    /* log2(cutoff / 50 Hz) without the envelope */
    float fenv_oct;                   /* the filter envelope's reach, octaves */
    float kq;                         /* 1 / Q */
    float kres;                       /* the ladder's feedback 0..4 */
    float gl, gr;                     /* dry gains (pan, level, volume, velocity, wobble, pump) */
    float g1, g2;                     /* sends, relative to the dry level */
    float pitch_off;                  /* cents added to the note (bend, perf, vibrato, an LFO on pitch) */
    float e[4];                       /* the engine knobs 0..1 */
    float ek[4];                      /* the same, raw (the discrete knobs: 1..8, a table index) */
    float ex[23];                     /* the engine's derived values (eng_prep) */
    float cx[8];                      /* the character stage's values for the chunk (char_prep) */
    float cin[3];                     /* what cx[0..5] were made from (amount, tone, the ring's frequency) */
    uint8_t cin_type;                 /* and the type (0xFF: none yet) */
    uint8_t ftype, stereo, mute, eng;
    uint8_t ctype;                    /* the character stage running (CT_OFF: skipped, also at mix 0) */
} cfg_t;

typedef struct {
    float ph, ph2, env, lp, ar, rc, gain, inc, coef, id, last_pitch, last_freq, last_cut;
    uint8_t mode, type, attack, release;
} layer_t;

typedef struct {
    layer_t layer;
    uint8_t trk, held, engine, steal_phase;   /* held: the key is down; steal: 1 fading out, 2 in */
    uint8_t note, pend_note, pend_vel, pend_held;
    uint32_t tag, pend_tag, age;
    float vel, pitch, pitch_cur, glide_k;     /* semitones; glide_k: the chunk's approach fraction */
    int16_t pend_glide;
    uint16_t pos;                     /* sample in the chunk */
    uint8_t ck;                       /* chunk slot since prepare */
    uint8_t nchunk;                   /* chunks so far (the slow refreshes count on it, not on the block size) */
    env_t amp, flt;                   /* stepped once a sub-block (SUB samples) */
    uint8_t fresh;                    /* configured mid-block: refresh the coefficients before the next sample;
                                       * bit 1: started since the last render, its first configuration due there */
    uint8_t vi;                       /* the voice's index (its sample cache, smp_vc) */
    float cost_m;                     /* its render's measured time, clock ticks a frame (a running mean; 0 none yet) */
    uint8_t tws, tws_pend;            /* cane: the line slot it plays from, and its pending note's (CN_NONE) */
    float amp_cur, amp_step;          /* the amp level, ramped inside the sub-block */
    float steal_gain, sg_step;
    float glc, grc, gl_step, gr_step; /* the dry gains, ramped */
    float a1, a2, a3, b1, b2, b3;     /* the filter's coefficients (TPT SVF, lp24's second stage; the ladder's g and k) */
    float fhz, fkq, fkres;            /* what they were made from (a held note's are its last sub-block's: kept) */
    float fco, flv, ffe;              /* and what fhz was (the cutoff, the filter envelope's level and reach) */
    uint8_t fty;
    float f[8];                       /* filter: ic1 ic2 jc1 jc2 of L, then R (the ladder: its four poles a side) */
    float peak;
    float tsec;                       /* seconds since the note (the LFO's fade envelope counts on it) */
    uint32_t rng;
    cfg_t c;
    float env_in[8];                  /* the envelope knobs the coefficients were made from */
    float pan_in, pan_l, pan_r;       /* the pan the gains were made from, and those gains */
    float pitch_in, e_in[4];          /* the pitch and the knobs the frequency and increments were made from */
    float kp_w;                       /* knit_prep's pitch-free parts were made from: the width and the voices */
    int8_t kp_n;                      /* (0 or -1: none yet; knit_init) */
    float o[16];                      /* the engine's state */
    float cz[8];                      /* the character stage's: low-pass / hold L R, DC L R, phase, -, the
                                       * sampler's output filter L R (tape: cz[4..5] its wow's phases) */
} voice_t;
/* the sample engine's decoded windows (dsp/sample.h), a voice each: beside the struct, in RAM (the pool is
 * the scarcer); each is touched only by its own voice's render, on whichever core renders it */
static smp_cache_t smp_vc[NVOICE];
/* the sample engine's loop crossfades: a few caches for a voice's second read position while it crosses its loop
 * point (a voice finding none free jumps, as before): the voice holding each, NVOICE free */
#define SMP_NXF 4
static smp_cache_t smp_xc[SMP_NXF];
static uint8_t smp_xo[SMP_NXF] = {NVOICE, NVOICE, NVOICE, NVOICE};

#define NTP_LOCK TP_DRUM0             /* the synth's locks: the kit's own parameters never reach a voice */
typedef struct {
    uint8_t lock[NTP_LOCK];
    perf_t perf;
    int16_t bend_c;
    uint8_t pb_snap;                  /* a note started: the performance pitch jumps to its value, no glide */
    float pb_last, pb_base, pb_step;  /* the performance pitch (cents), glided across a stretch's chunks from the
                                       * last stretch's value: bends and the warble smooth in long stretches */
    uint8_t mono_n, mono_note[8], mono_vel[8];
    uint32_t mono_tag[8];
    int8_t mono_voice;
    float last_pitch;                 /* the previous note: poly glide starts here */
    float cost_m;                     /* its voices' measured time (voice_t cost_m): a new note's first guess */
    float lfo_ph, lfo_sh, lfo_sm;     /* the LFO's phase, the drift's target and its slewed value */
    float duck, duck_hold;            /* the pump's level 0..1 and the hold time left, seconds */
    float lf_in, lf_out;              /* the fade envelope: seconds to fade in (or out), 0 = none */
    float lscale;                     /* the destination's range / 127: the offset in the knob's units */
    int16_t ldest;                    /* the resolved destination: a TP_* index, LD_PITCH or LD_NONE */
    uint32_t rng;
    float loff[NCK], lpitch[NCK], lgain[NCK];   /* the chunk slots: offset (param units), cents, gain */
} trk_t;

struct synth {
    uint8_t (*par)[NTP];
    float bpm;
    uint32_t counter;                 /* voice ages */
    uint16_t pos;                     /* chunk phase at the next prepare */
    uint8_t nck, max_voices;
    float load_pred;                  /* the load this block will reach, %: the last block's (synth_load_hint) and the
                                       * voices started since (find_voice); 0: not known (the host) */
    trk_t t[NTRK];
    voice_t v[NVOICE];
    float goff[NCK];                  /* the shared LFO's offset at each chunk of the block (knob units, +-127) */
    float g_ph, g_sh, g_now;          /* its phase, its random value, its value at the block's end (-1..1) */
    uint32_t g_rng;                   /* (its random steps' generator)*/
    volatile uint8_t g_reset;         /* restart at the next prepare (the transport started) */
};
uint32_t synth_load_steals;           /* new notes that took a sounding voice to stay inside LOAD_ADMIT (synth.h) */
_Static_assert(sizeof(struct synth) <= SYNTH_BYTES, "synth_t outgrew SYNTH_BYTES");
#ifdef PLAT_HOST
uint16_t synth_host_solo = 0xFFFFu;           /* the host's stems: bits 0-7 the tracks, 8 / 9 the FX returns */
int synth_sizeof(void) { return (int)sizeof(struct synth); }
#endif

volatile uint16_t synth_peak[NTRK];
uint32_t (*synth_clock)(void);
volatile uint32_t synth_prof[2][NENGINE + 1];
volatile uint32_t synth_vblk[NVOICE];                 /* each voice's time this block (the profiler; engine.c clears it) */
volatile uint8_t synth_vinfo[NVOICE];                 /* and what it was: engine | 32 started this block | 64 core 1 | 128 sounded */
volatile uint32_t synth_vworst[3];                   /* the slowest voice render since the reader cleared it: its time, its
                                                      * engine, its frames */

/* ------------------------------------------------------------ small maths --- */
static inline uint32_t xs(uint32_t *r)
{
    uint32_t x = *r;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    *r = x;
    return x;
}
static inline float frand(uint32_t *r) { return (float)(int32_t)xs(r) * (1.0f / 2147483648.0f); }   /* -1..1 */
static inline float blep(float t, float dt, float idt)      /* the PolyBLEP residual at phase t, step dt */
{
    if (t < dt) {
        t *= idt;
        return t + t - t * t - 1.0f;
    }
    if (t > 1.0f - dt) {
        t = (t - 1.0f) * idt;
        return t * t + t + t + 1.0f;
    }
    return 0.0f;
}
static inline float wrap1(float p) { return p - fm_floorf(p); }
static inline float step1(float p, float d)      /* a phase accumulator: p + d wrapped to [0, 1), d < 1 */
{
    p += d;
    return p >= 1.0f ? p - 1.0f : p;
}
static inline float soft3(float x)               /* a cubic soft clip: linear near 0, flat at +-1.5 */
{
    x = fm_minf(fm_maxf(x, -1.5f), 1.5f);        /* (the FPU's max and min: two instructions; fm_clampf takes four) */
    return x - x * x * x * (4.0f / 27.0f);
}
static float env_seconds(float p) { return p < 0.001f ? 0.001f : 0.001f * fm_exp2f(p * 13.2877124f); }  /* 1 ms .. 10 s */
/* the envelopes step once a sub-block of SUB samples: the attack's increment, the decay's and the
 * release's multiplier (to 0.1 % in secs) for that step */
static float layer_release_seconds(float p) { return 0.001f*fm_exp2f(p*5.90689060f); } /* 1ms..60ms: bounded extra voice tails */
static float env_rate(float secs) { return (float)SUB / (secs * SY_SR); }
static float env_coef(float secs) { return fm_expf(-6.9f * (float)SUB / (secs * SY_SR)); }
static float lfo_hz(int v, float bpm)
{
    if (v < LS_SYNC_N)
        return bpm * (1.0f / 60.0f) / SYNC_BEATS[v];
    return 0.1f * fm_exp2f((float)(v - LS_SYNC_N) * (8.22881869f / 119.0f));   /* 0.1 .. 30 Hz */
}
/* the LFO's fade envelope knob (synth.h): seconds to fade in, or to fade out */
static void fade_secs(int v, float *in, float *out)
{
    *in = *out = 0.0f;
    if (v < 64)
        *in = (float)(64 - v) * (3.0f / 64.0f);
    else if (v > 64)
        *out = fm_maxf((float)(127 - v) * (3.0f / 63.0f), 0.05f);
}

static inline void env_step(env_t *e, float ar, float dc, float sl, float rc)
{
    switch (e->stage) {
    case ENV_ATTACK:
        e->level += ar;
        if (e->level >= 1.0f) {
            e->level = 1.0f;
            e->stage = ENV_DECAY;
        }
        break;
    case ENV_DECAY:
        e->level = sl + (e->level - sl) * dc;
        if (e->level <= sl + 0.0001f) {
            e->level = sl;
            e->stage = ENV_SUSTAIN;
        }
        break;
    case ENV_SUSTAIN: e->level = sl; break;
    case ENV_RELEASE:
        e->level *= rc;
        if (e->level < 0.0001f) {
            e->level = 0.0f;
            e->stage = ENV_OFF;
        }
        break;
    default: e->level = 0.0f; break;
    }
}

/* ----------------------------------------------------------- parameters --- */
static inline int P(const synth_t *s, int trk, int p)      /* the knob, or its lock */
{
    uint8_t l = p >= TP_LAYER_MODE && p < TP_LAYER_END ? xm.layer_lock[trk][p-TP_LAYER_MODE] : s->t[trk].lock[p];
    return l != LOCK_NONE ? l : s->par[trk][p];
}
/* the effective value: the LFO adds to its destination (clamped to the byte; the knob's own range is
 * applied by the engine that reads it) */
static int xmod_cfg(const synth_t *s, int trk, int f)
{
    int v=xm.lock[trk][f];
    return v==LOCK_NONE ? s->par[trk][TP_XMOD0+f] : v;
}
static float xmod_param(int trk, int p, int k);
static inline float pf(const synth_t *s, int trk, int p, int dest, float off, int k)
{
    float x = (float)P(s, trk, p);
    if (p == dest)
        x = fm_clampf(x + off, 0.0f, 127.0f);
    if (xm.active[trk]) x = fm_clampf(x + xmod_param(trk, p, k), 0.0f, 127.0f);
    return x;
}

/* ----------------------------------------------------------- the engines --- */
/* each: eng_prep() turns c.e[] / c.ek[] and c.freq into c.ex[] once a chunk (or after a steal);
 * eng_run() writes m <= SUB raw samples to xl (and xr when c.stereo); the amplitude of a cycle is
 * about 1; eng_chunk() moves the engine's own slow parts every chunk */
static void knit_init(voice_t *v);
static void cn_init(voice_t *v);
static void vo_init(voice_t *v);
static void eng_init(voice_t *v)
{
    int i;
    for (i = 0; i < 16; i++)
        v->o[i] = 0.0f;
    smp_cache_reset(&smp_vc[v->vi % NVOICE]);
    for (i = 0; i < SMP_NXF; i++)                /* (a crossfade it held: free) */
        if (smp_xo[i] == v->vi)
            smp_xo[i] = NVOICE;
    if (v->engine == EG_BELLOWS)
        for (i = 0; i < 6; i++)
            v->o[i * 2] = 1.0f;                  /* the rotating phasors start at 1 + 0i */
    if (v->engine == EG_KNIT)
        knit_init(v);
    if (v->engine == EG_RAYON)
        v->o[5] = v->o[7] = 1.0f;                /* rayon: its fall and its tine start full */
    if (v->engine == EG_BELLOWS)
        v->o[13] = 1.0f, v->o[14] = 0.0f;        /* the rotor's gain and its ramp */
    if (v->engine == EG_CANE)
        cn_init(v);
    else if (v->engine == EG_VOILE)
        vo_init(v);
}

/* a rising saw crossfading into a pulse that is low first and high after pw: the two in step, so the
 * morph keeps its level (a pulse high first would cancel the saw's fundamental halfway). The pulse's
 * second edge sits at p + 1 - pw in (0.5, 2): its wrap is a compare (the same bits as wrap1's floor) */
/* saw .. pulse by mix (0..1, > 0 here) at width pw, PolyBLEP'd: a pulse is a saw less the saw a width on (q =
 * p + 1 - pw, wrapped), plus 1 - 2 pw, so the blend is 2 p - 2 mix q + (2 mix (1 - pw) - 1), less the saw's residual
 * at p, plus mix the residual at q. k: its constants (saw_pulse_k) */
typedef struct { float a, m2, c, mix; } sawp_t;
static inline sawp_t saw_pulse_k(float pw, float mix)
{
    sawp_t k = {1.0f - pw, 2.0f * mix, 2.0f * mix * (1.0f - pw) - 1.0f, mix};
    return k;
}
SY_INLINE float saw_pulse(float p, float dt, float idt, sawp_t k)
{
    float q = p + k.a;
    q = q >= 1.0f ? q - 1.0f : q;
    return 2.0f * p - k.m2 * q + k.c - blep(p, dt, idt) + k.mix * blep(q, dt, idt);
}
/* wavetable: a frame crossfade (scan) through one of nine tables, bend bends the phase (symmetry), ripple
 * phase-modulates it by a second oscillator that climbs from a slow wobble to the note's own rate */
static void wt_prep(voice_t *v)
{
    cfg_t *c = &v->c;
    float pos = c->e[1] * (float)(WT_NFRAME - 1), fr = fm_floorf(pos), dr = c->e[3];
    c->ex[0] = fm_minf(c->freq * INV_SR, 0.45f);
    c->ex[1] = fm_clampf(fm_floorf(c->ek[0] + 0.5f), 0.0f, (float)(WT_NTABLE - 1));
    c->ex[2] = fm_minf(fr, (float)(WT_NFRAME - 2));
    c->ex[3] = pos - c->ex[2];
    c->ex[4] = 0.5f + c->e[2] * 0.45f;           /* the warp point: 0.5 = straight */
    c->ex[5] = dr > 0.001f ? c->freq * fm_exp2f(-7.0f + 8.0f * dr) * INV_SR : 0.0f;   /* 1/128 .. 2x the note */
    c->ex[6] = dr * dr * 0.6f;                   /* depth, turns */
    c->stereo = 0;
}
static void wt_run(voice_t *v, float *xl, float *xr, int m)
{
    const cfg_t *c = &v->c;
    const int8_t *ta = WT[(int)c->ex[1]][(int)c->ex[2]], *tb = ta + WT_N;
    float p = v->o[0], mp = v->o[1], d = c->ex[0], md = c->ex[5], fb = c->ex[3], w = c->ex[4];
    float ka = 0.5f / w, kb = 0.5f / (1.0f - w), depth = c->ex[6];
    int i;
    (void)xr;
    for (i = 0; i < m; i++) {
        float q, s, fa, a, b;
        int k;
        p = step1(p, d);
        q = p < w ? p * ka : 0.5f + (p - w) * kb;
        if (md > 0.0f) {
            mp = step1(mp, md);
            q = wrap1(q + depth * fm_sin_turns(mp));
        }
        s = q * (float)WT_N;
        k = (int)s;
        fa = s - (float)k;
        k &= WT_N - 1;
        a = (float)ta[k] + ((float)ta[(k + 1) & (WT_N - 1)] - (float)ta[k]) * fa;
        b = (float)tb[k] + ((float)tb[(k + 1) & (WT_N - 1)] - (float)tb[k]) * fa;
        xl[i] = (a + (b - a) * fb) * (1.0f / 128.0f);
    }
    v->o[0] = p;
    v->o[1] = mp;
}

/* rayon (was orbit): two-operator FM, the DX's way, for e-pianos, bells, mallets and basses. bright = the index (velocity
 * sets how much of it a note gets: 0.4 .. 1 of it); ratio from a detuned 1:1 (0..50: slow beating) to the modulator's
 * ratios (51..100: RAYON_RATIO, the bells' inharmonic ones among them); edge = the modulator's feedback (sine toward
 * saw); tine = a 14:1 partial struck with the note and dying in ~0.25 s, by velocity (the e-piano's bark, tines'
 * bell). Its second page (TP_X1..X3, RAYON_X_P): fall, the index falling from the note's start (0 = held; else a time
 * constant 20 ms .. 4 s); floor, what of it remains (0..100 %); keyscale, the index lower for higher notes (0 .. -6 dB
 * an octave above C3). o[0..2] the carrier, the modulator, the feedback; o[5] the fall (1 at the note's start); o[6]
 * the tine's phase, o[7] its envelope. ex[0] / ex[1] the increments, ex[2] the index now (rayon_chunk: the fall),
 * ex[3] the feedback, ex[4] the tine's level at the start, ex[5] its increment, ex[8..10] the second page's
 * (voice_chunk), ex[11] the index before the fall */
static const float RAYON_RATIO[16] = {0.5f, 0.6666667f, 0.75f, 1.25f, 1.3333334f, 1.4142135f, 1.5f, 1.75f, 2.0f, 2.5f,
                                      3.0f, 3.5f, 4.0f, 5.0f, 7.0f, 8.0f};
static void rayon_prep(voice_t *v)
{
    cfg_t *c = &v->c;
    float r = c->e[1] * 100.0f, ratio, vs = 0.4f + 0.6f * v->vel;
    if (r <= 50.0f)
        ratio = fm_exp2f(r * 0.6f * (1.0f / 1200.0f));          /* 0 .. 30 cents */
    else {
        int k = (int)((r - 51.0f) * (15.99f / 49.0f));
        ratio = RAYON_RATIO[k < 0 ? 0 : k > 15 ? 15 : k];
    }
    c->ex[0] = fm_minf(c->freq * INV_SR, 0.45f);
    c->ex[1] = fm_minf(c->freq * ratio * INV_SR, 0.45f);
    c->ex[2] = c->e[0] * c->e[0] * 5.0f * vs;                   /* index, turns */
    if (c->ex[10] > 0.0f && c->freq > 130.81f)                  /* keyscale: the index an octave above C3 x 2^-k */
        c->ex[2] *= fm_exp2f(-c->ex[10] * fm_log2f(c->freq * (1.0f / 130.81f)));
    c->ex[11] = c->ex[2];                                        /* (the index before the fall: rayon_chunk) */
    c->ex[3] = c->e[2] * 1.3f;                                  /* feedback */
    c->ex[5] = c->freq * 14.0f * INV_SR;                         /* the tine: 14:1, only while under 0.45 */
    c->ex[4] = c->ex[5] < 0.45f ? c->e[3] * 0.5f * vs : 0.0f;
    c->stereo = 0;
}
static void rayon_run(voice_t *v, float *xl, float *xr, int m)
{
    const cfg_t *c = &v->c;
    float cp = v->o[0], mp = v->o[1], fbv = v->o[2];
    float dc = c->ex[0], dm = c->ex[1], idx = c->ex[2] * 0.25f, fb = c->ex[3] * 0.25f, tl = c->ex[4] * v->o[7];
    int i;
    (void)xr;
    for (i = 0; i < m; i++) {
        float mo;
        mp = step1(mp, dm);
        cp = step1(cp, dc);
        mo = fm_sin_turns(mp + fbv * fb);
        fbv = mo;
        xl[i] = fm_sin_turns(cp + mo * idx);
    }
    if (tl > 1e-4f) {                            /* the tine, added */
        float tp = v->o[6], dt = c->ex[5];
        for (i = 0; i < m; i++) {
            tp = step1(tp, dt);
            xl[i] += fm_sin_turns(tp) * tl;
        }
        v->o[6] = tp;
    }
    v->o[0] = cp;
    v->o[1] = mp;
    v->o[2] = fbv;
}
static void rayon_chunk(voice_t *v)              /* the fall, the tine's decay */
{
    cfg_t *c = &v->c;
    if (c->ex[8] > 0.0f) {                       /* the fall: o[5] 1 at the note's start, toward 0 */
        c->ex[2] = c->ex[11] * (c->ex[9] + (1.0f - c->ex[9]) * v->o[5]);
        v->o[5] *= c->ex[8];
    }
    v->o[7] *= 0.994f;                           /* the tine: ~0.25 s (tines') */
}

/* organ: six drawbars (16' 8' 4' 2 2/3' 2' 1 1/3') as rotating phasors (a complex multiply a sine:
 * no polynomial). stops picks one of eight registrations, transistor to church; pedal 1..8 is the 16'
 * bar; the rotor's amount and rate are 1..8 (1 = none / slowest) */
static const float ORGAN_SET[8][5] = {{1.0f, 0.15f, 0.0f, 0.6f, 0.0f},    /* 1 transistor: reedy, hollow */
                                      {1.0f, 0.6f, 0.0f, 0.4f, 0.2f},     /* 2 combo: bright, thin */
                                      {1.0f, 0.7f, 0.5f, 0.1f, 0.0f},     /* 3 jazz */
                                      {1.0f, 0.9f, 0.7f, 0.7f, 0.5f},     /* 4 gospel: all bars out */
                                      {1.0f, 0.8f, 0.6f, 0.3f, 0.3f},     /* 5 rock */
                                      {1.0f, 0.5f, 0.35f, 0.5f, 0.6f},    /* 6 theatre */
                                      {1.0f, 0.4f, 0.1f, 0.2f, 0.05f},    /* 7 pipe: flutes */
                                      {1.0f, 0.8f, 0.9f, 0.9f, 0.9f}};    /* 8 church: the full chorus */
static const float ORGAN_RATIO[6] = {0.5f, 1.0f, 2.0f, 3.0f, 4.0f, 6.0f};
static inline int knob8(float raw) { int k = (int)(raw + 0.5f); return k < 1 ? 1 : k > 8 ? 8 : k; }
/* the drawbars the stops and the pedal ask for (bars[0..5]) and the rotor's depth (*amt): organ_chunk glides the
 * voice's toward them (a stop changed while a note sounds: no click); a new note starts at them (organ_prep) */
static void organ_want(const cfg_t *c, float *bars, float *amt)
{
    int k = knob8(c->ek[0]) - 1, j;
    float bass = (float)(knob8(c->ek[1]) - 1) * (1.0f / 7.0f), sum = bass;
    *amt = (float)(knob8(c->ek[2]) - 1) * (1.0f / 7.0f);
    bars[0] = bass * 0.8f;
    for (j = 1; j < 6; j++) {
        bars[j] = ORGAN_SET[k][j - 1];
        sum += bars[j];
    }
    sum = 1.4f / (sum + 0.5f);                  /* the bars share a level near the other engines' */
    for (j = 0; j < 6; j++)
        bars[j] *= sum;
}
static void organ_prep(voice_t *v)
{
    cfg_t *c = &v->c;
    int j;
    float tr = 0.5f * fm_exp2f((float)(knob8(c->ek[3]) - 1) * (4.0f / 7.0f)) * INV_SR, base, amt;   /* 0.5 .. 8 Hz */
    if (v->fresh) {                             /* (sounding: organ_chunk glides them) */
        float bars[6];
        organ_want(c, bars, &amt);
        for (j = 0; j < 6; j++)
            c->ex[j] = bars[j];
        c->ex[19] = amt;
    }
    amt = c->ex[19];
    c->ex[18] = tr;
    base = c->freq * INV_SR * (1.0f + amt * 0.004f * fm_sin_turns(v->o[12]));   /* the tremolo's pitch wobble */
    for (j = 0; j < 6; j++) {
        float a = fm_minf(base * ORGAN_RATIO[j], 0.45f) * FM_TWO_PI, re = v->o[j * 2], im = v->o[j * 2 + 1], r2;
        c->ex[6 + j] = fm_cosf(a);
        c->ex[12 + j] = fm_sinf(a);
        r2 = re * re + im * im;                  /* renormalise the phasor once a chunk */
        if (r2 > 0.5f) {
            float g = fm_rsqrtf(r2);
            v->o[j * 2] = re * g;
            v->o[j * 2 + 1] = im * g;
        } else {
            v->o[j * 2] = 1.0f;
            v->o[j * 2 + 1] = 0.0f;
        }
    }
    c->stereo = 0;
}
void organ_bars(const uint8_t *par, float bars[6])
{
    int k = knob8((float)par[TP_E1]) - 1, j;
    float mx = 0.0f;
    bars[0] = (float)(knob8((float)par[TP_E2]) - 1) * (1.0f / 7.0f) * 0.8f;
    for (j = 1; j < 6; j++)
        bars[j] = ORGAN_SET[k][j - 1];
    for (j = 0; j < 6; j++)
        mx = fm_maxf(mx, bars[j]);
    for (j = 0; j < 6; j++)
        bars[j] /= mx;
}
static void organ_run(voice_t *v, float *xl, float *xr, int m)
{
    const cfg_t *c = &v->c;
    float re[6], im[6];
    const float *cr = c->ex + 6, *ci = c->ex + 12;
    int i, j;
    (void)xr;
    for (j = 0; j < 6; j++) {
        re[j] = v->o[j * 2];
        im[j] = v->o[j * 2 + 1];
    }
    {   /* the tremolo: its gain ramps across the chunk (organ_chunk aims it) */
        float g0 = v->o[13], dg = v->o[14];
        for (i = 0; i < m; i++) {
            float s = 0.0f;
            for (j = 0; j < 6; j++) {
                float nr = re[j] * cr[j] - im[j] * ci[j];
                im[j] = re[j] * ci[j] + im[j] * cr[j];
                re[j] = nr;
                s += im[j] * c->ex[j];
            }
            g0 += dg;
            xl[i] = s * g0;
        }
        v->o[13] = g0;
    }
    for (j = 0; j < 6; j++) {
        v->o[j * 2] = re[j];
        v->o[j * 2 + 1] = im[j];
    }
}
static void organ_chunk(voice_t *v)              /* the drawbars' glide, the tremolo's phase and the chunk's gain ramp */
{
    cfg_t *c = &v->c;
    float g1, bars[6], amt;
    int j;
    organ_want(c, bars, &amt);
    for (j = 0; j < 6; j++)
        c->ex[j] = glide_to(c->ex[j], bars[j]);
    c->ex[19] = glide_to(c->ex[19], amt);
    v->o[12] = wrap1(v->o[12] + c->ex[18] * (float)SY_CHUNK);
    g1 = 1.0f - c->ex[19] * 0.5f * (0.5f - 0.5f * fm_sin_turns(v->o[12]));
    v->o[14] = (g1 - v->o[13]) * (1.0f / (float)SY_CHUNK);
}

/* knit's unison: the voices' detune offsets by pairs (n / 2), the JP-8000's table at six or seven (after NuSaw,
 * the NuSaw plugin, MIT, and its FM-1 port fm1-nusaw: brocade's, the supersaw this replaces); NuSaw's detune curve
 * (fine at first, wide at the end); and its keytracked high-pass (12 dB at a third of the note, the JP-8000's), which
 * keeps a unison's beating out of the bass */
static const float KNIT_COEF[4][7] = {
    {0.0f},
    {0.0f, 1.0f, -1.0f},
    {0.0f, 1.0f / 3.0f, -1.0f / 3.0f, 1.0f, -1.0f},
    {0.0f, 128.0f / 720.0f, -128.0f / 720.0f, 408.0f / 720.0f, -412.0f / 720.0f, 704.0f / 720.0f, -1.0f}};
static inline float knit_detune(float x)
{
    if (x < 0.1f)
        return x * 0.2f;
    if (x < 0.5f)
        return 0.02f + (x - 0.1f) * 0.575f;
    return 0.25f + (x - 0.5f) * 1.5f;
}
SY_INLINE void knit_hp(float *x, float *lo, float *bp, float f, int m)
{
    float l = *lo, b = *bp;
    int i;
    for (i = 0; i < m; i++) {
        float h = x[i] - l - 1.4f * b;
        b += f * h;
        l += f * b;
        x[i] = h;
    }
    *lo = fm_flush(l);
    *bp = fm_flush(b);
}
/* knit: the everyday subtractive voice. wave: saw (0) .. square (the middle) .. a 10 % pulse (saw_pulse:
 * the LFO on it is PWM); voices 1..7: a unison of that wave, detuned by the JP-8000's offsets (KNIT_COEF) as detune opens, each pair across the field as width opens, all at one power (1 / sqrt n); at one voice
 * detune is a drift instead, the pitch wandering slowly (up to +-12 cents, a fresh target every ~0.4 s). Its second
 * page (TP_X1..X4, KNIT_X_P): osc 2, one more of the wave at an interval (+-24 semitones about 64) and its level (0 off),
 * detune also tuning it up to 20 cents above the interval (two oscillators beating, at any number of voices);
 * sub, a sine an octave down; noise. A unison's beating is kept out of the bass by brocade's keytracked high-pass.
 * o[0..6] the voices' phases (random at the start), o[7] osc 2's, o[8] the sub's, o[10] the drift (cents) and o[11]
 * its target, o[12..15] the high-pass (low and band, L then R). ex[0] the increment, ex[1] the detune's, ex[2] the
 * voices, ex[3] the pulse's mix, ex[4] its width, ex[5..10] the pairs' L and R gains, ex[11] the high-pass's, ex[12]
 * a voice's gain, ex[13] osc 2's increment, ex[14] its gain, ex[15] the sub's increment, ex[16] its gain, ex[17]
 * the noise's, ex[18..21] the second page's knobs (voice_chunk), ex[22] the drift's factor (knit_chunk). */
#define KNIT_MAX 7
#define KNIT_OSC2_DETUNE (20.0f / 1200.0f)      /* detune at full: osc 2 that many octaves (20 cents) above its interval */
static void knit_prep(voice_t *v)
{
    cfg_t *c = &v->c;
    int n = (int)fm_clampf(fm_floorf(c->ek[2] + 0.5f), 1.0f, (float)KNIT_MAX), M = n / 2, k;
    float f = c->freq * INV_SR, w = c->e[3];
    c->ex[0] = fm_minf(f, 0.45f);
    c->ex[1] = n > 1 ? f * 0.1102f * knit_detune(c->e[1]) : 0.0f;
    c->ex[2] = (float)n;
    if (c->e[0] < 0.5f) {                        /* saw .. square */
        c->ex[3] = c->e[0] * 2.0f;
        c->ex[4] = 0.5f;
    } else {                                     /* square .. a 10 % pulse */
        c->ex[3] = 1.0f;
        c->ex[4] = 0.5f - (c->e[0] - 0.5f) * 0.8f;
    }
    const int kp_fresh = v->kp_n <= 0;           /* (no cache yet: knit_init, or a voice never prepared) */
    if (kp_fresh || v->kp_n != n || v->kp_w != w) {   /* (the pairs' gains and a voice's: only when width or voices moved;
                                                  * the tape's wow moves the pitch every chunk) */
        for (k = 1; k <= 3; k++) {               /* pair k: its upper voice towards the right, its lower the left */
            float a = (1.0f + (M ? (float)(k < M ? k : M) / (float)M * w : 0.0f)) * 0.78539816f;
            c->ex[3 + 2 * k] = fm_cosf(a) * 1.41421356f;
            c->ex[4 + 2 * k] = fm_sinf(a) * 1.41421356f;
        }
        c->ex[12] = fm_rsqrtf((float)n);
        v->kp_n = (int8_t)n;
        v->kp_w = w;
    }
    c->ex[11] = fm_minf(2.07345f * f, 0.9f);    /* the high-pass at a third of the note (brocade's) */
    if (c->ex[19] > 0.0f)                        /* osc 2's increment: only when it sounds (its level: ex[14]; a
                                                  * level turned up moves a knob, so this runs again) */
        c->ex[13] = fm_minf(f * fm_exp2f((c->ex[18] - 64.0f) * (1.0f / 12.0f) + c->e[1] * KNIT_OSC2_DETUNE), 0.45f);
    c->ex[14] = c->ex[19] * (1.0f / 127.0f);
    c->ex[15] = f * 0.5f;
    c->ex[16] = c->ex[20] * (1.0f / 127.0f);
    c->ex[17] = c->ex[21] * (0.5f / 127.0f);
    if (c->ex[22] <= 0.0f)
        c->ex[22] = 1.0f;
    c->stereo = w > 0.001f && n > 1;
}
static void knit_chunk(voice_t *v)                 /* the drift at one voice: toward a fresh target, slowly */
{
    cfg_t *c = &v->c;
    float depth = c->ex[2] < 1.5f ? c->e[1] * 12.0f : 0.0f;
    if (depth <= 0.0f) {
        c->ex[22] = 1.0f;
        return;
    }
    if ((v->nchunk & 255) == 0)                  /* (~0.4 s) */
        v->o[11] = (float)(int32_t)xs(&v->rng) * (1.0f / 2147483648.0f) * depth;
    v->o[10] += (v->o[11] - v->o[10]) * 0.01f;
    c->ex[22] = fm_exp2f(v->o[10] * (1.0f / 1200.0f));
}
/* one oscillator into the buffers (set: first, or added), a run at a time: between its edges (the saw's wrap at 1,
 * the pulse's where q = p + 1 - pw wraps) the wave is a plain ramp, and the PolyBLEP's residuals are 0 but on the
 * samples beside an edge (blep: t < dt after it, t > 1 - dt before it). So a run whose samples are all clear of the
 * edges goes without the edge tests and residuals (a pad's note at 110 Hz: 2 such samples in 400), and the samples
 * near an edge take the full path. The same samples as knit_osc's: a residual of 0 changes nothing, and a run is
 * found one sample short, so rounding never puts an edge's sample in it. */
SY_INLINE void knit_osc_seg(float *ph, float d, float pw, float mix, float gl, float gr, float *xl, float *xr, int m,
                          const int stereo, const int first)
{
    float p = *ph, id = 1.0f / d;
    sawp_t k = saw_pulse_k(pw, mix);
    const int pulse = mix > 0.0f;
    int i = 0;
    while (i < m) {
        float pn = p + d;
        if (pn >= d && pn <= 1.0f - d && !(pulse && pn > pw - d && pn < pw + d)) {   /* clear of the edges */
            float lim = pulse && pn < pw ? pw - d : 1.0f - d, fr = (lim - p) * id;
            int run = (fr > (float)(m - i + 1) ? m - i + 1 : (int)fr) - 1, j;
            if (run >= 1) {
                if (!pulse) {
                    for (j = 0; j < run; j++, i++) {
                        float x;
                        p += d;
                        x = 2.0f * p - 1.0f;
                        if (first) {
                            xl[i] = x * gl;
                            if (stereo)
                                xr[i] = x * gr;
                        } else {
                            xl[i] += x * gl;
                            if (stereo)
                                xr[i] += x * gr;
                        }
                    }
                } else {
                    const int hi = pn >= pw;             /* (q has wrapped: the run is all past the pulse's edge) */
                    for (j = 0; j < run; j++, i++) {
                        float x, q;
                        p += d;
                        q = p + k.a;
                        if (hi)
                            q = q - 1.0f;
                        x = 2.0f * p - k.m2 * q + k.c;
                        if (first) {
                            xl[i] = x * gl;
                            if (stereo)
                                xr[i] = x * gr;
                        } else {
                            xl[i] += x * gl;
                            if (stereo)
                                xr[i] += x * gr;
                        }
                    }
                }
                continue;
            }
        }
        {   /* beside an edge: the full path */
            float x;
            p = step1(p, d);
            x = !pulse ? 2.0f * p - 1.0f - blep(p, d, id) : saw_pulse(p, d, id, k);
            if (first) {
                xl[i] = x * gl;
                if (stereo)
                    xr[i] = x * gr;
            } else {
                xl[i] += x * gl;
                if (stereo)
                    xr[i] += x * gr;
            }
            i++;
        }
    }
    *ph = p;
}
SY_INLINE void knit_loop(voice_t *v, float *xl, float *xr, int m, const int stereo)
{
    const cfg_t *c = &v->c;
    const int n = (int)c->ex[2];
    const float *co = KNIT_COEF[n / 2], mix = c->ex[3], pw = c->ex[4], g = c->ex[12], dr = c->ex[22];
    float d[KNIT_MAX + 1], gg[2 * KNIT_MAX + 2];
    int i, k;
    for (k = 0; k < n; k++) {                    /* the voices: the centre, then the pairs (upper right, lower left) */
        d[k] = fm_clampf((c->ex[0] + co[k] * c->ex[1]) * dr, 1e-6f, 0.45f);
        gg[2 * k] = gg[2 * k + 1] = g;
        if (k && stereo) {
            const float *pn = &c->ex[3 + 2 * ((k + 1) >> 1)];
            gg[2 * k] = g * pn[~k & 1];
            gg[2 * k + 1] = g * pn[k & 1];
        }
    }
    for (k = 0; k < n; k++)                      /* the voices: the centre first (it sets the buffers), then the pairs */
        if (k)
            knit_osc_seg(&v->o[k], d[k], pw, mix, gg[2 * k], gg[2 * k + 1], xl, xr, m, stereo, 0);
        else
            knit_osc_seg(&v->o[0], d[0], pw, mix, gg[0], gg[1], xl, xr, m, stereo, 1);
    if (n > 1) {
        knit_hp(xl, &v->o[12], &v->o[13], c->ex[11], m);
        if (stereo)
            knit_hp(xr, &v->o[14], &v->o[15], c->ex[11], m);
    }
    if (!v->layer.mode && c->ex[14] > 0.0f) {                      /* osc 2: one more, in the middle */
        float d = fm_clampf(c->ex[13] * dr, 1e-6f, 0.45f);
        knit_osc_seg(&v->o[7], d, pw, mix, c->ex[14], c->ex[14], xl, xr, m, stereo, 0);
    }
    if (c->ex[16] > 0.0f || c->ex[17] > 0.0f) {  /* the sub (a sine an octave down) and the noise */
        float p = v->o[8], d = c->ex[15] * dr, gs = c->ex[16], gn = c->ex[17];
        for (i = 0; i < m; i++) {
            float x;
            p = step1(p, d);
            x = fm_sin_pi((p < 0.5f ? p : p - 1.0f) * FM_TWO_PI) * gs + frand(&v->rng) * gn;
            xl[i] += x;
            if (stereo)
                xr[i] += x;
        }
        v->o[8] = p;
    }
}
static void knit_run(voice_t *v, float *xl, float *xr, int m)
{
    if (v->c.stereo)
        knit_loop(v, xl, xr, m, 1);
    else
        knit_loop(v, xl, xr, m, 0);
}
static void knit_init(voice_t *v)                  /* the voices from random phases */
{
    int j;
    for (j = 0; j < KNIT_MAX; j++)
        v->o[j] = (float)(xs(&v->rng) >> 8) * (1.0f / 16777216.0f);
    v->c.ex[22] = 1.0f;                          /* (no drift yet: another engine's ex[22] is not a factor) */
    v->kp_n = -1;                                /* (knit_prep's cache: another engine wrote over ex[]) */
}

/* cane, voile and gingham: Braids' models (dsp/braids.h, MIT) */
#define CN_NONE 0xFFu
#include "braids.h"

/* sample: a sample of the bank (dsp/sample.h) at the note's pitch; its root note plays it at its own rate
 * (sm->rate: the factory's 22.05 kHz, half a sample a frame), linearly interpolated. start: where in it
 * (0..99 %); length: how much of the rest (127 = to its end): the region. Modes: one-shot (the region once; then the voice ends), loop
 * (from the region's start, round its loop: the sample's own loop if it lies inside the region, else the
 * region), reverse (the region once, backwards), pingpong (into the loop, then forth and back across it).
 * o[0] the position (a whole sample: exact in a float), o[1] its fraction, o[2] the direction (+-1), o[3]
 * 1 = done, o[4] 1 = started; the block being read is decoded in v->sc. */
static void smp_prep(voice_t *v)
{
    cfg_t *c = &v->c;
    int idx = (int)fm_clampf(fm_floorf(c->ek[0] + 0.5f), 0.0f, (float)(smp_slots() - 1));
    const smp_t *sm = smp_get(idx);
    float n, s0, s1, ls, le;
    c->stereo = 0;
    c->ex[6] = (float)idx;
    c->ex[7] = fm_clampf(fm_floorf(c->ek[3] + 0.5f), 0.0f, (float)(NSM - 1));
    if (!sm) {
        c->ex[0] = 0.0f;
        return;
    }
    n = (float)sm->n;
    s0 = fm_floorf(fm_minf(c->e[1], 0.99f) * n);
    s1 = fm_minf(s0 + fm_maxf(fm_floorf(c->e[2] * (n - s0) + 0.5f), 32.0f), n);
    ls = s0;
    le = s1;
    if (sm->le > sm->ls && (float)sm->ls >= s0 && (float)sm->le <= s1) {
        ls = (float)sm->ls;
        le = (float)sm->le;
    }
    if (c->ex[8] > 0.0f || c->ex[9] > 0.0f) {    /* the loop page: its start in the region, its length (0: as above) */
        ls = fm_floorf(s0 + (s1 - s0 - 32.0f) * c->ex[8] * (1.0f / 127.0f));
        if (c->ex[9] > 0.0f)
            le = fm_minf(ls + fm_maxf(fm_floorf((s1 - ls) * c->ex[9] * (1.0f / 127.0f)), 32.0f), s1);
        else if (!(sm->le > sm->ls && (float)sm->ls >= ls && (float)sm->le <= s1))
            le = s1;
        if (le < ls + 32.0f)
            le = fm_minf(ls + 32.0f, s1);
    }
    /* the rate: the note over the root, times the sample's rate over ours (at most 3 octaves above its own) */
    c->ex[0] = fm_minf(c->freq / (440.0f * fm_exp2f(((float)sm->root - 69.0f) * (1.0f / 12.0f))) *
                       ((float)sm->rate / SY_SR), 8.0f);
    c->ex[1] = s0;
    c->ex[2] = s1;
    c->ex[3] = ls;
    c->ex[4] = le;
}
#define SMP_FADE 64.0f                           /* a one-shot's fade at its region's end: samples of it (~3 ms) */
#define SMP_SWITCH 64.0f                         /* a mono retrigger's fade of the sound playing (1.5 ms; slice's SL_SWITCH) */
#define SMP_XF_S 0.008f                          /* a loop's crossfade: seconds of the sample (at most a quarter of the loop) */
/* the loop's crossfade (forward loop mode): from xf source samples before the loop's end, the end fades out while the
 * loop's start fades in (read at the same distance into it, a second cache: smp_xc), then the voice goes on from there.
 * o[7] the cache + 1 while crossing (0 none), o[8] / o[9] the start's read position and fraction. Returns the
 * frames written into out (up to m), the crossing done when it reaches the loop's end */
static int smp_xfade(voice_t *v, const smp_t *sm, int32_t *pos, float *fr, float inc, int32_t ls, int32_t le,
                     int32_t xf, float *out, int m)
{
    float tb[SUB * 4], p0 = (float)*pos + *fr;
    int32_t pb = (int32_t)v->o[8];
    float fb = v->o[9];
    int k, j, n = m > SUB * 4 ? SUB * 4 : m;
    smp_cache_t *xc = &smp_xc[(int)v->o[7] - 1];
    k = smp_play(&smp_vc[v->vi % NVOICE], sm, pos, fr, inc, 1, ls, le, out, n);
    smp_play(xc, sm, &pb, &fb, inc, 1, ls, le, tb, k);
    for (j = 0; j < k; j++) {                    /* (equal power: the two halves of a loop are not alike) */
        float t = fm_clampf((p0 + (float)j * inc - (float)(le - xf)) / (float)xf, 0.0f, 1.0f);
        out[j] = out[j] * fm_sin_turns(0.25f - t * 0.25f) + tb[j] * fm_sin_turns(t * 0.25f);
    }
    if (k < n || *pos >= le) {                   /* the end reached: on from the start's side, the cache free */
        *pos = pb;
        *fr = fb;
        smp_xo[(int)v->o[7] - 1] = NVOICE;
        v->o[7] = 0.0f;
    } else {
        v->o[8] = (float)pb;
        v->o[9] = fb;
    }
    return k;
}
static void smp_run(voice_t *v, float *xl, float *xr, int m)
{
    const cfg_t *c = &v->c;
    const smp_t *sm = smp_get((int)c->ex[6]);
    const int mode = (int)c->ex[7];
    const int32_t s0 = (int32_t)c->ex[1], s1 = (int32_t)c->ex[2], ls = (int32_t)c->ex[3], le = (int32_t)c->ex[4];
    const float inc = c->ex[0];
    float fr = v->o[1];
    int32_t pos = (int32_t)v->o[0], dir = v->o[2] < 0.0f ? -1 : 1;
    int i = 0, done = !sm || inc <= 0.0f || v->o[3] > 0.5f, turns = 0;
    int32_t xf = sm && le - ls >= 64 ? (int32_t)fm_minf((float)sm->rate * SMP_XF_S, (float)(le - ls) * 0.25f) : 0;
    (void)xr;
    if (!done && v->o[5] > 0.5f && v->o[7] > 0.5f) {   /* (a retrigger during a crossing: the crossing let go) */
        smp_xo[(int)v->o[7] - 1] = NVOICE;
        v->o[7] = 0.0f;
    }
    if (!done && v->o[5] > 0.5f) {               /* a mono retrigger: the sound playing fades out over SMP_SWITCH
                                                  * samples, then the note starts (smp_retrigger) */
        float sw = v->o[6];
        int k = (int)((1.0f - sw) * SMP_SWITCH + 0.999f);
        k = k < 1 ? 1 : k > m ? m : k;
        if (pos >= s0 && pos < s1) {
            int got = smp_play(&smp_vc[v->vi % NVOICE], sm, &pos, &fr, inc, dir, s0, s1, xl, k);
            for (int j = 0; j < got; j++)
                xl[j] *= fm_maxf(1.0f - (sw + (float)j * (1.0f / SMP_SWITCH)), 0.0f);
            for (int j = got; j < k; j++)
                xl[j] = 0.0f;
        } else
            for (int j = 0; j < k; j++)
                xl[j] = 0.0f;
        sw += (float)k * (1.0f / SMP_SWITCH);
        i = k;
        if (sw >= 1.0f) {
            v->o[5] = v->o[6] = 0.0f;
            v->o[4] = 0.0f;
        } else
            v->o[6] = sw;
    }
    if (!done && v->o[4] < 0.5f && v->o[5] < 0.5f) {   /* the note's first sample: the region's start (reverse: its end) */
        v->o[4] = 1.0f;
        pos = mode == SM_REVERSE ? s1 - 1 : s0;
        fr = 0.0f;
        dir = mode == SM_REVERSE ? -1 : 1;
    }
    while (!done && i < m && v->o[5] < 0.5f) {
        int32_t lo = s0, hi = s1;
        if (mode == SM_LOOP && v->o[7] > 0.5f) {      /* crossing the loop point */
            i += smp_xfade(v, sm, &pos, &fr, inc, ls, le, xf, xl + i, m - i);
            continue;
        }
        if (mode == SM_LOOP || mode == SM_PINGPONG) {   /* into the loop, then round (or across) it */
            hi = le;
            lo = dir < 0 || pos >= ls ? ls : s0;
            if (mode == SM_LOOP && xf > 0 && pos < le - xf)
                hi = le - xf;                    /* (up to the crossfade's start: smp_xfade from there) */
        }
        {
            int i0 = i;
            float p0 = (float)pos + (dir > 0 ? fr : -fr);
            i += smp_play(&smp_vc[v->vi % NVOICE], sm, &pos, &fr, inc, dir, lo, hi, xl + i, m - i);
            if (mode == SM_ONESHOT || mode == SM_REVERSE) {   /* the region's last SMP_FADE samples fade out: a sample
                                                                * cut short (or ending loud) ends without a click */
                float rem = dir > 0 ? (float)s1 - p0 : p0 - (float)s0, j0 = rem - inc * (float)(i - i0);
                if (j0 < SMP_FADE)
                    for (int j = i0; j < i; j++, rem -= inc)
                        if (rem < SMP_FADE)
                            xl[j] *= fm_maxf(rem, 0.0f) * (1.0f / SMP_FADE);
            }
        }
        if (i >= m)
            break;
        if (mode == SM_ONESHOT || mode == SM_REVERSE || le - ls < 2 || ++turns > 4)
            done = 1;                            /* (a loop shorter than the step: once round is enough) */
        else if (mode == SM_LOOP && xf > 0 && pos >= le - xf && pos < le) {   /* the crossfade's start: a cache for it */
            int x;
            for (x = 0; x < SMP_NXF && smp_xo[x] != NVOICE; x++)
                ;
            if (x < SMP_NXF) {
                smp_xo[x] = (uint8_t)v->vi;
                smp_cache_reset(&smp_xc[x]);
                v->o[7] = (float)(x + 1);
                v->o[8] = (float)(ls + (pos - (le - xf)));
                v->o[9] = fr;
            } else
                xf = 0;                          /* (none free: this turn jumps, as before) */
        } else if (mode == SM_LOOP)
            pos = ls + (pos - le) % (le - ls);
        else if (dir > 0) {                      /* pingpong: back from the loop's end */
            pos = 2 * (le - 1) - pos - (fr > 0.0f);
            fr = fr > 0.0f ? 1.0f - fr : 0.0f;
            dir = -1;
            if (pos < ls)
                pos = ls;
        } else {                                 /* and forth from its start */
            pos = 2 * ls - pos - (fr > 0.0f);
            fr = fr > 0.0f ? 1.0f - fr : 0.0f;
            dir = 1;
            if (pos >= le)
                pos = le - 1;
        }
    }
    if (done) {                                  /* the region has played (or nothing to play): silence, the voice
                                                  * is free (its amp ramps to 0 over the silence) */
        for (; i < m; i++)
            xl[i] = 0.0f;
        v->o[3] = 1.0f;
        v->amp.stage = ENV_OFF;
        v->amp.level = 0.0f;
    }
    v->o[0] = (float)pos;
    v->o[1] = fr;
    v->o[2] = (float)dir;
}

/* slice: a loop cut into even slices (synth.h EG_SLICE), the note choosing one: (note - root) mod slices. Its
 * rate: a sample that states its bars lasts that many bars at the tempo (n samples in bars * 4 beats, whatever
 * its rate), else its own (sm->rate); the pitch knob (and the bend, an LFO on the pitch) on top, so a slice
 * pitched down plays longer than its place in the bar. The gate is the share of the slice that plays, then the voice
 * ends (as one-shot); every slice fades in over SL_FADE_IN frames and out over the last SL_FADE_OUT before
 * its gate's end, so a cut never clicks. A mono retrigger, or a legato note picking another slice, fades the
 * old one out over SL_SWITCH frames first (one cache window a voice: no second read position to crossfade
 * with); legato then goes on at the same place in the new slice, the time running on.
 * o[0] the position, o[1] its fraction, o[2] the slice playing, o[3] 1 = done, o[4] 1 = started, o[5] frames
 * into the slice (its fade in), o[6] the switch's fade (0 .. 1 = silent), o[7] a switch waiting: 1 the note's
 * slice from its start (a retrigger), 2 the note's slice at the same place (legato), 3 the end (the gate
 * turned down behind the position), o[8] the gate's end the last time (in the sample) */
#define SL_FADE_IN 32.0f                         /* 0.7 ms */
#define SL_FADE_OUT 96.0f                        /* 2.2 ms */
#define SL_SWITCH 64.0f                          /* 1.5 ms */
static void slc_prep(voice_t *v, float bpm)
{
    cfg_t *c = &v->c;
    int idx = (int)fm_clampf(fm_floorf(c->ek[0] + 0.5f), 0.0f, (float)(smp_slots() - 1));
    const smp_t *sm = smp_get(idx);
    float rate, semi;
    c->stereo = 0;
    c->ex[6] = (float)idx;
    c->ex[7] = (float)sl_count((int)(c->ek[1] + 0.5f));
    if (!sm || sm->n < 64u) {
        c->ex[0] = 0.0f;
        return;
    }
    rate = sm->bars ? (float)sm->n * bpm * (1.0f / (240.0f * SY_SR)) / (float)sm->bars : (float)sm->rate / SY_SR;
    semi = fm_clampf(c->ek[2], 40.0f, 88.0f) - 64.0f + c->pitch_off * 0.01f;
    c->ex[0] = fm_clampf(rate * fm_exp2f(semi * (1.0f / 12.0f)), 0.01f, 8.0f);
    c->ex[1] = fm_maxf(c->e[3], 0.02f);
    c->ex[2] = (float)sm->root;
    c->ex[3] = 1.0f / (c->ex[0] * SL_FADE_OUT);  /* source samples to the gate's end -> the fade out's gain */
}
/* slice k of ns: its first sample s0 and the gate's end e */
static void slc_bounds(const smp_t *sm, int ns, int k, float gate, int32_t *s0, int32_t *e)
{
    int32_t a = (int32_t)((uint32_t)k * sm->n / (uint32_t)ns), b = (int32_t)((uint32_t)(k + 1) * sm->n / (uint32_t)ns);
    int32_t g = (int32_t)(gate * (float)(b - a));
    *s0 = a;
    *e = a + (g < 32 ? 32 : g > b - a ? b - a : g);
}
static void slc_run(voice_t *v, float *xl, float *xr, int m)
{
    const cfg_t *c = &v->c;
    const smp_t *sm = smp_get((int)c->ex[6]);
    const int ns = (int)c->ex[7];
    const float inc = c->ex[0], gate = c->ex[1];
    smp_cache_t *ca = &smp_vc[v->vi % NVOICE];
    float fr = v->o[1], fin = v->o[5], sw = v->o[6];
    int32_t pos = (int32_t)v->o[0], s0 = 0, e = 0;
    int cur = (int)v->o[2], pend = (int)v->o[7], want = 0, i = 0;
    int done = !sm || inc <= 0.0f || v->o[3] > 0.5f || ns < 1;
    (void)xr;
    if (!done) {
        int d = ((int)v->note - (int)c->ex[2]) % ns;
        want = d < 0 ? d + ns : d;
        if (v->o[4] < 0.5f) {                    /* the note's first sample: its slice's start */
            v->o[4] = 1.0f;
            cur = want;
            pend = 0;
            sw = fin = fr = 0.0f;
            slc_bounds(sm, ns, cur, gate, &s0, &e);
            pos = s0;
        } else if (!pend && (want != cur || cur >= ns)) {
            pend = 2;                            /* (a legato note on another slice, the slices turned) */
        }
    }
    while (!done && i < m) {
        int k, j, req = m - i;
        float lo;
        if (pend == 3 && sw >= 1.0f) {           /* faded out past a gate turned down: the end */
            done = 1;
            break;
        }
        if (pend && sw >= 1.0f) {                /* faded out: the switch */
            int32_t off = 0;
            if (pend == 2 && cur < ns) {
                slc_bounds(sm, ns, cur, gate, &s0, &e);
                off = pos - s0;
            } else {
                fr = 0.0f;
            }
            cur = want;
            slc_bounds(sm, ns, cur, gate, &s0, &e);
            pos = s0 + (off > 0 ? off : 0);
            pend = 0;
            sw = fin = 0.0f;
            if (pos >= e) {
                done = 1;
                break;
            }
        }
        slc_bounds(sm, ns, cur, gate, &s0, &e);
        if (!pend && pos >= e && cur < ns) {     /* at the gate's end: it has played; or the gate was turned
                                                  * down behind the position: a fade, then the end */
            if ((float)e >= v->o[8]) {
                done = 1;
                break;
            }
            pend = 3;
        }
        v->o[8] = (float)e;
        if (pend == 3)                           /* (meanwhile on into the slice, the gate's fade out of it) */
            slc_bounds(sm, ns, cur, 1.0f, &s0, &e);
        if (pend) {                              /* up to the switch */
            int left = (int)((1.0f - sw) * SL_SWITCH + 0.999f);
            req = left < 1 ? 1 : left < req ? left : req;
        }
        lo = pend == 3 ? 1e9f : ((float)(e - pos) - fr) * c->ex[3];
        k = smp_play(ca, sm, &pos, &fr, inc, 1, s0, e, xl + i, req);
        for (j = 0; j < k; j++) {                /* the fades: in, out at the gate's end, the switch's */
            float g = fm_minf(fm_minf((fin + (float)j) * (1.0f / SL_FADE_IN), lo - (float)j * (1.0f / SL_FADE_OUT)), 1.0f);
            if (pend)
                g *= 1.0f - fm_minf(sw + (float)j * (1.0f / SL_SWITCH), 1.0f);
            xl[i + j] *= fm_maxf(g, 0.0f);
        }
        fin = fm_minf(fin + (float)k, SL_FADE_IN);
        if (pend)
            sw = fm_minf(sw + (float)k * (1.0f / SL_SWITCH), 1.0f);
        i += k;
        if (k < req) {                           /* the gate's end: the slice has played */
            if (pend)
                sw = 1.0f;                       /* (a switch waiting: now) */
            else
                done = 1;
        }
    }
    if (done) {                                  /* silence: the voice is free (as the sample engine's one-shot) */
        for (; i < m; i++)
            xl[i] = 0.0f;
        v->o[3] = 1.0f;
        v->amp.stage = ENV_OFF;
        v->amp.level = 0.0f;
    }
    v->o[0] = (float)pos;
    v->o[1] = fr;
    v->o[2] = (float)cur;
    v->o[5] = fin;
    v->o[6] = sw;
    v->o[7] = (float)pend;
}
static void smp_retrigger(voice_t *v)            /* a mono retrigger: what plays fades out first (smp_run), no click */
{
    if (v->o[4] > 0.5f && v->o[3] < 0.5f) {
        v->o[5] = 1.0f;
        v->o[6] = 0.0f;
    } else
        v->o[3] = v->o[4] = v->o[5] = 0.0f;
}
static void slc_retrigger(voice_t *v)            /* a mono retrigger: the playing slice fades, the note's starts */
{
    if (v->o[4] > 0.5f && v->o[3] < 0.5f)
        v->o[7] = 1.0f;
    else
        v->o[3] = v->o[4] = 0.0f;
}

static void tweed_prep(voice_t *v)
{
    /* Voices are reused across engines: Tweed writes mono, including after a stereo Knit. */
    v->c.stereo = 0;
    /* C4 is neutral: pitched keys, arp, Pitch Scale and pitch locks transpose it. */
    tweed_coeff(v->c.ex, v->c.freq * fm_exp2f((v->c.ek[0] - 60.0f) * (1.0f/12.0f)), v->c.e[1], v->c.e[2]);
}
static void tweed_run(voice_t *v, float *xl, int m)
{
    for(int i=0;i<m;i++) xl[i]=tweed_tick(v->o,v->c.ex);
    if(v->o[3]==0.0f) { v->amp.level=0.0f; v->amp.stage=ENV_OFF; }
}
static void eng_chunk(voice_t *v)                /* every chunk: the engines' own slow movements */
{
    switch (v->engine) {
    case EG_RAYON: rayon_chunk(v); break;
    case EG_BELLOWS: organ_chunk(v); break;
    case EG_CANE: cn_chunk(v); break;
    case EG_KNIT: knit_chunk(v); break;
    case EG_VOILE: vo_chunk(v); break;
    default: break;
    }
}
static void eng_prep(voice_t *v, float bpm)
{
    switch (v->engine) {
    case EG_TWEED: tweed_prep(v); break;
    case EG_JACQUARD: wt_prep(v); break;
    case EG_RAYON: rayon_prep(v); break;
    case EG_BELLOWS: organ_prep(v); break;
    case EG_SAMPLE: smp_prep(v); break;
    case EG_SLICE: slc_prep(v, bpm); break;
    case EG_CANE: cn_prep(v); break;
    case EG_VOILE: vo_prep(v); break;
    default: knit_prep(v); break;
    }
}
static void eng_run(voice_t *v, float *xl, float *xr, int m)
{
    switch (v->engine) {
    case EG_TWEED: tweed_run(v, xl, m); break;
    case EG_JACQUARD: wt_run(v, xl, xr, m); break;
    case EG_RAYON: rayon_run(v, xl, xr, m); break;
    case EG_BELLOWS: organ_run(v, xl, xr, m); break;
    case EG_SAMPLE: smp_run(v, xl, xr, m); break;
    case EG_SLICE: slc_run(v, xl, xr, m); break;
    case EG_CANE: cn_run(v, xl, xr, m); break;
    case EG_VOILE: vo_run(v, xl, xr, m); break;
    default: knit_run(v, xl, xr, m); break;
    }
}

/* ------------------------------------------------------------ the voice --- */
static inline int v_sounding(const voice_t *v) { return v->amp.stage != ENV_OFF || v->steal_phase != 0 || (v->layer.mode && (v->held || v->layer.env > 1e-3f)); }

static float porta_ms(int glide_ms, int porta) { return glide_ms > 0 ? (float)glide_ms : (float)(porta * porta) * 0.125f; }   /* 0 .. 2 s */

static void voice_start(synth_t *s, voice_t *v, int note, int vel, int glide_ms, uint32_t tag, int held, int in_render)
{
    trk_t *t = &s->t[v->trk];
    float ms = porta_ms(glide_ms, P(s, v->trk, TP_PORTA));
    int eng = P(s, v->trk, TP_ENGINE);
    if (!eg_synth(eng))
        eng = EG_KNIT;
    v->tws = v->tws_pend;                        /* cane: the slot voice_take kept for this note */
    v->cost_m = t->cost_m;                       /* (the split's guess: what the track's voices take) */
    if (eng != v->engine || !v_sounding(v)) {
        v->engine = (uint8_t)eng;
        eng_init(v);
    }
    v->layer.env = v->layer.lp = v->layer.ph = v->layer.ph2 = 0.0f;
    v->layer.mode = 0;
    v->layer.last_freq=0.0f; v->layer.last_cut=-100.0f;
    v->layer.attack = v->layer.release = 255;
    v->note = (uint8_t)note;
    v->tag = tag;
    v->vel = (float)vel * (1.0f / 127.0f);
    v->held = (uint8_t)held;
    v->pitch = (float)note;
    v->pitch_cur = (ms > 0.5f && t->last_pitch > 0.0f) ? t->last_pitch : v->pitch;
    v->glide_k = ms > 0.5f ? 1.0f - fm_expf(-(float)SY_CHUNK * 1000.0f / (ms * SY_SR)) : 1.0f;
    if (!in_render)                              /* a render (the steal) writes nothing the tracks share */
        v->age = s->counter++;
    v->amp.stage = ENV_ATTACK;
    v->flt.stage = ENV_ATTACK;
    v->tsec = 0.0f;
    if(v->engine == EG_TWEED) tweed_trigger(v->o);
    if (v->engine == EG_RAYON)                   /* its fall and its tine from the top, every note */
        v->o[5] = v->o[7] = 1.0f;
    if (v->engine == EG_SAMPLE || v->engine == EG_SLICE) {   /* from the region's (the slice's) start again */
        v->o[3] = v->o[4] = 0.0f;
        v->o[6] = v->o[7] = 0.0f;
    }
    if (v->engine == EG_CANE)                    /* the Braids engines: a strike (Braids' trigger) */
        cn_strike(v, 1);
    else if (v->engine == EG_VOILE)
        vo_strike(v);
    if (!in_render)
        t->last_pitch = v->pitch;
    v->fresh = 1;
}

static int track_voices(const synth_t *s, int trk)
{
    int i, n = 0;
    for (i = 0; i < s->max_voices; i++)
        n += s->v[i].trk == trk && v_sounding(&s->v[i]);
    return n;
}

/* knit's cap (brocade's, whose unison it took): at most knit_cap() of its voices in the pool, by the unison of the
 * track that wants one (six at six or fewer, five at seven: such a voice costs about two and a half ordinary ones).
 * A voice counts as what it will play (a steal's pending note: its track's engine). */
static int knit_cap(const synth_t *s, int trk)
{
    return P(s, trk, TP_E3) >= 7 ? 5 : 6;
}
static int knit_voice(const synth_t *s, const voice_t *v)
{
    if (!v_sounding(v))
        return 0;
    return (v->steal_phase == 1 ? P(s, v->trk, TP_ENGINE) : v->engine) == EG_KNIT;
}
/* and its saws: a voice costs about its unison's count (and one for osc 2), so past KNIT_SAWS in the pool a new note
 * takes the quietest releasing knit voice (a chord change's tails under the new chord: house's pad, four saws a
 * voice, played six voices with them, ~100 % of a core); held notes stay, the voice cap alone takes those */
#define KNIT_SAWS 16
static int knit_saws(const synth_t *s, int trk)
{
    int n = P(s, trk, TP_E3);
    return (n < 1 ? 1 : n > KNIT_MAX ? KNIT_MAX : n) + (P(s, trk, TP_X2) > 0);
}
static int knit_find(const synth_t *s, int trk) /* the knit voice to take when the cap is reached; -1 */
{
    int i, n = 0, saws = 0, best = -1, own = 0, over_cap;
    float quiet = 1e9f;
    uint32_t oldest = 0xFFFFFFFFu;
    for (i = 0; i < s->max_voices; i++)
        if (knit_voice(s, &s->v[i])) {
            n++;
            saws += knit_saws(s, s->v[i].trk);
        }
    over_cap = n >= knit_cap(s, trk);
    if (!over_cap && saws + knit_saws(s, trk) <= KNIT_SAWS)
        return -1;
    for (i = 0; i < s->max_voices; i++) {        /* releasing first (the quietest), then the track's own oldest */
        const voice_t *v = &s->v[i];
        if (!knit_voice(s, v) || v->steal_phase == 1)
            continue;
        if (v->amp.stage == ENV_RELEASE && v->amp.level < quiet) {
            quiet = v->amp.level;
            best = i;
        }
    }
    if (best >= 0 || !over_cap)                  /* (past the saws alone, none releasing: a free voice after all) */
        return best;
    for (i = 0; i < s->max_voices; i++) {
        const voice_t *v = &s->v[i];
        int mine = v->trk == trk;
        if (!knit_voice(s, v) || v->steal_phase == 1 || (own && !mine))
            continue;
        if ((mine && !own) || v->age < oldest) {
            oldest = v->age;
            best = i;
            own = mine;
        }
    }
    if (best < 0)                                /* all of them fading for a note already: the newest of */
        for (i = 0; i < s->max_voices; i++)      /* those waits for this note instead */
            if (knit_voice(s, &s->v[i]) && (best < 0 || s->v[i].age > s->v[best].age))
                best = i;
    return best;
}

/* cane's cap: its waveguides play from CN_SLOTS line slots (dsp/braids.h cn_mem), so at most CN_SLOTS of its
 * voices: one that plays cane (sounding) or will (a steal's pending note that voice_take kept a slot for) */
static int cn_voice(const voice_t *v)
{
    return (v->engine == EG_CANE && v_sounding(v)) || (v->steal_phase == 1 && v->tws_pend != CN_NONE);
}
static int cn_holds(const voice_t *v, int j)     /* the voice plays from slot j, or will */
{
    return (v->engine == EG_CANE && v_sounding(v) && v->tws == j) || (v->steal_phase == 1 && v->tws_pend == j);
}
static int cn_find(const synth_t *s, int trk)    /* the cane voice to take when the cap is reached; -1 */
{
    int i, n = 0, best = -1, own = 0;
    float quiet = 1e9f;
    uint32_t oldest = 0xFFFFFFFFu;
    for (i = 0; i < NVOICE; i++)
        n += cn_voice(&s->v[i]);
    if (n < CN_SLOTS)
        return -1;
    for (i = 0; i < NVOICE; i++) {               /* releasing first (the quietest), then the track's own oldest */
        const voice_t *v = &s->v[i];
        if (!cn_voice(v) || v->steal_phase == 1)
            continue;
        if (v->amp.stage == ENV_RELEASE && v->amp.level < quiet) {
            quiet = v->amp.level;
            best = i;
        }
    }
    if (best >= 0)
        return best;
    for (i = 0; i < NVOICE; i++) {
        const voice_t *v = &s->v[i];
        int mine = v->trk == trk;
        if (!cn_voice(v) || v->steal_phase == 1 || (own && !mine))
            continue;
        if ((mine && !own) || v->age < oldest) {
            oldest = v->age;
            best = i;
            own = mine;
        }
    }
    if (best < 0)                                /* all of them fading for a note already: the newest waits */
        for (i = 0; i < NVOICE; i++)
            if (cn_voice(&s->v[i]) && (best < 0 || s->v[i].age > s->v[best].age))
                best = i;
    return best;
}
/* the slot for a cane note on voice vi: its own when it plays cane now (the note follows on its lines), else
 * one no other voice holds (cn_find made sure there is one); CN_NONE when the track is not cane */
static void cn_reserve(synth_t *s, int vi, int trk)
{
    voice_t *v = &s->v[vi];
    int j, i;
    v->tws_pend = CN_NONE;
    if (P(s, trk, TP_ENGINE) != EG_CANE)
        return;
    if (v->engine == EG_CANE && v_sounding(v) && v->tws < CN_SLOTS) {
        v->tws_pend = v->tws;
        return;
    }
    for (j = 0; j < CN_SLOTS; j++) {
        int used = 0;
        for (i = 0; i < NVOICE && !used; i++)
            used = i != vi && cn_holds(&s->v[i], j);
        if (!used) {
            v->tws_pend = (uint8_t)j;
            return;
        }
    }
}

/* the load check at a note's start (the FM-1's: there each track knows its voices' measured time): a free voice
 * adds the track's cost to this block's predicted load, scaled by LOAD_SHARE (the two cores share the voices); one
 * that would take it past LOAD_ADMIT % takes a sounding voice instead, as a full pool does. The overload guard
 * (engine.c) only sees a block once it has overrun: a chord change's new voices could. */
#define LOAD_ADMIT 92.0f
#define LOAD_SHARE 0.6f
void synth_load_hint(synth_t *s, uint32_t pct) { s->load_pred = (float)pct; }
static float load_add(const synth_t *s, int trk)
{
    return s->t[trk].cost_m * (100.0f / 544.0f) * LOAD_SHARE;   /* (ticks a frame; 544 a frame's budget) */
}
static int load_over(const synth_t *s, int trk)
{
    int i;
    float add = load_add(s, trk);
    if (add <= 0.0f || s->load_pred <= 0.0f || s->load_pred + add <= LOAD_ADMIT)
        return 0;
    for (i = 0; i < s->max_voices; i++)          /* (a sounding voice to take: else the free one after all) */
        if (v_sounding(&s->v[i]) && s->v[i].steal_phase == 0)
            return 1;
    return 0;
}

/* a voice for a new note: a free one (inside the load check); else the track's oldest if it holds NVOICE_TRK
 * already; else the quietest releasing; else the oldest of all. A stolen voice fades 15 ms first. knit and cane
 * first keep to their own caps (knit_find, cn_find). */
static int find_voice(synth_t *s, int trk)
{
    int i, best = -1, over;
    float quiet = 1e9f;
    uint32_t oldest = 0xFFFFFFFFu;
    if (P(s, trk, TP_ENGINE) == EG_KNIT && (best = knit_find(s, trk)) >= 0)
        return best;
    if (P(s, trk, TP_ENGINE) == EG_CANE && (best = cn_find(s, trk)) >= 0)
        return best;
    if (track_voices(s, trk) >= NVOICE_TRK) {
        for (i = 0; i < s->max_voices; i++)
            if (s->v[i].trk == trk && s->v[i].steal_phase == 0 && s->v[i].age < oldest) {
                oldest = s->v[i].age;
                best = i;
            }
        if (best >= 0)
            return best;
    }
    over = load_over(s, trk);
    if (over)
        synth_load_steals++;
    else
        for (i = 0; i < s->max_voices; i++)
            if (!v_sounding(&s->v[i])) {
                s->load_pred += load_add(s, trk);
                return i;
            }
    for (i = 0; i < s->max_voices; i++)
        if (s->v[i].amp.stage == ENV_RELEASE && s->v[i].steal_phase == 0 && s->v[i].amp.level < quiet) {
            quiet = s->v[i].amp.level;
            best = i;
        }
    if (best >= 0)
        return best;
    for (i = 0; i < s->max_voices; i++)
        if (s->v[i].steal_phase == 0 && s->v[i].age < oldest) {
            oldest = s->v[i].age;
            best = i;
        }
    if (best >= 0)
        return best;
    for (i = 0, oldest = 0xFFFFFFFFu; i < s->max_voices; i++)
        if (s->v[i].age < oldest) {
            oldest = s->v[i].age;
            best = i;
        }
    return best >= 0 ? best : 0;
}

static void voice_chunk(synth_t *s, voice_t *v);
static void voice_config_now(synth_t *s, voice_t *v)   /* a voice started mid-chunk: its parameters now */
{
    v->ck = (uint8_t)(v->ck - 1);                /* voice_chunk takes the slot the boundary read */
    v->nchunk = (uint8_t)(v->nchunk - 1);
    voice_chunk(s, v);
}

static void voice_take(synth_t *s, int vi, int trk, int note, int vel, int glide_ms, uint32_t tag)
{
    voice_t *v = &s->v[vi];
    cn_reserve(s, vi, trk);
    if (!v_sounding(v)) {
        int i;
        v->trk = (uint8_t)trk;
        v->steal_gain = 1.0f;
        v->steal_phase = 0;
        v->amp.level = v->flt.level = 0.0f;
        for (i = 0; i < 8; i++)
            v->f[i] = 0.0f;
        for (i = 0; i < 8; i++)
            v->cz[i] = 0.0f;
        v->amp_cur = 0.0f;
        v->glc = v->grc = 0.0f;
        voice_start(s, v, note, vel, glide_ms, tag, 1, 0);
        v->fresh |= 2;                           /* configured by its render (synth_render), on its core */
    } else {                                     /* fade the old note out, then start (voice_steal) */
        v->pend_note = (uint8_t)note;
        v->pend_vel = (uint8_t)vel;
        v->pend_tag = tag;
        v->pend_glide = (int16_t)(glide_ms > 32767 ? 32767 : glide_ms);
        v->pend_held = 1;
        v->trk = (uint8_t)trk;                   /* the track's from now: its note off finds it */
        v->steal_phase = 1;
        v->age = s->counter++;
    }
}

/* ---------------------------------------------------------------- notes --- */
/* a regular (not free) wave or drift LFO restarts on every note of its track */
static void lfo_retrigger(synth_t *s, int trk)
{
    trk_t *t = &s->t[trk];
    for (int l = 0; l < XM_LFOS; l++)
        if (xmod_cfg(s,trk,l*XM_FIELDS+3) == 1) xm.state[trk][l].reset = 1;
    int type = P(s, trk, TP_LTYPE);
    if ((type != LT_WAVE && type != LT_DRIFT) || P(s, trk, TP_LDEST) >= LD_FREE)
        return;
    t->lfo_ph = 0.0f;
    if (type == LT_DRIFT) {
        t->lfo_sh = frand(&t->rng);
        t->lfo_sm = t->lfo_sh;
    }
}

void synth_note_on(synth_t *s, int trk, int note, int vel, int glide_ms, uint32_t tag)
{
    trk_t *t;
    int mode;
    if (trk < 0 || trk >= NTRK || note < 0 || note > 127)
        return;
    if (!eg_synth(P(s, trk, TP_ENGINE)))
        return;                                  /* dsp/drumline.c plays a kit's; a MIDI track's go out only */
    if (vel < 1)
        vel = 1;
    if (vel > 127)
        vel = 127;
    t = &s->t[trk];
    mode = P(s, trk, TP_VMODE);
    lfo_retrigger(s, trk);
    t->pb_snap = 1;
    if (mode == VM_POLY) {
        voice_take(s, find_voice(s, trk), trk, note, vel, glide_ms, tag);
        return;
    }
    {   /* mono / legato: one voice, a stack of held notes */
        int i, k = -1;
        voice_t *v = t->mono_voice >= 0 ? &s->v[t->mono_voice] : 0;
        for (i = 0; i < t->mono_n; i++)
            if (t->mono_note[i] == note)
                k = i;
        if (k < 0 && t->mono_n < 8) {
            t->mono_note[t->mono_n] = (uint8_t)note;
            t->mono_vel[t->mono_n] = (uint8_t)vel;
            t->mono_tag[t->mono_n] = tag;
            t->mono_n++;
        }
        if (v && v->trk == trk && v_sounding(v) && v->steal_phase == 0) {
            int was_held = v->held;
            float ms = porta_ms(glide_ms, P(s, trk, TP_PORTA));
            v->layer.env = v->layer.lp = v->layer.ph = v->layer.ph2 = 0.0f;
    v->layer.mode = 0;
    v->layer.last_freq=0.0f; v->layer.last_cut=-100.0f;
    v->layer.attack = v->layer.release = 255;
    v->note = (uint8_t)note;
            v->tag = tag;
            v->vel = (float)vel * (1.0f / 127.0f);
            v->held = 1;
            v->pitch = (float)note;
            v->glide_k = ms > 0.5f ? 1.0f - fm_expf(-(float)SY_CHUNK * 1000.0f / (ms * SY_SR)) : 1.0f;
            t->last_pitch = v->pitch;
            if (mode == VM_MONO || !was_held || v->amp.stage == ENV_RELEASE) {   /* legato: only from silence */
                v->amp.stage = ENV_ATTACK;       /* retrigger from the level now */
                v->flt.stage = ENV_ATTACK;
                v->tsec = 0.0f;
                if (v->engine == EG_RAYON)
                    v->o[5] = v->o[7] = 1.0f;
                if (v->engine == EG_SAMPLE)
                    smp_retrigger(v);
                if (v->engine == EG_SLICE)
                    slc_retrigger(v);
                if (v->engine == EG_CANE)        /* the lines as they are, the exciter again */
                    cn_strike(v, 0);
                else if (v->engine == EG_VOILE)
                    vo_strike(v);
            }
            return;
        }
        i = find_voice(s, trk);
        t->mono_voice = (int8_t)i;
        voice_take(s, i, trk, note, vel, glide_ms, tag);
    }
}

static void voice_release(voice_t *v)
{
    v->held = 0;
    if (v->amp.stage != ENV_OFF && v->amp.stage != ENV_RELEASE) {
        v->amp.stage = ENV_RELEASE;
        v->flt.stage = ENV_RELEASE;
    }
}

/* a key let go: the release; a slice plays on to its gate's end (the GATE knob is how much of it plays, whatever the
 * note's length: slices on the steps play through as the break did) */
static void key_release(voice_t *v)
{
    if (v->engine == EG_SLICE && v->amp.stage != ENV_RELEASE)
        v->held = 0;
    else
        voice_release(v);
}

void synth_note_off(synth_t *s, int trk, uint32_t tag)
{
    trk_t *t;
    int i;
    if (trk < 0 || trk >= NTRK)
        return;
    t = &s->t[trk];
    for (i = 0; i < t->mono_n; i++)              /* the mono stack (kept in every mode: harmless in poly) */
        if (t->mono_tag[i] == tag) {
            int j;
            for (j = i; j < t->mono_n - 1; j++) {
                t->mono_note[j] = t->mono_note[j + 1];
                t->mono_vel[j] = t->mono_vel[j + 1];
                t->mono_tag[j] = t->mono_tag[j + 1];
            }
            t->mono_n--;
            break;
        }
    if (P(s, trk, TP_VMODE) != VM_POLY && t->mono_voice >= 0) {
        voice_t *v = &s->v[t->mono_voice];
        if (v->trk != trk)
            return;
        if (v->steal_phase == 1 && v->pend_tag == tag) {
            v->pend_held = 0;
            return;
        }
        if (v->tag != tag)
            return;
        if (t->mono_n > 0) {                     /* back to the note still held */
            int k = t->mono_n - 1;
            v->note = t->mono_note[k];
            v->tag = t->mono_tag[k];
            v->pitch = (float)v->note;
            t->last_pitch = v->pitch;
        } else {
            key_release(v);
        }
        return;
    }
    for (i = 0; i < NVOICE; i++) {
        voice_t *v = &s->v[i];
        if (v->trk != trk)
            continue;
        if (v->held && v->tag == tag && v->steal_phase != 1)
            key_release(v);
        if (v->steal_phase == 1 && v->pend_tag == tag)
            v->pend_held = 0;                    /* let go before its steal finished: just its release */
    }
}

void synth_all_off(synth_t *s, int trk)
{
    int i;
    for (i = 0; i < NVOICE; i++) {
        voice_t *v = &s->v[i];
        if (trk >= 0 && v->trk != trk)
            continue;
        voice_release(v);
        if (v->steal_phase == 1)
            v->pend_held = 0;
    }
    for (i = 0; i < NTRK; i++)
        if (trk < 0 || i == trk) {
            s->t[i].mono_n = 0;
            s->t[i].mono_voice = -1;
        }
}

void synth_bend(synth_t *s, int trk, int cents)
{
    if (trk >= 0 && trk < NTRK)
        s->t[trk].bend_c = (int16_t)(cents < -32000 ? -32000 : cents > 32000 ? 32000 : cents);
}
perf_t *synth_perf(synth_t *s, int trk) { return &s->t[trk < 0 ? 0 : trk >= NTRK ? NTRK - 1 : trk].perf; }
void synth_lock(synth_t *s, int trk, int param, int val)
{
    if (trk>=0 && trk<NTRK && layer_engine(s->par[trk][TP_ENGINE]) && param>=TP_LAYER_MODE && param<TP_LAYER_END) {
        xm.layer_lock[trk][param-TP_LAYER_MODE]=(uint8_t)(val<0?0:val>255?255:val); return;
    }
    if (trk>=0 && trk<NTRK && param>=TP_XMOD0 && param<NTP) {
        xm.lock[trk][param-TP_XMOD0]=(uint8_t)(val<0?0:val>255?255:val); return;
    }
    if (trk >= 0 && trk < NTRK && param >= 0 && param < NTP_LOCK)
        s->t[trk].lock[param] = (uint8_t)(val < 0 ? 0 : val > 255 ? 255 : val);
}
int synth_lock_value(const synth_t *s, int trk, int param)
{
    if (trk>=0 && trk<NTRK && layer_engine(s->par[trk][TP_ENGINE]) && param>=TP_LAYER_MODE && param<TP_LAYER_END)
        return xm.layer_lock[trk][param-TP_LAYER_MODE]==LOCK_NONE ? -1 : xm.layer_lock[trk][param-TP_LAYER_MODE];
    if (trk>=0 && trk<NTRK && param>=TP_XMOD0 && param<NTP)
        return xm.lock[trk][param-TP_XMOD0]==LOCK_NONE ? -1 : xm.lock[trk][param-TP_XMOD0];
    if (trk < 0 || trk >= NTRK || param < 0 || param >= NTP_LOCK || s->t[trk].lock[param] == LOCK_NONE)
        return -1;
    return s->t[trk].lock[param];
}
void synth_tempo(synth_t *s, float bpm) { s->bpm = bpm < 20.0f ? 20.0f : bpm > 400.0f ? 400.0f : bpm; }
void synth_limit(synth_t *s, int max_voices)
{
    s->max_voices = (uint8_t)(max_voices < 1 ? 1 : max_voices > NVOICE ? NVOICE : max_voices);
}
/* a voice's cost in units of ~1.1 % of a block: on the FM-1 its measured time (or, a note just started, its track's
 * voices' and a unit for its set-up); else, and in the simulator (its samples the same every run), the model below */
#define COST_TICKS_UNIT 5.98f                    /* 1.1 % of 544 clock ticks, a frame's time */
int synth_voice_cost(const synth_t *s, int vi)
{
    const voice_t *v = &s->v[vi];
    if (!v_sounding(v))
        return 0;
#ifndef PLAT_HOST
    if (v->cost_m > 0.0f) {
        int u = (int)(v->cost_m * (1.0f / COST_TICKS_UNIT) + 0.5f) + (v->fresh & 2 ? 1 : 0);
        return u < 1 ? 1 : u > 40 ? 40 : u;
    }
#endif
    if (v->engine == EG_CANE || v->engine == EG_VOILE) {   /* by the model (braids.h) */
        int md = v->c.ex[19] > 0.0f ? (int)v->c.ex[19] : 0;
        return v->engine == EG_CANE ? CN_COST[md < NCANE ? md : 0] : VO_COST[md < NVOILE ? md : 0];
    }
    if (v->engine == EG_BELLOWS)
        return 5;                                /* (the FM-1, tools/measure_load.sh 2026-10-18: a quarter above the rest) */
    if (v->engine == EG_KNIT)                    /* (the FM-1, tools/preset_prof.py 2026-10-19: 3 and a unit and
                                                  * a half a unison voice, a unit an extra; clamped: a voice started
                                                  * this block holds its last engine's values until its first chunk) */
        return 3 + (int)(1.5f * fm_clampf(v->c.ex[2], 1.0f, (float)KNIT_MAX)) + (v->c.ex[14] > 0.0f) +
               (v->c.ex[16] > 0.0f || v->c.ex[17] > 0.0f);
    if (v->engine == EG_RAYON)
        return 5;                                /* (the FM-1, 2026-10-19: a quarter above an ordinary voice) */
    return 4;
}
void synth_duck_trigger(synth_t *s, int src)
{
    int i;
    for (i = 0; i < NTRK; i++)
        if (P(s, i, TP_LTYPE) == LT_PUMP && P(s, i, TP_LSPEED) == src) {
            s->t[i].duck = 1.0f;
            s->t[i].duck_hold = env_seconds((float)P(s, i, TP_LDEST) * (1.0f / 127.0f));
        }
}

void synth_init(synth_t *s, uint8_t (*par)[NTP])
{
    int i, j;
    uint8_t *b = (uint8_t *)s;
    for (i = 0; i < (int)sizeof *s; i++)
        b[i] = 0;
    s->par = par;
    for (i = 0; i < (int)sizeof xm; i++) ((uint8_t *)&xm)[i] = 0;
    xm.mask = 0xFFF;
    for(int t=0;t<NTRK;t++) { for(int f=0;f<24;f++)xm.lock[t][f]=LOCK_NONE; for(int f=0;f<LAYER_N;f++)xm.layer_lock[t][f]=LOCK_NONE; }
    for (int t = 0; t < NTRK; t++) for (int l = 0; l < XM_LFOS; l++)
        xm.state[t][l].rng = 0x9E3779B9u ^ (uint32_t)((t + 1) * 123457 + l * 9871);
    s->bpm = 120.0f;
    s->max_voices = NVOICE;
    for (i = 0; i < NTRK; i++) {
        trk_t *t = &s->t[i];
        for (j = 0; j < NTP_LOCK; j++)
            t->lock[j] = LOCK_NONE;
        t->mono_voice = -1;
        t->rng = 0x9E3779B9u * (uint32_t)(i + 1);
        t->ldest = LD_NONE;
        for (j = 0; j < NCK; j++)
            t->lgain[j] = 1.0f;
    }
    for (i = 0; i < NVOICE; i++) {
        voice_t *v = &s->v[i];
        v->vi = (uint8_t)i;
        v->rng = 0x2545F491u * (uint32_t)(i + 1) + 1u;
        v->steal_gain = 1.0f;
        v->engine = EG_KNIT;
        v->tws = v->tws_pend = CN_NONE;
        for (j = 0; j < 8; j++)
            v->env_in[j] = -1.0f;                /* the caches: nothing made yet */
        v->pan_in = v->pitch_in = -1.0f;
        eng_init(v);
    }
    for (i = 0; i < NTRK; i++)
        synth_peak[i] = 0;
}

/* -------------------------------------------------------------- prepare --- */
static inline float lfo_wave_value(int shape, float ph)   /* square, sine, ramp, saw */
{
    switch (shape & 3) {
    case 0: return ph < 0.5f ? 1.0f : -1.0f;
    case 1: return fm_sin_turns(ph);
    case 2: return 2.0f * ph - 1.0f;
    default: return 1.0f - 2.0f * ph;
    }
}
static inline float lfo_wave_trem(int shape, float ph)    /* sine, saw, exponential, square, blip */
{
    switch (shape) {
    case 1: return 1.0f - 2.0f * ph;
    case 2: return 2.0f * fm_exp2f(-8.0f * ph) - 1.0f;
    case 3: return ph < 0.5f ? 1.0f : -1.0f;
    case 4: return ph < 0.08f ? 1.0f : -1.0f;
    default: return fm_sin_turns(ph);
    }
}

/* the track-level values of every chunk boundary inside the next n frames: the LFO (wave, drift:
 * an offset on its destination; wobble: a gain and a vibrato; pump: a gain), one slot each. The
 * voices read the slots in order as they cross the boundaries. Also the meters. */
/* the shared LFO's rate in Hz: synced to the beat (16 bars .. 1/16), else free */
static float glfo_hz(int v, float bpm)
{
    static const float BEATS[GL_SYNC_N] = {64.0f, 32.0f, 16.0f, 8.0f, 4.0f, 2.0f, 1.0f, 0.5f, 0.25f};
    if (v < GL_SYNC_N)
        return bpm * (1.0f / 60.0f) / BEATS[v];
    return 0.02f * fm_exp2f((float)(v - GL_SYNC_N) * (8.96578428f / 118.0f));   /* 0.02 .. 10 Hz */
}
static float glfo_shape(int sh, float ph, float rnd)
{
    switch (sh) {
    case GS_TRI: return ph < 0.5f ? 4.0f * ph - 1.0f : 3.0f - 4.0f * ph;
    case GS_UP: return 2.0f * ph - 1.0f;
    case GS_DOWN: return 1.0f - 2.0f * ph;
    case GS_SQUARE: return ph < 0.5f ? 1.0f : -1.0f;
    case GS_RANDOM: return rnd;
    default: return fm_sin_turns(ph);
    }
}
void synth_glfo_restart(synth_t *s)
{
    s->g_reset = 1;
    for (int t = 0; t < NTRK; t++) for (int l = 0; l < XM_LFOS; l++)
        if (xmod_cfg(s,t,l*XM_FIELDS+3) == 2) xm.state[t][l].reset = 1;
}
void synth_xmod_scale(int key, uint16_t mask) { xm.key = (uint8_t)(key % 12); xm.mask = mask; }
float synth_xmod_value(int track, int dest)
{
    return track >= 0 && track < NTRK && dest >= 0 && dest < XM_DESTS ? (float)xm.out[track][0][dest] * (1.0f / 16.0f) : 0.0f;
}
static void xmod_prepare(synth_t *s)
{
    for (int t = 0; t < NTRK; t++) {
        uint8_t config[24];
        for(int f=0;f<24;f++)config[f]=(uint8_t)xmod_cfg(s,t,f);
        const uint8_t *p = config;
        int was_active = xm.active[t];
        xm.quant[t] = xm.active[t] = 0;
        for (int l = 0; l < XM_LFOS; l++) {
            const uint8_t *c = p + l * XM_FIELDS;
            if (c[0] && c[0] < XM_SHAPES) {
                xm.active[t] = 1;
                for (int j = 0; j < XM_ROUTES; j++)
                    if (c[4 + j * 2] == XD_SCALE && c[5 + j * 2] != 64) xm.quant[t] = 1;
            }
        }
        if (!xm.active[t]) {
            if (was_active) for (int k=0;k<XM_SLOTS;k++) for (int d=0;d<XM_DESTS;d++) xm.out[t][k][d]=0;
            xm.state[t][0].shape=xm.state[t][1].shape=0;
            continue;
        }
        for (int k = 0; k < s->nck; k++) {
            for (int d = 0; d < XM_DESTS; d++) xm.out[t][k][d] = 0;
            for (int l = 0; l < XM_LFOS; l++) {
                const uint8_t *c = p + l * XM_FIELDS;
                float v = xm_tick(&xm.state[t][l], c, s->bpm, CHUNK_S);
                if (!c[0]) continue;
                for (int j = 0; j < XM_ROUTES; j++) {
                    int d = c[4 + j * 2], a = (int)c[5 + j * 2] - 64;
                    if (d > XD_OFF && d < XM_DESTS && a) {
                        float depth = (float)a / (a < 0 ? 64.0f : 63.0f);
                        int q = (int)(v * depth * 127.0f * 16.0f);
                        xm.out[t][k][d] = (int16_t)(xm.out[t][k][d] + q);
                    }
                }
            }
        }
    }
}
static float xmod_param(int trk, int p, int k)
{
    int d = p == TP_PAN ? XD_PAN : p == TP_CUT ? XD_CUT : p == TP_RES ? XD_RES :
            p == TP_VOLUME ? XD_VOLUME : p == TP_SEND1 ? XD_SEND1 : p == TP_SEND2 ? XD_SEND2 :
            p == TP_CAMT ? XD_CHAR : p >= TP_E1 && p <= TP_E4 ? XD_E1 + p - TP_E1 :
            p >= TP_A && p <= TP_R ? XD_A + p - TP_A : p == TP_FENV ? XD_FENV : XD_OFF;
    return d ? (float)xm.out[trk][k][d] * (1.0f / 16.0f) : 0.0f;
}
float synth_glfo_now(const synth_t *s) { return s->g_now; }
/* the shared LFO over the block's chunks (synth.h GS_*, GD_*): its offset per chunk, which voice_chunk adds to the
 * routed tracks' destination */
static void glfo_prepare(synth_t *s)
{
    const uint8_t *g = s->par[SY_GLFO_TRK];
    int type = g[TP_LTYPE], k;
    float dph, amt;
    if (s->g_reset) {
        s->g_reset = 0;
        s->g_ph = 0.0f;
    }
    if (!type || type > NGS) {
        for (k = 0; k < NCK; k++)
            s->goff[k] = 0.0f;
        s->g_now = 0.0f;
        return;
    }
    dph = glfo_hz(g[TP_LSPEED], s->bpm) * CHUNK_S;
    amt = fm_clampf(((float)g[TP_LAMT] - 64.0f) * (127.0f / 63.0f), -127.0f, 127.0f);
    for (k = 0; k < s->nck; k++) {
        float ph = s->g_ph + dph;
        if (ph >= 1.0f) {
            ph -= 1.0f;
            if (!s->g_rng)
                s->g_rng = 0x9E3779B9u;
            s->g_sh = 2.0f * (float)(xs(&s->g_rng) >> 8) * (1.0f / 16777216.0f) - 1.0f;   /* a fresh step a cycle */
        }
        s->g_ph = ph;
        s->g_now = glfo_shape(type - 1, ph, s->g_sh);
        s->goff[k] = s->g_now * amt;
    }
}
void synth_prepare(synth_t *s, uint32_t n)
{
    float tpk[NTRK];
    int i, k, nck = 0;
    uint32_t off = (SY_CHUNK - s->pos) % SY_CHUNK;
    for (; off < n && nck < NCK; off += SY_CHUNK)
        nck++;
    s->nck = (uint8_t)(nck ? nck : 1);
    glfo_prepare(s);
    xmod_prepare(s);
    for (i = 0; i < NTRK; i++)
        tpk[i] = 0.0f;
    for (k = 0; k < NVOICE; k++) {               /* each track's loudest voice, the voices' peaks cleared: one pass */
        voice_t *v = &s->v[k];
        if (v->trk < NTRK) {
            if (v->peak > tpk[v->trk])
                tpk[v->trk] = v->peak;
            v->peak = 0.0f;
        }
    }
    for (i = 0; i < NTRK; i++) {
        trk_t *t = &s->t[i];
        int type = P(s, i, TP_LTYPE), lx = P(s, i, TP_LX), lx2 = P(s, i, TP_LX2), engine = P(s, i, TP_ENGINE);
        float hz = type == LT_PUMP ? 0.0f : lfo_hz(P(s, i, TP_LSPEED), s->bpm), dph = hz * CHUNK_S;
        float amt = (float)P(s, i, TP_LAMT), pk = 0.0f, vib = 0.0f, vol = 0.0f;
        {   /* the performance pitch: from the last stretch's value to this one's over the chunks (one stretch
             * behind, smooth); a note on the track since: at its value at once */
            float to = (float)t->perf.pitch_c;
            t->pb_base = t->pb_snap ? to : t->pb_last;
            t->pb_step = (to - t->pb_base) / (float)s->nck;
            t->pb_base = to - t->pb_step * (float)s->nck;      /* (the last chunk exactly at the value) */
            t->pb_last = to;
            t->pb_snap = 0;
        }
        t->ldest = LD_NONE;
        t->lscale = 0.0f;
        t->lf_in = t->lf_out = 0.0f;
        if (type == LT_WAVE || type == LT_DRIFT) {
            int d = LD_TP[P(s, i, TP_LDEST) & 3][lx & 3];
            t->ldest = (int16_t)d;
            if (d >= 0) {
                const tp_info_t *in = tp_info(d, engine);
                t->lscale = (float)(in->hi - in->lo) * (1.0f / 127.0f);
            } else if (d == LD_PITCH) {
                t->lscale = 1.0f;
            }
            if (type == LT_DRIFT)
                fade_secs(lx2, &t->lf_in, &t->lf_out);
        } else if (type == LT_WOBBLE) {
            fade_secs(lx, &t->lf_in, &t->lf_out);
            vib = (amt - 64.0f) * (100.0f / 63.0f);                 /* cents */
            vol = ((float)P(s, i, TP_LDEST) - 64.0f) * (1.0f / 63.0f);
        }
        for (k = 0; k < nck; k++) {
            float ph, val = 0.0f, pitch = 0.0f, gain = 1.0f;
            ph = t->lfo_ph + dph;
            if (ph >= 1.0f) {
                ph -= 1.0f;
                t->lfo_sh = frand(&t->rng);      /* a fresh sample on every cycle */
            }
            t->lfo_ph = ph;
            switch (type) {
            case LT_WAVE:
                val = lfo_wave_value(lx2, ph) * (amt - 64.0f) * (127.0f / 63.0f) * t->lscale;
                break;
            case LT_DRIFT: {                    /* a wander: slews to each cycle's sample within a quarter cycle */
                float sm = fm_minf(4.0f * dph, 1.0f);
                t->lfo_sm += (t->lfo_sh - t->lfo_sm) * sm;
                val = (0.5f + 0.5f * t->lfo_sm) * amt * t->lscale;
                break;
            }
            case LT_WOBBLE: {
                float w = lfo_wave_trem(lx2, ph);
                pitch = w * vib;
                gain = vol >= 0.0f ? 1.0f - vol * (0.5f - 0.5f * w) : 1.0f + vol * (0.5f + 0.5f * w);
                break;
            }
            case LT_PUMP: {
                if (t->duck_hold > 0.0f)
                    t->duck_hold -= CHUNK_S;
                else
                    t->duck *= fm_expf(-6.9f * CHUNK_S / env_seconds((float)lx * (1.0f / 127.0f)));
                gain = 1.0f - amt * (1.0f / 127.0f) * t->duck;
                break;
            }
            default: break;
            }
            t->loff[k] = val;
            t->lpitch[k] = pitch;
            t->lgain[k] = gain;
        }
        pk = tpk[i];                             /* the meter: the loudest voice of the track (gathered above) */
        {
            uint32_t q = (uint32_t)(fm_minf(pk, 2.0f) * 16383.5f), old = synth_peak[i];
            old = old - (old >> 4);              /* the fall: about 1/16 a block */
            synth_peak[i] = (uint16_t)(q > old ? q : old);
        }
    }
    for (k = 0; k < NVOICE; k++)
        s->v[k].ck = 0;
    s->pos = (uint16_t)((s->pos + n) % SY_CHUNK);
}

/* ------------------------------------------------------ the character --- */
/* the character stage's chunk values (synth.h CT_*): c.cx[] from the four knobs, the LFO's offset on the
 * amount, and the note's frequency (ring). The state (cz) starts from 0 when the type changes. */
static inline float sat_c(float x)               /* a soft saturation (tanh-like, cubic): flat at +-1 from |x| = 1.5 */
{
    x = fm_minf(fm_maxf(x, -1.5f), 1.5f);
    return x - x * x * x * (4.0f / 27.0f);
}
static inline float sin_q(float ph)              /* a quick sine of a phase in turns (any), within 0.1 %: the folder's */
{
    float x = ph - fm_floorf(ph + 0.5f), y = 8.0f * x - 16.0f * x * fm_fabsf(x);
    return y + 0.225f * (y * fm_fabsf(y) - y);
}
static float ch_lp_hz(float t) { return 400.0f * fm_exp2f(t * 5.64385619f); }      /* tone 0..1: 400 Hz .. 20 kHz */
static float ch_pivot_hz(float a) { return 150.0f * fm_exp2f(a * 5.32192809f); }   /* amount 0..1: 150 Hz .. 6 kHz */
static float ch_alpha(float hz) { return hz >= 19000.0f ? 1.0f : 1.0f - fm_expf(-FM_TWO_PI * hz * INV_SR); }
static float ch_tape_hz(float t) { return 1500.0f * fm_exp2f(t * 3.585f); }        /* tone 0..1: 1.5 .. 18 kHz */
static float ch_smp_hz(float t) { return 2000.0f * fm_exp2f(t * 3.322f); }         /* tone 0..1: 2 .. 20 kHz */
static float ch_smp_rate(float a) { return 26040.0f * fm_exp2f(-a * 1.243f); }     /* amount 0..1: 26 .. 11 kHz */
#define CH_DC (FM_TWO_PI * 12.0f * INV_SR)       /* the DC blocker's one-pole: 12 Hz */
#define CH_REF 0.7f                              /* the drive keeps the level of a peak here (an engine's, about) */
#define CH_FOLD 0.6f                             /* the fold's level once it folds (a folded wave's RMS: about a saw's) */
/* the type's values from the amount and tone (0..1) and the note's frequency (ring). tc: the tone as -1..1,
 * 0 at 64 exactly (the page prints it so: the fold's bias, the crush's balance, the tilt) */
static void char_coefs(int type, float a, float t, float freq, float *x)
{
    float tc = fm_clampf((t * 127.0f - 64.0f) * (1.0f / 63.0f), -1.0f, 1.0f);
    switch (type) {
    case CT_DRIVE: {                             /* gain 0.25 .. 32 (-12 .. +30 dB), made up at CH_REF */
        float g = 0.25f * fm_exp2f(a * 7.0f);
        x[0] = g;
        x[1] = CH_REF / sat_c(g * CH_REF) * (1.0f - 0.25f * a);   /* (squarer as it drives: a little less) */
        x[2] = ch_alpha(ch_lp_hz(t));
        break;
    }
    case CT_FOLD: {                              /* sin(pi/2 (g x + bias)): g 0.3 .. 8, the bias +-1 */
        float g = 0.3f * fm_exp2f(a * 4.74f), b = tc;
        x[0] = g * 0.25f;                        /* (in turns) */
        x[1] = fm_maxf(CH_FOLD, 2.0f / (FM_PI * g));   /* small g: linear, unity; large: about the input's level */
        x[3] = b * 0.25f;
        x[4] = fm_sin_turns(b * 0.25f);          /* the output at x = 0: taken off, so silence stays silent */
        x[5] = CH_DC;
        break;
    }
    case CT_CRUSH: {                             /* bits 16 .. 3 and the rate / 1 .. / 45, by the balance */
        float wb = fm_minf(1.0f, 1.0f + tc), wr = fm_minf(1.0f, 1.0f - tc);
        float q = fm_exp2f(15.0f - a * wb * 13.0f);
        x[0] = q;
        x[1] = 1.0f / q;
        x[2] = fm_exp2f(-a * wr * 5.5f);
        break;
    }
    case CT_RING: {                              /* x (1 - d + d sin): the level made up for the depth */
        int k = (int)(t * 127.0f + 0.5f) >> 3;   /* (as tp_text_par prints it) */
        float w = fm_minf(freq * RING_R[k < 0 ? 0 : k > 15 ? 15 : k] * INV_SR, 0.45f) * FM_TWO_PI;
        float m = fm_rsqrtf((1.0f - a) * (1.0f - a) + 0.5f * a * a);
        x[0] = (1.0f - a) * m;
        x[1] = a * m;
        x[2] = fm_cosf(w);                       /* the sine as a rotating phasor: cz[4] + i cz[5] */
        x[3] = fm_sinf(w);
        x[5] = CH_DC;
        break;
    }
    case CT_TAPE: {                              /* the drive's curve, gentler; a two-pole roll-off; the wow's depth */
        float g = 0.5f * fm_exp2f(a * 4.0f);
        x[0] = g;
        x[1] = CH_REF / sat_c(g * CH_REF) * (1.0f - 0.15f * a);
        x[2] = ch_alpha(ch_tape_hz(t));
        x[3] = 2.0f + 8.0f * a;                  /* cents (voice_chunk) */
        break;
    }
    case CT_SAMPLER: {                           /* rate and bits by the amount; the input and output filters */
        float r = ch_smp_rate(a), q = fm_exp2f(13.0f - 3.0f * a);   /* (14 .. 11 bits: a voice sits well under 0 dB) */
        x[0] = q;
        x[1] = 1.0f / q;
        x[2] = r * INV_SR;
        x[3] = ch_alpha(0.45f * r);
        x[4] = ch_alpha(ch_smp_hz(t));
        break;
    }
    case CT_TILT: {                              /* lows x 2^-tilt, highs x 2^tilt about the pivot */
        float tl = tc;
        x[0] = ch_alpha(ch_pivot_hz(a));
        x[1] = fm_exp2f(-tl);
        x[2] = fm_exp2f(tl);
        break;
    }
    default:
        break;
    }
}
static void char_prep(synth_t *s, voice_t *v, int dest, float off, float gch, int k)   /* (gch: the shared LFO on the amount) */
{
    cfg_t *c = &v->c;
    int trk = v->trk, type = P(s, trk, TP_CTYPE), mix = P(s, trk, TP_CMIX), i;
    if (type >= NCT || mix == 0)
        type = CT_OFF;
    if (type != c->ctype) {
        for (i = 0; i < 8; i++)
            v->cz[i] = 0.0f;
        c->ctype = (uint8_t)type;
    }
    if (type == CT_OFF)
        return;
    c->cx[7] = fm_minf((float)mix, 127.0f) * (1.0f / 127.0f);
    {   /* (the coefficients cost exps: made again only when what they come from moved) */
        float a = fm_clampf(pf(s, trk, TP_CAMT, dest, off, k) + gch, 0.0f, 127.0f) * (1.0f / 127.0f);
        float t = fm_minf((float)P(s, trk, TP_CTONE), 127.0f) * (1.0f / 127.0f), f = type == CT_RING ? c->freq : 0.0f;
        if (type != c->cin_type || a != c->cin[0] || t != c->cin[1] || f != c->cin[2]) {
            char_coefs(type, a, t, c->freq, c->cx);
            c->cin_type = (uint8_t)type;
            c->cin[0] = a;
            c->cin[1] = t;
            c->cin[2] = f;
        }
    }
    if (type == CT_RING) {                       /* the phasor back to unit length, once a chunk (or at 1 + 0i) */
        float re = v->cz[4], im = v->cz[5], r2 = re * re + im * im, g = r2 > 0.5f ? fm_rsqrtf(r2) : 0.0f;
        v->cz[4] = g > 0.0f ? re * g : 1.0f;
        v->cz[5] = im * g;
    }
}

/* the Character page's picture (synth.h) */
float char_picture(const uint8_t *par, float u)
{
    int type = par[TP_CTYPE] < NCT ? par[TP_CTYPE] : CT_OFF;
    float a = (float)(par[TP_CAMT] & 127) * (1.0f / 127.0f), t = (float)(par[TP_CTONE] & 127) * (1.0f / 127.0f);
    float wet = (float)(par[TP_CMIX] & 127) * (1.0f / 127.0f), x[8], d = u, y = u;
    char_coefs(type, a, t, 220.0f, x);
    switch (type) {
    case CT_DRIVE: case CT_TAPE: y = sat_c(u * x[0]) * x[1]; break;
    case CT_FOLD: y = (sin_q(u * x[0] + x[3]) - x[4]) * x[1]; break;
    case CT_CRUSH: case CT_SAMPLER: {            /* a cycle of 200 samples, held and quantised */
        float hold = 1.0f / x[2], n = fm_floorf(u * 200.0f / hold) * hold;
        d = 0.9f * fm_sin_turns(u);
        y = fm_floorf(0.9f * fm_sin_turns(n * (1.0f / 200.0f)) * x[0] + 0.5f) * x[1];
        break;
    }
    case CT_RING: {                              /* two cycles of a sine, times the modulator (its peak at 1) */
        int k = (par[TP_CTONE] & 127) >> 3;
        d = fm_sin_turns(2.0f * u);
        y = d * (x[0] + x[1] * fm_sin_turns(2.0f * u * RING_R[k])) / (x[0] + x[1]);
        break;
    }
    case CT_TILT: {                              /* the response, 50 Hz .. 20 kHz: dB / 6 */
        float w = 50.0f * fm_exp2f(u * 8.64385619f) / ch_pivot_hz(a), w2 = w * w;
        d = 0.0f;
        y = 3.01029996f * fm_log2f((x[1] * x[1] + x[2] * x[2] * w2) / (1.0f + w2)) * (1.0f / 6.0f);
        break;
    }
    default: return u;
    }
    return d + wet * (y - d);
}

/* one sample of one side through the stage: d dry, back the mix of it and the effect. lp / dc: that side's
 * states; mod: the ring's gain this sample; upd: the crush's hold takes a new sample */
SY_INLINE float char_one(float d, const int type, float c0, float c1, float c2, float c3, float c4, float c5, float wet,
                         float *lp, float *dc, float mod, int upd)
{
    float y;
    switch (type) {
    case CT_DRIVE:
        y = sat_c(d * c0) * c1;
        *lp += c2 * (y - *lp);
        y = *lp;
        break;
    case CT_FOLD:
        y = (sin_q(d * c0 + c3) - c4) * c1;
        *dc += c5 * (y - *dc);
        y -= *dc;
        break;
    case CT_CRUSH:
        if (upd)
            *lp = fm_floorf(d * c0 + 0.5f) * c1;
        y = *lp;
        break;
    case CT_RING:                                /* (a sine times its own pitch has DC: blocked) */
        y = d * mod;
        *dc += c5 * (y - *dc);
        y -= *dc;
        break;
    case CT_TILT:
        *lp += c0 * (d - *lp);
        y = *lp * c1 + (d - *lp) * c2;
        break;
    case CT_TAPE:                                /* lp, dc: the roll-off's two poles */
        y = sat_c(d * c0) * c1;
        *lp += c2 * (y - *lp);
        *dc += c2 * (*lp - *dc);
        y = *dc;
        break;
    default:
        y = d;
        break;
    }
    (void)c4;
    return d + wet * (y - d);
}
SY_INLINE void char_loop(const float *cx, float *cz, float *xl, float *xr, int k, const int type, const int stereo)
{
    const float c0 = cx[0], c1 = cx[1], c2 = cx[2], c3 = cx[3], c4 = cx[4], c5 = cx[5], wet = cx[7];
    float z0 = cz[0], z1 = cz[1], z2 = cz[2], z3 = cz[3], ph = cz[4], qi = cz[5];
    int j;
    if (type == CT_SAMPLER) {                    /* z0 / z1 the input filter, z2 / z3 the held sample, z6 / z7 the output's */
        float z6 = cz[6], z7 = cz[7];
        for (j = 0; j < k; j++) {
            int upd;
            ph += c2;
            upd = ph >= 1.0f;
            if (upd)
                ph -= 1.0f;
            z0 += c3 * (xl[j] - z0);
            if (upd)
                z2 = fm_floorf(z0 * c0 + 0.5f) * c1;
            z6 += c4 * (z2 - z6);
            xl[j] += wet * (z6 - xl[j]);
            if (stereo) {
                z1 += c3 * (xr[j] - z1);
                if (upd)
                    z3 = fm_floorf(z1 * c0 + 0.5f) * c1;
                z7 += c4 * (z3 - z7);
                xr[j] += wet * (z7 - xr[j]);
            }
        }
        cz[0] = fm_flush(z0);
        cz[1] = fm_flush(z1);
        cz[2] = z2;
        cz[3] = z3;
        cz[4] = ph;
        cz[6] = fm_flush(z6);
        cz[7] = fm_flush(z7);
        return;
    }
    for (j = 0; j < k; j++) {
        float mod = 0.0f;
        int upd = 0;
        if (type == CT_RING) {                   /* (ph, qi): the phasor, turned a step */
            float nr = ph * c2 - qi * c3;
            qi = ph * c3 + qi * c2;
            ph = nr;
            mod = c0 + c1 * qi;
        } else if (type == CT_CRUSH) {
            ph += c2;
            if (ph >= 1.0f) {
                ph -= 1.0f;
                upd = 1;
            }
        }
        xl[j] = char_one(xl[j], type, c0, c1, c2, c3, c4, c5, wet, &z0, &z2, mod, upd);
        if (stereo)
            xr[j] = char_one(xr[j], type, c0, c1, c2, c3, c4, c5, wet, &z1, &z3, mod, upd);
    }
    cz[0] = fm_flush(z0);
    cz[1] = fm_flush(z1);
    cz[2] = fm_flush(z2);
    cz[3] = fm_flush(z3);
    cz[4] = ph;
    cz[5] = qi;
}
static void char_stage(const float *cx, float *cz, int type, int stereo, float *xl, float *xr, int k)
{
    switch (type * 2 + (stereo != 0)) {
    case CT_DRIVE * 2: char_loop(cx, cz, xl, xr, k, CT_DRIVE, 0); break;
    case CT_DRIVE * 2 + 1: char_loop(cx, cz, xl, xr, k, CT_DRIVE, 1); break;
    case CT_FOLD * 2: char_loop(cx, cz, xl, xr, k, CT_FOLD, 0); break;
    case CT_FOLD * 2 + 1: char_loop(cx, cz, xl, xr, k, CT_FOLD, 1); break;
    case CT_CRUSH * 2: char_loop(cx, cz, xl, xr, k, CT_CRUSH, 0); break;
    case CT_CRUSH * 2 + 1: char_loop(cx, cz, xl, xr, k, CT_CRUSH, 1); break;
    case CT_RING * 2: char_loop(cx, cz, xl, xr, k, CT_RING, 0); break;
    case CT_RING * 2 + 1: char_loop(cx, cz, xl, xr, k, CT_RING, 1); break;
    case CT_TILT * 2: char_loop(cx, cz, xl, xr, k, CT_TILT, 0); break;
    case CT_TILT * 2 + 1: char_loop(cx, cz, xl, xr, k, CT_TILT, 1); break;
    case CT_TAPE * 2: char_loop(cx, cz, xl, xr, k, CT_TAPE, 0); break;
    case CT_TAPE * 2 + 1: char_loop(cx, cz, xl, xr, k, CT_TAPE, 1); break;
    case CT_SAMPLER * 2: char_loop(cx, cz, xl, xr, k, CT_SAMPLER, 0); break;
    case CT_SAMPLER * 2 + 1: char_loop(cx, cz, xl, xr, k, CT_SAMPLER, 1); break;
    default: break;
    }
}

/* a kit's character (synth.h char_bus): the stage on the kit's summed pair */
void char_bus(chbus_t *c, const uint8_t *par, float *l, float *r, int n)
{
    int type = par[TP_CTYPE] < NCT ? par[TP_CTYPE] : CT_OFF, i;
    float a, t;
    if (par[TP_CMIX] == 0)
        type = CT_OFF;
    if (type != c->type) {                       /* another type: its states start clean */
        for (i = 0; i < 8; i++)
            c->cz[i] = 0.0f;
        c->type = (uint8_t)type;
        c->cin_type = 0xFFu;
    }
    if (type == CT_OFF)
        return;
    a = (float)(par[TP_CAMT] & 127) * (1.0f / 127.0f);
    t = (float)(par[TP_CTONE] & 127) * (1.0f / 127.0f);
    if (type != c->cin_type || a != c->cin[0] || t != c->cin[1]) {
        char_coefs(type, a, t, KIT_RING_HZ, c->cx);
        c->cin_type = (uint8_t)type;
        c->cin[0] = a;
        c->cin[1] = t;
    }
    c->cx[7] = (float)(par[TP_CMIX] & 127) * (1.0f / 127.0f);
    if (type == CT_RING) {                       /* the phasor back to unit length (char_prep) */
        float re = c->cz[4], im = c->cz[5], r2 = re * re + im * im, g = r2 > 0.5f ? fm_rsqrtf(r2) : 0.0f;
        c->cz[4] = g > 0.0f ? re * g : 1.0f;
        c->cz[5] = im * g;
    }
    char_stage(c->cx, c->cz, type, 1, l, r, n);
}

/* ------------------------------------------------------------ the chunk --- */
static void voice_pitch(synth_t *s, voice_t *v)
{
    v->c.freq = 440.0f * fm_exp2f((v->pitch_cur - 69.0f + v->c.pitch_off * 0.01f) * (1.0f / 12.0f));
    if (v->c.freq > 18000.0f)
        v->c.freq = 18000.0f;
    eng_prep(v, s->bpm);
}

/* a chunk boundary: the parameters into c */
/* r9.5 independent layer: zero mode preserves the previous renderer bit-for-bit. */
static float layer_value(const synth_t *s, int t, int p, int d, int k)
{
    float x = (float)P(s,t,p);
    if (xm.active[t]) x += (float)xm.out[t][k][d] * (1.0f/16.0f);
    return fm_clampf(x,0.0f,127.0f);
}
static void layer_prepare(synth_t *s, voice_t *v, int k)
{
    layer_t *l=&v->layer;
    int t=v->trk, mode=layer_engine(v->engine) ? P(s,t,TP_LAYER_MODE) : 0;
    l->mode=(uint8_t)(mode>4?4:mode);
    if (!l->mode) { l->env=0.0f; return; }
    int level=v->engine==EG_KNIT?TP_X2:TP_X1, pitch=v->engine==EG_KNIT?TP_X1:TP_X2;
    float st=(float)P(s,t,pitch)-64.0f;
    if(xm.active[t]) st+=(float)xm.out[t][k][XD_LAYER_PITCH]*(12.0f/(127.0f*16.0f));
    st=fm_clampf(st,-24.0f,24.0f);
    if (v->engine==EG_KNIT) st+=(float)(s->par[t][TP_O2FINE]-64)*0.01f;
    if(l->last_freq!=v->c.freq || l->last_pitch!=st) {
        l->inc=fm_minf(v->c.freq*fm_exp2f(st*(1.0f/12.0f))*INV_SR,0.45f);
        l->id=1.0f/l->inc; l->last_pitch=st; l->last_freq=v->c.freq;
    }
    l->gain=layer_value(s,t,level,XD_LAYER_LEVEL,k)*(1.0f/127.0f);
    int a=P(s,t,TP_LAYER_A), r=P(s,t,TP_LAYER_R);
    if (a!=l->attack) { l->ar=INV_SR/env_seconds((float)a*(1.0f/127.0f)); l->attack=(uint8_t)a; }
    if (r!=l->release) { l->rc=fm_expf(-6.9f*INV_SR/layer_release_seconds((float)r*(1.0f/127.0f))); l->release=(uint8_t)r; }
    float cut=layer_value(s,t,TP_LAYER_CUT,XD_LAYER_CUT,k);
    float oct=(cut*(8.64385619f/127.0f))+(float)(P(s,t,TP_LAYER_ENV)-64)*(6.0f/64.0f)*l->env;
    if(oct!=l->last_cut) {
        float hz=fm_clampf(50.0f*fm_exp2f(oct),50.0f,20000.0f);
        l->coef=1.0f-fm_expf(-FM_TWO_PI*hz*INV_SR); l->last_cut=oct;
    }
    l->type=(uint8_t)(P(s,t,TP_LAYER_TYPE)&1);
}
static inline float layer_wave(float p, int table, int frame)
{
    float x=p*(float)WT_N; int i=(int)x; float f=x-(float)i;
    const int8_t *w=WT[table][frame];
    return ((float)w[i]+((float)w[(i+1)&(WT_N-1)]-(float)w[i])*f)*(1.0f/128.0f);
}
static float layer_sample(voice_t *v)
{
    layer_t *l=&v->layer;
    float x, p=step1(l->ph,l->inc);
    l->ph=p;
    l->env=v->held?fm_minf(1.0f,l->env+l->ar):l->env*l->rc;
    if (l->env<1e-3f && !v->held) l->env=0.0f;
    if (l->gain==0.0f) return 0.0f;
    if (v->engine==EG_VOILE) {
        x=layer_wave(p,0,0);
    } else if(l->mode==1) {
        x=saw_pulse(p,l->inc,l->id,saw_pulse_k(v->c.ex[4],v->c.ex[3]));
    } else if(l->mode==2) {
        x=0.85f*layer_wave(p,0,0)+0.12f*frand(&v->rng);
    } else if(l->mode==3) {
        /* Reuse Jacquard's glass, progressively removing upper partials at high pitch. */
        x=layer_wave(p,7,l->inc<0.09f?3:l->inc<0.15f?2:l->inc<0.225f?1:0);
    } else {
        l->ph2=step1(l->ph2,l->inc*0.9977f);
        x=0.5f*(layer_wave(p,0,0)+layer_wave(l->ph2,0,0));
    }
    l->lp+=l->coef*(x-l->lp);
    return (l->type?x-l->lp:l->lp)*l->env*l->gain;
}

static void voice_chunk(synth_t *s, voice_t *v)
{
    trk_t *t = &s->t[v->trk];
    cfg_t *c = &v->c;
    int trk = v->trk, k = v->ck < s->nck ? v->ck : s->nck - 1, dest = t->ldest, i;
    float lenv = 1.0f, off, lg, vol, lev, pan, vg, res;
    const uint8_t *gp = s->par[SY_GLFO_TRK];
    const int groute = (gp[TP_LX] & 15) | (gp[TP_LX2] & 15) << 4;
    const float g = groute >> trk & 1 ? s->goff[k] : 0.0f;   /* the shared LFO on this track (synth.h GD_*) */
    const int gd = g != 0.0f ? gp[TP_LDEST] % NGD : -1;
    v->ck = (uint8_t)(v->ck + 1);
    v->nchunk = (uint8_t)(v->nchunk + 1);
    if (!v_sounding(v))
        return;
    /* the LFO's fade envelope: this voice's time since its note */
    if (t->lf_in > 0.0f)
        lenv = fm_minf(v->tsec / t->lf_in, 1.0f);
    else if (t->lf_out > 0.0f)
        lenv = fm_maxf(1.0f - v->tsec / t->lf_out, 0.0f);
    v->tsec += CHUNK_S;
    off = t->loff[k] * lenv;
    lg = 1.0f - (1.0f - t->lgain[k]) * lenv;
    {
        int gm = v->fresh ? 0 : E_GLIDE[v->engine < NENGINE ? v->engine : 0];
        for (i = 0; i < 4; i++) {
            float e;
            c->ek[i] = fm_minf(pf(s, trk, TP_E1 + i, dest, off, k), 127.0f);   /* a foreign lock value stays in range */
            e = c->ek[i] * (1.0f / 127.0f);
            c->e[i] = gm >> i & 1 ? glide_to(c->e[i], e) : e;   /* (a fresh voice: at its values at once) */
        }
    }
    {   /* the envelopes' coefficients cost an exp each: only for a knob that moved */
        static const uint8_t EP[8] = {TP_A, TP_D, TP_S, TP_R, TP_FA, TP_FD, TP_FS, TP_FR};
        float *co[8];
        co[0] = &c->amp_ar; co[1] = &c->amp_dc; co[2] = &c->amp_sl; co[3] = &c->amp_rc;
        co[4] = &c->flt_ar; co[5] = &c->flt_dc; co[6] = &c->flt_sl; co[7] = &c->flt_rc;
        for (i = 0; i < 8; i++) {
            float x = pf(s, trk, EP[i], dest, off, k) * (1.0f / 127.0f);
            if (x == v->env_in[i])
                continue;
            v->env_in[i] = x;
            *co[i] = (i & 3) == 0 ? env_rate(env_seconds(x)) : (i & 3) == 2 ? x : env_coef(env_seconds(x));
        }
    }
    /* the filter: 50 Hz .. 20 kHz over the knob, the performance offset, keytrack, velocity */
    {   /* the cutoff and the resonance glide too (~10 ms), as the engine knobs */
        float co = (pf(s, trk, TP_CUT, dest, off, k) + (float)t->perf.cut + (gd == GD_CUT ? g : 0.0f)) * (8.64385619f / 127.0f)
                   + pf(s, trk, TP_KTRK, dest, off, k) * (1.0f / 127.0f) * (v->pitch - 60.0f) * (1.0f / 12.0f);
        c->cut_oct = v->fresh ? co : glide_to(c->cut_oct, co);
    }
    c->fenv_oct = (pf(s, trk, TP_FENV, dest, off, k) - 64.0f) * (6.0f / 64.0f) * (0.5f + 0.5f * v->vel);
    res = fm_clampf((pf(s, trk, TP_RES, dest, off, k) + (gd == GD_RES ? g : 0.0f)) * (1.0f / 127.0f), 0.0f, 1.0f);
    if (!v->fresh)
        res = glide_to(c->kres * 0.25f, res);
    c->kq = 2.0f * fm_exp2f(-res * 4.3f);        /* Q 0.5 .. 10 */
    c->kres = res * 4.0f;                        /* the ladder's feedback */
    c->ftype = (uint8_t)P(s, trk, TP_FTYPE);
    if (c->ftype >= NFT)
        c->ftype = FT_LP24;
    c->mute = t->perf.mute;
#ifdef PLAT_HOST
    if (!(synth_host_solo >> trk & 1u))          /* the host's stems (LOOM_SOLO): a track left out is muted */
        c->mute = 1;
#endif
    /* gains */
    vol = pf(s, trk, TP_VOLUME, dest, off, k) * (1.0f / 127.0f);
    lev = tp_level_gain(P(s, trk, TP_LEVEL)) * (100.0f / 127.0f);
    vg = (0.25f + 0.75f * v->vel * v->vel) * vol * vol * lev * lg * (1.0f - 0.6f * res);
    if (gd == GD_VOL)                            /* (a tremolo: down to silence, up to +6 dB) */
        vg *= fm_clampf(1.0f + g * (1.0f / 127.0f), 0.0f, 2.0f);
    pan = fm_clampf((pf(s, trk, TP_PAN, dest, off, k) - 64.0f + (float)t->perf.pan + (gd == GD_PAN ? g : 0.0f)) *
                    (1.0f / 64.0f), -1.0f, 1.0f);
    if (pan != v->pan_in || v->fresh) {          /* the pan's cos / sin: only when it moved */
        v->pan_in = pan;
        v->pan_l = pan == 0.0f ? 0.70710678f : fm_cosf((pan + 1.0f) * 0.78539816f);   /* centre: exactly equal */
        v->pan_r = pan == 0.0f ? 0.70710678f : fm_sinf((pan + 1.0f) * 0.78539816f);
    }
    c->gl = v->pan_l * vg;
    c->gr = v->pan_r * vg;
    c->g1 = fm_clampf((pf(s, trk, TP_SEND1, dest, off, k) + (float)t->perf.send1) + (gd == GD_SEND1 ? g : 0.0f), 0.0f, 127.0f) * (1.0f / 127.0f);
    c->g2 = fm_clampf((pf(s, trk, TP_SEND2, dest, off, k) + (float)t->perf.send2) + (gd == GD_SEND2 ? g : 0.0f), 0.0f, 127.0f) * (1.0f / 127.0f);
    /* pitch: the glide, bend, performance pitch, vibrato, an LFO on the pitch (+-12 semitones at 100 %) */
    v->pitch_cur += (v->pitch - v->pitch_cur) * v->glide_k;
    c->pitch_off = (float)t->bend_c + t->pb_base + t->pb_step * (float)(k + 1) + t->lpitch[k] * lenv;
    if (!xm.active[trk]) {
        if (dest == LD_PITCH) c->pitch_off += off * (1200.0f / 127.0f);
        if (gd == GD_PITCH) c->pitch_off += g * (1200.0f / 127.0f);
    } else {
        float musical = (float)(xm.out[trk][k][XD_PITCH] + xm.out[trk][k][XD_SCALE]) * (1200.0f / (127.0f * 16.0f));
        if (dest == LD_PITCH) musical += off * (1200.0f / 127.0f);
        if (gd == GD_PITCH) musical += g * (1200.0f / 127.0f);
        if (xm.quant[trk]) musical = (xm_quantize(v->pitch_cur + musical * 0.01f, xm.key, xm.mask) - v->pitch_cur) * 100.0f;
        c->pitch_off += musical;
    }
    {   /* the sound's octave (Play 2) */
        int oc = P(s, trk, TP_OCT);
        c->pitch_off += (float)((oc > 4 ? 4 : oc) - 2) * 1200.0f;
    }
    if (c->ctype == CT_TAPE) {                   /* the tape's wow and flutter (char_coefs: cx[3] cents) */
        v->cz[4] = wrap1(v->cz[4] + 0.55f * (float)SY_CHUNK * INV_SR);
        v->cz[5] = wrap1(v->cz[5] + 6.1f * (float)SY_CHUNK * INV_SR);
        c->pitch_off += c->cx[3] * c->cx[7] * (fm_sin_turns(v->cz[4]) + 0.25f * fm_sin_turns(v->cz[5]));
    }
    {   /* the frequency and the engine's increments: when the pitch or a knob moved (or every 4th
         * chunk: the organ's pitch wobble and phasor trim); knit's and rayon's second pages: when they moved */
        float pin = v->pitch_cur + c->pitch_off * 0.01f;
        int moved = pin != v->pitch_in || v->fresh || (v->nchunk & 3) == 0;
        if (v->engine == EG_RAYON) {             /* its second page (rayon_prep, rayon_chunk) */
            int fl = P(s, trk, TP_X1), fo = P(s, trk, TP_X2), ks = P(s, trk, TP_X3);
            float fall = fl ? fm_expf(-(float)SY_CHUNK / (0.02f * fm_exp2f((float)fl * (7.64f / 127.0f)) * SY_SR)) : 0.0f;
            float fv = (float)fo * (1.0f / 127.0f), kv = (float)ks * (1.0f / 127.0f);
            moved |= fall != c->ex[8] || kv != c->ex[10];
            c->ex[8] = fall;
            c->ex[9] = fv;
            c->ex[10] = kv;
        }
        if (v->engine == EG_SAMPLE) {          /* its loop page (smp_prep) */
            float a = (float)P(s, trk, TP_X1), b = (float)P(s, trk, TP_X2);
            moved |= a != c->ex[8] || b != c->ex[9];
            c->ex[8] = a;
            c->ex[9] = b;
        }
        if (v->engine == EG_KNIT) {            /* its second page (knit_prep) */
            for (i = 0; i < 4; i++) {
                float xv = (float)P(s, trk, TP_X1 + i);
                if (i == 0)                      /* (osc 2's fine, in cents: TP_O2FINE, past the locks: the knob) */
                    xv += (float)(s->par[trk][TP_O2FINE] - 64) * 0.01f;
                moved |= xv != c->ex[18 + i];
                c->ex[18 + i] = xv;
            }
        }
        for (i = 0; i < 4 && !moved; i++)
            moved = c->e[i] != v->e_in[i];
        if (moved) {
            v->pitch_in = pin;
            for (i = 0; i < 4; i++)
                v->e_in[i] = c->e[i];
            voice_pitch(s, v);
        }
    }
    eng_chunk(v);
    layer_prepare(s,v,k);
    char_prep(s, v, dest, off, gd == GD_CHAR ? g : 0.0f, k);
}

/* the steal's turn: the old note has faded; start the pending one here, mid-chunk */
static void voice_steal(synth_t *s, voice_t *v)
{
    int held = v->pend_held;
    v->amp.stage = ENV_OFF;                      /* so voice_start sees a fresh voice */
    v->amp.level = v->flt.level = 0.0f;
    v->steal_phase = 2;
    v->amp_cur = 0.0f;
    voice_start(s, v, v->pend_note, v->pend_vel, v->pend_glide, v->pend_tag, held, 1);
    v->pitch_cur = v->pitch;                     /* a stolen voice does not glide from the old note */
    if (!held)
        voice_release(v);
    voice_config_now(s, v);
}

/* a sub-block boundary (SUB samples, aligned in the chunk, or a voice configured mid-block): the
 * envelopes step, the filter's coefficients follow the filter envelope, the ramps (amp level, steal
 * fade, dry gains) aim at their next values. Between boundaries only the per-sample state moves. */
static void voice_subblock(synth_t *s, voice_t *v, int aligned)
{
    cfg_t *c;
    float hz, g, gl, gr;
    const float hk = 1.41421356f;
    if (v->steal_phase == 1 && v->steal_gain <= 0.0f) {   /* the old note has faded: the new one starts */
        int i;
        voice_steal(s, v);
        for (i = 0; i < 8; i++)
            v->f[i] = 0.0f;
        for (i = 0; i < 8; i++)
            v->cz[i] = 0.0f;
    }
    c = &v->c;
    v->fresh = 0;
    if (aligned) {
        env_step(&v->amp, c->amp_ar, c->amp_dc, c->amp_sl, c->amp_rc);
        env_step(&v->flt, c->flt_ar, c->flt_dc, c->flt_sl, c->flt_rc);
    }
    if (c->cut_oct == v->fco && v->flt.level == v->flv && c->fenv_oct == v->ffe && v->fhz > 0.0f) {
        hz = v->fhz;
    } else {
        hz = 50.0f * fm_exp2f(c->cut_oct + v->flt.level * c->fenv_oct);
        hz = hz > 20000.0f ? 20000.0f : hz < 50.0f ? 50.0f : hz;
        v->fco = c->cut_oct;
        v->flv = v->flt.level;
        v->ffe = c->fenv_oct;
    }
    if (hz == v->fhz && c->kq == v->fkq && c->kres == v->fkres && c->ftype == v->fty) {
        /* the same as the last sub-block's (a settled envelope, no LFO on the cutoff): the coefficients stand */
    } else if (c->ftype == FT_LADDER) {          /* four one-poles: g per pole, k the feedback */
        v->b1 = fm_minf(1.0f - fm_expf(-FM_TWO_PI * hz * INV_SR), 0.9f);
        v->b2 = c->kres;
    } else {
        g = fm_tanf(FM_PI * fm_minf(hz, 0.45f * SY_SR) * INV_SR);
        v->a1 = 1.0f / (1.0f + g * (g + c->kq));
        v->a2 = g * v->a1;
        v->a3 = g * v->a2;
        if (c->ftype == FT_LP24) {
            v->b1 = 1.0f / (1.0f + g * (g + hk));
            v->b2 = g * v->b1;
            v->b3 = g * v->b2;
        }
    }
    v->fhz = hz;
    v->fkq = c->kq;
    v->fkres = c->kres;
    v->fty = c->ftype;
    v->amp_step = (v->amp.level - v->amp_cur) * (1.0f / (float)SUB);
    if (v->steal_phase == 1) {
        v->sg_step = v->steal_gain > STEAL_RATE * (float)SUB ? -STEAL_RATE : -v->steal_gain * (1.0f / (float)SUB);
    } else if (v->steal_phase == 2) {
        if (v->steal_gain + STEAL_RATE * (float)SUB >= 1.0f) {
            v->sg_step = (1.0f - v->steal_gain) * (1.0f / (float)SUB);
            v->steal_phase = 0;                  /* reaches 1 at the end of this block */
        } else {
            v->sg_step = STEAL_RATE;
        }
    } else {
        v->sg_step = 0.0f;
    }
    gl = c->mute ? 0.0f : c->gl;
    gr = c->mute ? 0.0f : c->gr;
    v->gl_step = (gl - v->glc) * (0.35f / (float)SUB);
    v->gr_step = (gr - v->grc) * (0.35f / (float)SUB);
}

/* the sample loop for one sub-block: the filter (one of six), the ramps, the outputs. Instantiated
 * for each filter type and for mono / stereo with constant arguments, so the compiler folds the
 * branches away; the generic switch is in voice_samples. chr: the filter only, its output back into
 * xl / xr for the character stage (char_stage), then out_loop does the rest.
 *   lp24:    a TPT state-variable low-pass (resonant) into a second, flat one: 24 dB, aggressive
 *   ladder:  four one-poles in series with the last one's output fed back through a soft clip
 *   lp12:    the one resonant TPT stage, 12 dB
 *   hp12:    its high-pass output, 12 dB
 *   bp12:    its band-pass output, scaled by 1 / Q so the peak stays at unity
 *   dynamic: the drum tracks' filter (drumline.c): on a synth voice it is a bypass */
SY_INLINE void sample_loop(voice_t *v, float *xl, float *xr, float *l, float *r, float *s1, float *s2,
                               int k, const int ftype, const int stereo, const int chr)
{
    const cfg_t *c = &v->c;
    const float a1 = v->a1, a2 = v->a2, a3 = v->a3, b1 = v->b1, b2 = v->b2, b3 = v->b3, kq = c->kq;
    const float es = v->amp_step, sgs = v->sg_step, gls = v->gl_step, grs = v->gr_step;
    const float g1 = c->g1, g2 = c->g2, wide = stereo ? 1.41421356f : 1.0f;
    const float lcomp = 1.0f + b2 * 0.25f;       /* the ladder: its passband falls as the feedback rises */
    const int sends = g1 > 0.0f || g2 > 0.0f;
#ifdef PLAT_WEB
    const float bloom_dry = (bloom_export_mask >> v->trk & 1u) ? 1.0f : 0.0f;
#else
    const float bloom_dry = 1.0f;
#endif
    float f0 = v->f[0], f1 = v->f[1], f2 = v->f[2], f3 = v->f[3], f4 = v->f[4], f5 = v->f[5], f6 = v->f[6], f7 = v->f[7];
    float e = v->amp_cur, sg = v->steal_gain, glc = v->glc, grc = v->grc, pk = 0.0f;
    int j;
    for (j = 0; j < k; j++) {
        float yl, yr, ol, or_, a;
        if (ftype == FT_LADDER) {
            float x = xl[j] - b2 * soft3(f3);
            f0 += b1 * (x - f0);
            f1 += b1 * (f0 - f1);
            f2 += b1 * (f1 - f2);
            f3 += b1 * (f2 - f3);
            yl = f3 * lcomp;
        } else if (ftype == FT_DYNAMIC) {
            yl = xl[j];
        } else {
            float t3 = xl[j] - f1, t1 = a1 * f0 + a2 * t3, t2 = f1 + a2 * f0 + a3 * t3;
            f0 = 2.0f * t1 - f0;
            f1 = 2.0f * t2 - f1;
            yl = ftype == FT_HP12 ? xl[j] - kq * t1 - t2 : ftype == FT_BP12 ? kq * t1 : t2;
            if (ftype == FT_LP24) {
                float w3 = yl - f3, w1 = b1 * f2 + b2 * w3, w2 = f3 + b2 * f2 + b3 * w3;
                f2 = 2.0f * w1 - f2;
                f3 = 2.0f * w2 - f3;
                yl = w2;
            }
        }
        if (stereo) {
            if (ftype == FT_LADDER) {
                float x = xr[j] - b2 * soft3(f7);
                f4 += b1 * (x - f4);
                f5 += b1 * (f4 - f5);
                f6 += b1 * (f5 - f6);
                f7 += b1 * (f6 - f7);
                yr = f7 * lcomp;
            } else if (ftype == FT_DYNAMIC) {
                yr = xr[j];
            } else {
                float u3 = xr[j] - f5, u1 = a1 * f4 + a2 * u3, u2 = f5 + a2 * f4 + a3 * u3;
                f4 = 2.0f * u1 - f4;
                f5 = 2.0f * u2 - f5;
                yr = ftype == FT_HP12 ? xr[j] - kq * u1 - u2 : ftype == FT_BP12 ? kq * u1 : u2;
                if (ftype == FT_LP24) {
                    float w3 = yr - f7, w1 = b1 * f6 + b2 * w3, w2 = f7 + b2 * f6 + b3 * w3;
                    f6 = 2.0f * w1 - f6;
                    f7 = 2.0f * w2 - f7;
                    yr = w2;
                }
            }
        } else {
            yr = yl;
        }
        if (chr) {
            xl[j] = yl;
            if (stereo)
                xr[j] = yr;
            continue;
        }
        e += es;
        sg += sgs;
        glc += gls;
        grc += grs;
        a = e * sg * wide;
        ol = yl * a * glc;
        or_ = yr * a * grc;
        l[j] += ol * bloom_dry;
        r[j] += or_ * bloom_dry;
        if (sends) {
            float mono = (ol + or_) * 0.5f;
            s1[j] += mono * g1;
            s2[j] += mono * g2;
        }
        yl = fm_fabsf(yl);
        if (yl > pk)
            pk = yl;
    }
    v->amp_cur = e;
    v->steal_gain = sg;
    v->glc = glc;
    v->grc = grc;
    pk *= e * sg * wide * (glc > grc ? glc : grc);   /* the meter: this block's loudest, roughly */
    if (pk > v->peak)
        v->peak = pk;
    v->f[0] = fm_flush(f0); v->f[1] = fm_flush(f1); v->f[2] = fm_flush(f2); v->f[3] = fm_flush(f3);
    if (stereo) {
        v->f[4] = fm_flush(f4); v->f[5] = fm_flush(f5); v->f[6] = fm_flush(f6); v->f[7] = fm_flush(f7);
    }
}

/* a stereo voice's filter, one channel at a time (ch 0: f[0..3], 1: f[4..7]), its output back into x: the same
 * arithmetic as sample_loop's, with half the state live at once (a fused stereo loop held both channels' states,
 * the coefficients and the ramps, more than the FM-1's registers: it spilled) */
SY_INLINE void flt_loop(voice_t *v, float *x, int k, const int ftype, const int ch)
{
    const float a1 = v->a1, a2 = v->a2, a3 = v->a3, b1 = v->b1, b2 = v->b2, b3 = v->b3, kq = v->c.kq;
    const float lcomp = 1.0f + b2 * 0.25f;
    float *f = v->f + 4 * ch;
    float f0 = f[0], f1 = f[1], f2 = f[2], f3 = f[3];
    int j;
    for (j = 0; j < k; j++) {
        float y;
        if (ftype == FT_LADDER) {
            float u = x[j] - b2 * soft3(f3);
            f0 += b1 * (u - f0);
            f1 += b1 * (f0 - f1);
            f2 += b1 * (f1 - f2);
            f3 += b1 * (f2 - f3);
            y = f3 * lcomp;
        } else {
            float t3 = x[j] - f1, t1 = a1 * f0 + a2 * t3, t2 = f1 + a2 * f0 + a3 * t3;
            f0 = 2.0f * t1 - f0;
            f1 = 2.0f * t2 - f1;
            y = ftype == FT_HP12 ? x[j] - kq * t1 - t2 : ftype == FT_BP12 ? kq * t1 : t2;
            if (ftype == FT_LP24) {
                float w3 = y - f3, w1 = b1 * f2 + b2 * w3, w2 = f3 + b2 * f2 + b3 * w3;
                f2 = 2.0f * w1 - f2;
                f3 = 2.0f * w2 - f3;
                y = w2;
            }
        }
        x[j] = y;
    }
    f[0] = fm_flush(f0);
    f[1] = fm_flush(f1);
    f[2] = fm_flush(f2);
    f[3] = fm_flush(f3);
}
static void flt_channel(voice_t *v, float *x, int k, int ch)
{
    switch (v->c.ftype) {
    case FT_LP24: flt_loop(v, x, k, FT_LP24, ch); break;
    case FT_LADDER: flt_loop(v, x, k, FT_LADDER, ch); break;
    case FT_LP12: flt_loop(v, x, k, FT_LP12, ch); break;
    case FT_HP12: flt_loop(v, x, k, FT_HP12, ch); break;
    case FT_BP12: flt_loop(v, x, k, FT_BP12, ch); break;
    default: break;                              /* (dynamic: a bypass) */
    }
}

/* after the character stage: the ramps and the outputs (sample_loop's second half) */
SY_INLINE void out_loop(voice_t *v, const float *xl, const float *xr, float *l, float *r, float *s1, float *s2,
                        int k, const int stereo)
{
    const cfg_t *c = &v->c;
    const float es = v->amp_step, sgs = v->sg_step, gls = v->gl_step, grs = v->gr_step;
    const float g1 = c->g1, g2 = c->g2, wide = stereo ? 1.41421356f : 1.0f;
    const int sends = g1 > 0.0f || g2 > 0.0f;
#ifdef PLAT_WEB
    const float bloom_dry = (bloom_export_mask >> v->trk & 1u) ? 1.0f : 0.0f;
#else
    const float bloom_dry = 1.0f;
#endif
    float e = v->amp_cur, sg = v->steal_gain, glc = v->glc, grc = v->grc, pk = 0.0f;
    int j;
    for (j = 0; j < k; j++) {
        float yl = xl[j], yr = stereo ? xr[j] : yl, ol, or_, a;
        e += es;
        sg += sgs;
        glc += gls;
        grc += grs;
        a = e * sg * wide;
        ol = yl * a * glc;
        or_ = yr * a * grc;
        l[j] += ol * bloom_dry;
        r[j] += or_ * bloom_dry;
        if (sends) {
            float mono = (ol + or_) * 0.5f;
            s1[j] += mono * g1;
            s2[j] += mono * g2;
        }
        yl = fm_fabsf(yl);
        if (yl > pk)
            pk = yl;
    }
    v->amp_cur = e;
    v->steal_gain = sg;
    v->glc = glc;
    v->grc = grc;
    pk *= e * sg * wide * (glc > grc ? glc : grc);
    if (pk > v->peak)
        v->peak = pk;
}
static void out_mono(voice_t *v, const float *xl, float *l, float *r, float *s1, float *s2, int k)
{
    out_loop(v, xl, xl, l, r, s1, s2, k, 0);
}
static void out_stereo(voice_t *v, const float *xl, const float *xr, float *l, float *r, float *s1, float *s2,
                       int k)
{
    out_loop(v, xl, xr, l, r, s1, s2, k, 1);
}

/* m samples (inside a chunk) of one voice into the buffers */
static void voice_samples(synth_t *s, voice_t *v, float *l, float *r, float *s1, float *s2, int m)
{
    float bl[SY_CHUNK], br[SY_CHUNK], *xl = bl, *xr = br;
    int i = 0, ahead = 0;
    while (i < m) {
        int k = SUB - (v->pos & (SUB - 1));
        if (k > m - i)
            k = m - i;
        if ((v->pos & (SUB - 1)) == 0 || v->fresh)
            voice_subblock(s, v, (v->pos & (SUB - 1)) == 0);
        if (ahead) {                             /* (knit's oscillators made for the whole call already: below) */
            xl = bl + i;
            xr = br + i;
        } else if (i == 0 && v->engine == EG_KNIT && v->steal_phase != 1 && m <= SY_CHUNK) {
            /* knit's oscillators depend on the chunk's values alone (its pitch, detune, gains: voice_chunk), and m
             * stays inside a chunk: all of them at once, each oscillator's set-up once instead of a sub-block's
             * worth of times; the filter, the character and the outputs keep their sub-blocks below (a pending
             * steal starts its note at a sub-block's start: then a sub-block at a time). The same samples */
            eng_run(v, bl, br, m);
            ahead = 1;
        } else {
            xl = bl;
            xr = br;
            eng_run(v, xl, xr, k);
        }
#define SL(ft, ch) sample_loop(v, xl, xr, l + i, r + i, s1 + i, s2 + i, k, ft, 0, ch)
        if (v->layer.mode) {
            /* Each source has its own filter/envelope, then shared Character and output ramps. */
            int stereo=v->c.stereo;
            flt_channel(v,xl,k,0);
            if(stereo) flt_channel(v,xr,k,1);
            float e=v->amp_cur, saved_step=v->amp_step;
            for(int j=0;j<k;j++) {
                e+=saved_step;
                float y=layer_sample(v)*(stereo?0.70710678f:1.0f);
                xl[j]=xl[j]*e+y;
                if(stereo) xr[j]=xr[j]*e+y;
            }
            if(v->c.ctype!=CT_OFF) char_stage(v->c.cx,v->cz,v->c.ctype,stereo,xl,xr,k);
            v->amp_cur=1.0f; v->amp_step=0.0f;
            if(stereo) out_stereo(v,xl,xr,l+i,r+i,s1+i,s2+i,k);
            else out_mono(v,xl,l+i,r+i,s1+i,s2+i,k);
            v->amp_cur=e; v->amp_step=saved_step;
        } else
        if (v->c.stereo) {                       /* the filter a channel at a time, the character, the outputs */
            flt_channel(v, xl, k, 0);
            flt_channel(v, xr, k, 1);
            if (v->c.ctype != CT_OFF)
                char_stage(v->c.cx, v->cz, v->c.ctype, v->c.stereo, xl, xr, k);
            out_stereo(v, xl, xr, l + i, r + i, s1 + i, s2 + i, k);
        } else if (v->c.ctype == CT_OFF) {
            switch (v->c.ftype) {
            case FT_LP24: SL(FT_LP24, 0); break;
            case FT_LADDER: SL(FT_LADDER, 0); break;
            case FT_LP12: SL(FT_LP12, 0); break;
            case FT_HP12: SL(FT_HP12, 0); break;
            case FT_BP12: SL(FT_BP12, 0); break;
            default: SL(FT_DYNAMIC, 0); break;
            }
        } else {                                 /* the filter, the character stage, then the outputs */
            switch (v->c.ftype) {
            case FT_LP24: SL(FT_LP24, 1); break;
            case FT_LADDER: SL(FT_LADDER, 1); break;
            case FT_LP12: SL(FT_LP12, 1); break;
            case FT_HP12: SL(FT_HP12, 1); break;
            case FT_BP12: SL(FT_BP12, 1); break;
            default: break;                      /* (dynamic: a bypass, xl / xr as they are) */
            }
            char_stage(v->c.cx, v->cz, v->c.ctype, v->c.stereo, xl, xr, k);
            out_mono(v, xl, l + i, r + i, s1 + i, s2 + i, k);
        }
#undef SL
        i += k;
        v->pos = (uint16_t)(v->pos + k);
    }
}

void synth_render(synth_t *s, int v0, int v1, float *l, float *r, float *s1, float *s2, uint32_t n)
{
    synth_render_on(s, v0 == 0 && v1 < NVOICE, v0, v1, l, r, s1, s2, n);   /* (the second core's: [0, k), k < 16) */
}

/* the queue's order (engine.c ws_take0 / ws_take1: the second core takes from the bottom, the first from the top):
 * the sounding voices by measured cost, the dearest at the bottom and the cheapest at the top: the second core, free
 * first, takes the dear ones; the first, which comes to the queue late (the sequencer, then the kits only it renders),
 * takes cheap ones, so the last taken are small and neither is left with a whole knit voice (~17 % of a block) while
 * the other waits; within a cost an engine's together (its code fetched once). The silent voices are not in it (each
 * take is a sync between the cores): synth_idle moves them on. Returns how many are in it. The simulator keeps every
 * voice in their order (its sums the same split or whole: synth_test) */
int synth_order(const synth_t *s, int8_t *ord)
{
    int vi, j;
#ifndef PLAT_HOST
    int c[NVOICE], n = 0;
    for (vi = 0; vi < NVOICE; vi++) {
        int ck = synth_voice_cost(s, vi);
        if (!ck)
            continue;
        for (j = n; j > 0 && (c[j - 1] < ck || (c[j - 1] == ck && s->v[ord[j - 1]].engine > s->v[vi].engine)); j--) {
            ord[j] = ord[j - 1];
            c[j] = c[j - 1];
        }
        ord[j] = (int8_t)vi;
        c[j] = ck;
        n++;
    }
    return n;
#else
    for (vi = 0; vi < NVOICE; vi++)
        ord[vi] = (int8_t)vi;
    (void)s;
    (void)j;
    return NVOICE;
#endif
}
/* the voices left out of the queue (not among ord's first n): n frames on, as synth_render_on moves a silent one (its
 * place in the chunk; at a chunk's start voice_chunk's counts, all it does for a silent voice) */
void synth_idle(synth_t *s, const int8_t *ord, int nord, uint32_t n)
{
    uint32_t in = 0;
    int k, vi;
    for (k = 0; k < nord; k++)
        in |= 1u << ord[k];
    for (vi = 0; vi < NVOICE; vi++) {
        voice_t *v = &s->v[vi];
        uint32_t i = 0;
        if (in >> vi & 1u)
            continue;
        while (i < n) {
            uint32_t m = SY_CHUNK - v->pos;
            if (m > n - i)
                m = n - i;
            if (v->pos == 0) {
                v->ck = (uint8_t)(v->ck + 1);
                v->nchunk = (uint8_t)(v->nchunk + 1);
            }
            v->pos = (uint16_t)(v->pos + m);
            if (v->pos >= SY_CHUNK)
                v->pos = 0;
            i += m;
        }
    }
}
void synth_render_on(synth_t *s, int core, int v0, int v1, float *l, float *r, float *s1, float *s2, uint32_t n)
{
    int vi;
    if (v0 < 0)
        v0 = 0;
    if (v1 > NVOICE)
        v1 = NVOICE;
    uint32_t (*clk)(void) = synth_clock;
    volatile uint32_t *prof = synth_prof[core != 0];
    int8_t ord[NVOICE];
    int no = 0, oi;
    for (vi = v0; vi < v1; vi++) {               /* on the FM-1 the voices grouped by engine (each engine's code
                                                  * fetched from the flash once, then reused from the cache by the
                                                  * next); the simulator keeps their order: its sums the same split
                                                  * or whole (synth_test) */
        int j = no++;
#ifndef PLAT_HOST
        int e = s->v[vi].engine;
        while (j > 0 && s->v[ord[j - 1]].engine > e) {
            ord[j] = ord[j - 1];
            j--;
        }
#endif
        ord[j] = (int8_t)vi;
    }
    for (oi = 0; oi < no; oi++) {
        voice_t *v = &s->v[vi = ord[oi]];
        uint32_t i = 0, t0 = 0, tc = 0, tk = 0;
        const int timed = clk && (v_sounding(v) || v->pos == 0);
        if (timed) {
            t0 = clk();
            synth_vinfo[vi] = (uint8_t)((synth_vinfo[vi] & 32u) | (v->engine & 31u) | (v->fresh & 2 ? 32u : 0u) |
                                        (prof == synth_prof[1] ? 64u : 0u) | 128u);
        }
        if (v->fresh & 2) {                      /* a note started since the last render: its parameters now, from
                                                  * this stretch's first slot (at a chunk's start the chunk's own
                                                  * configuration below is the first) */
            v->fresh &= (uint8_t)~2u;
            if (v->pos != 0) {
                uint8_t ck = v->ck;
                if (timed)
                    tk = clk();
                voice_chunk(s, v);
                if (timed)
                    tc += clk() - tk;
                v->ck = ck;
                v->nchunk = (uint8_t)(v->nchunk - 1);
            }
        }
        while (i < n) {
            uint32_t m = SY_CHUNK - v->pos;
            if (m > n - i)
                m = n - i;
            if (v->pos == 0) {
                if (timed)
                    tk = clk();
                voice_chunk(s, v);
                if (timed)
                    tc += clk() - tk;
            }
            if (v_sounding(v))
                voice_samples(s, v, l + i, r + i, s1 + i, s2 + i, (int)m);
            else
                v->pos = (uint16_t)(v->pos + m);
            if (v->pos >= SY_CHUNK)
                v->pos = 0;
            i += m;
        }
        if (timed) {
            tk = clk() - t0;
            synth_vblk[vi] += tk;
            if (n >= 32u && !(synth_vinfo[vi] & 32u) && v_sounding(v)) {   /* the split's costs: a running mean of
                                                                          * the voice's time a frame, not its first
                                                                          * render's (its set-up) */
                float x = (float)tk / (float)n;
                v->cost_m = v->cost_m > 0.0f ? v->cost_m + (x - v->cost_m) * 0.25f : x;
                s->t[v->trk < NTRK ? v->trk : 0].cost_m = v->cost_m;
            }
            prof[NENGINE] += tc;
            prof[v->engine < NENGINE ? v->engine : 0] += tk - tc;
            if (tk > synth_vworst[0]) {
                synth_vworst[0] = tk;
                synth_vworst[1] = v->engine;
                synth_vworst[2] = n;
            }
        }
    }
}

int synth_sounding(const synth_t *s, int v0, int v1)
{
    int i;
    for (i = v0 < 0 ? 0 : v0; i < v1 && i < NVOICE; i++)
        if (v_sounding(&s->v[i]))
            return 1;
    return 0;
}
int synth_slice_now(const synth_t *s, int trk, int *slice, int32_t *pos)
{
    int i, best = -1;
    for (i = 0; i < NVOICE; i++) {
        const voice_t *v = &s->v[i];
        if (v->trk != trk || v->engine != EG_SLICE || v->amp.stage == ENV_OFF || v->steal_phase == 1 ||
            v->o[4] < 0.5f || v->o[3] > 0.5f)
            continue;
        if (best < 0 || v->age > s->v[best].age)
            best = i;
    }
    if (best < 0)
        return 0;
    *slice = (int)s->v[best].o[2];
    *pos = (int32_t)s->v[best].o[0];
    return 1;
}
int synth_voices_used(const synth_t *s)
{
    int i, n = 0;
    for (i = 0; i < NVOICE; i++)
        n += v_sounding(&s->v[i]);
    return n;
}

/* ------------------------------------------------------- parameter info --- */
static const tp_info_t FIXED[NTP_SOUND + 13] = {
    {"engine", 0, NENGINE - 1, 0, PK_NAMES, EG_NAME}, {"", 0, 127, 0, PK_NN, 0}, {"", 0, 127, 0, PK_NN, 0},
    {"", 0, 127, 0, PK_NN, 0},                          {"", 0, 127, 0, PK_NN, 0},
    {"mode", 0, 2, VM_POLY, PK_NAMES, VMODE_N},         {"porta", 0, 127, 0, PK_NUM, 0},
    {"bend", 0, 8, 2, PK_NAMES, BEND_N},                {"volume", 0, 127, 100, PK_PCT, 0},
    {"attack", 0, 127, 0, PK_MS, 0},                    {"decay", 0, 127, 60, PK_MS, 0},
    {"sustain", 0, 127, 100, PK_PCT, 0},                {"release", 0, 127, 40, PK_MS, 0},
    {"attack", 0, 127, 0, PK_MS, 0},                    {"decay", 0, 127, 60, PK_MS, 0},
    {"sustain", 0, 127, 0, PK_PCT, 0},                  {"release", 0, 127, 40, PK_MS, 0},
    {"cutoff", 0, 127, 110, PK_HZ, 0},                  {"reso", 0, 127, 20, PK_PCT, 0},
    {"env", 0, 127, 64, PK_BIP, 0},                     {"keytrack", 0, 127, 64, PK_PCT, 0},
    {"type", 0, NFT - 1, FT_LP24, PK_NAMES, FTYPE_N},    {"fx I", 0, 127, 0, PK_PCT, 0},
    {"fx II", 0, 127, 0, PK_PCT, 0},
    {"type", 0, NLT - 1, LT_OFF, PK_NAMES, LTYPE_N},    {"speed", 0, 127, 3, PK_HZ_SYNC, 0},
    {"amount", 0, 127, 64, PK_BIP, 0},                  {"dest", 0, NLD - 1, LD_FILTER, PK_NAMES, LDEST_N},
    {"param", 0, 3, 0, PK_NUM, 0},                      {"shape", 0, 3, 1, PK_NAMES, VSHAPE_N},
    /* the character stage: its amount and tone print per type (tp_text_par) */
    {"type", 0, NCT - 1, CT_OFF, PK_NAMES, CTYPE_N},    {"amount", 0, 127, 64, PK_PCT, 0},
    {"tone", 0, 127, 64, PK_BIP, 0},                    {"mix", 0, 127, 127, PK_PCT, 0},
    /* TP_X1 .. TP_X4: the engine's second page: none but an engine's own (tp_info: knit's, rayon's) */
    {"-", 0, 0, 0, PK_NUM, 0}, {"-", 0, 0, 0, PK_NUM, 0}, {"-", 0, 0, 0, PK_NUM, 0}, {"-", 0, 0, 0, PK_NUM, 0},
    {"octave", 0, 4, 2, PK_NAMES, OCT_N},                /* TP_OCT */
    /* TP_PLAYER .. TP_CHAN */
    {"player", 0, NPL - 1, PL_OFF, PK_NAMES, PLAYER_N}, {"speed", 0, 10, 4, PK_NAMES, ARPSPD_N},
    {"pattern", 0, 5, 0, PK_NAMES, ARPPAT_N},           {"range", 1, 4, 1, PK_NUM, 0},
    {"hold", 0, 1, 0, PK_SWITCH, 0},                    {"length", 0, 2, 1, PK_NAMES, ARPLEN_N},
    {"style", 0, 5, 0, PK_NAMES, ARPSTY_N},             {"glide", 0, 2, 0, PK_NAMES, ARPGLD_N},
    {"stereo", 0, 2, 0, PK_NAMES, ARPSTE_N},            {"level", 0, 127, 100, PK_FADER, 0},
    {"pan", 0, 127, 64, PK_BIP, 0},                     {"follow", 0, 2, 1, PK_NAMES, BRAIN_N},
    {"midi out", 0, 1, 1, PK_SWITCH, 0}};
/* a drumline key's values (synth.h DP_*); its model's knobs take their names and defaults from drumline.c
 * (tp_info_par). The key's envelope and filter: its Envelope and Filter pages */
static const tp_info_t DRUMP[DP_N] = {{"model", 0, NDM - 1, 0, PK_NAMES, DM_NAME}, {"knob 1", 0, 127, 64, PK_NN, 0},
                                      {"knob 2", 0, 127, 64, PK_NN, 0}, {"knob 3", 0, 127, 64, PK_NN, 0},
                                      {"knob 4", 0, 127, 64, PK_NN, 0}, {"random", 0, 127, 0, PK_PCT, 0},
                                      {"pan", 0, 127, 64, PK_BIP, 0}, {"volume", 0, 127, 76, PK_DB, 0},
                                      {"mode", 0, NPM - 1, PM_ONESHOT, PK_NAMES, PM_NAME},
                                      {"attack", 0, 127, 0, PK_DMS, 0}, {"hold", 0, 127, 0, PK_DMS, 0},
                                      {"decay", 0, 127, 127, PK_DECAY, 0}, {"lag", 0, 127, 0, PK_LAGMS, 0},
                                      {"cutoff", 0, 127, 127, PK_HZ, 0}, {"reso", 0, 127, 0, PK_PCT, 0},
                                      {"env", 0, 127, 64, PK_BIP, 0}, {"drive", 0, 127, 0, PK_PCT, 0},
                                      {"type", 0, NDF - 1, DF_OFF, PK_NAMES, DFTYPE_N},
                                      {"fx I", 0, 127, 0, PK_PCT, 0}, {"fx II", 0, 127, 0, PK_PCT, 0}};
/* a drumline track's kit pages: Kit env (TP_A..TP_R) and Kit filter (the bus: TP_CUT..TP_KTRK) */
static const tp_info_t DRUMENV[4] = {{"lag", 0, 127, 0, PK_PCT, 0}, {"attack", 0, 127, 0, PK_PCT, 0},
                                     {"random", 0, 127, 0, PK_PCT, 0}, {"length", 0, 127, 64, PK_PCT, 0}};
static const tp_info_t DRUMFLT[4] = {{"lowcut", 0, 127, 0, PK_HZ, 0}, {"comp", 0, 127, 0, PK_PCT, 0},
                                     {"drive", 0, 127, 0, PK_PCT, 0}, {"hicut", 0, 127, 127, PK_HZ, 0}};
static const tp_info_t NONE_P = {"-", 0, 0, 0, PK_NUM, 0};
/* knit's second page: osc 2's interval (+-24 semitones about 64) and level, the sub, the noise (knit_prep) */
static const tp_info_t KNIT_X_P[4] = {{"osc 2", 40, 88, 64, PK_BIPST, 0}, {"level", 0, 127, 0, PK_PCT, 0},
                                    {"sub", 0, 127, 0, PK_PCT, 0}, {"noise", 0, 127, 0, PK_PCT, 0}};
static const tp_info_t O2FINE_P = {"osc 2 fine", 14, 114, 64, PK_CENT, 0};   /* (TP_O2FINE: +-50 cents) */
/* the sample engine's second page (its loop modes only): where the loop starts in the region that plays, and how much
 * of the rest it loops (0 auto: the sample's own loop, else to the region's end) (smp_prep) */
static const tp_info_t SAMPLE_X_P[4] = {{"loop start", 0, 127, 0, PK_PCT, 0}, {"loop len", 0, 127, 0, PK_PCT, 0},
                                        {"-", 0, 0, 0, PK_NUM, 0}, {"-", 0, 0, 0, PK_NUM, 0}};
/* orbit's second page: the index's fall (0 held; 20 ms .. 4 s), its floor, keyscale (rayon_prep) */
static const tp_info_t RAYON_X_P[4] = {{"fall", 0, 127, 0, PK_NUM, 0}, {"floor", 0, 127, 0, PK_PCT, 0},
                                       {"keyscale", 0, 127, 0, PK_PCT, 0}, {"-", 0, 0, 0, PK_NUM, 0}};
/* the MIDI engine (EG_MIDI): its second page's knobs (each named by its CC: tp_info_par), and the eight knobs' CC
 * numbers (TP_A..TP_R, TP_FA..TP_FR; set on the SEL list): cutoff, resonance, attack, release; mod wheel, decay,
 * reverb, chorus */
static const tp_info_t MIDI_X_P[4] = {{"cc", 0, 127, 0, PK_NN, 0}, {"cc", 0, 127, 64, PK_NN, 0},
                                      {"cc", 0, 127, 0, PK_NN, 0}, {"cc", 0, 127, 0, PK_NN, 0}};
static const tp_info_t MIDI_CC_P[8] = {{"knob 1", 0, NMIDI_CC - 1, 74, PK_NUM, 0}, {"knob 2", 0, NMIDI_CC - 1, 71, PK_NUM, 0},
                                       {"knob 3", 0, NMIDI_CC - 1, 73, PK_NUM, 0}, {"knob 4", 0, NMIDI_CC - 1, 72, PK_NUM, 0},
                                       {"knob 5", 0, NMIDI_CC - 1, 1, PK_NUM, 0},  {"knob 6", 0, NMIDI_CC - 1, 75, PK_NUM, 0},
                                       {"knob 7", 0, NMIDI_CC - 1, 91, PK_NUM, 0}, {"knob 8", 0, NMIDI_CC - 1, 93, PK_NUM, 0}};
static const char *const MIDI_CC_N[NMIDI_CC] = {"cc 0", "cc 1", "cc 2", "cc 3", "cc 4", "cc 5", "cc 6", "cc 7", "cc 8", "cc 9", "cc 10", "cc 11", "cc 12", "cc 13", "cc 14", "cc 15", "cc 16", "cc 17", "cc 18", "cc 19", "cc 20", "cc 21", "cc 22", "cc 23", "cc 24", "cc 25", "cc 26", "cc 27", "cc 28", "cc 29", "cc 30", "cc 31", "cc 32", "cc 33", "cc 34", "cc 35", "cc 36", "cc 37", "cc 38", "cc 39", "cc 40", "cc 41", "cc 42", "cc 43", "cc 44", "cc 45", "cc 46", "cc 47", "cc 48", "cc 49", "cc 50", "cc 51", "cc 52", "cc 53", "cc 54", "cc 55", "cc 56", "cc 57", "cc 58", "cc 59", "cc 60", "cc 61", "cc 62", "cc 63", "cc 64", "cc 65", "cc 66", "cc 67", "cc 68", "cc 69", "cc 70", "cc 71", "cc 72", "cc 73", "cc 74", "cc 75", "cc 76", "cc 77", "cc 78", "cc 79", "cc 80", "cc 81", "cc 82", "cc 83", "cc 84", "cc 85", "cc 86", "cc 87", "cc 88", "cc 89", "cc 90", "cc 91", "cc 92", "cc 93", "cc 94", "cc 95", "cc 96", "cc 97", "cc 98", "cc 99", "cc 100", "cc 101", "cc 102", "cc 103", "cc 104", "cc 105", "cc 106", "cc 107", "cc 108", "cc 109", "cc 110", "cc 111", "cc 112", "cc 113", "cc 114", "cc 115", "cc 116", "cc 117", "cc 118", "cc 119"};
static const tp_info_t STRUM_P[4] = {{"roll", 0, 63, 30, PK_NUM, 0}, {"pattern", 0, 3, 0, PK_NAMES, MPAT_N},
                                       {"-", 0, 0, 0, PK_NUM, 0}, {"hold", 0, 1, 0, PK_SWITCH, 0}};
/* the LFO's knobs per type (synth.h): speed / amount / dest / x / x2 */
static const tp_info_t LFO_SPEED_DUCK = {"source", 0, DUCK_METRO, 0, PK_NAMES, DUCK_N};
static const tp_info_t LFO_AMT[NLT] = {{"-", 0, 0, 0, PK_NUM, 0}, {"amount", 0, 127, 64, PK_BIP, 0},
                                       {"vibrato", 0, 127, 64, PK_BIP, 0}, {"amount", 0, 127, 64, PK_PCT, 0},
                                       {"amount", 0, 127, 80, PK_PCT, 0}};
static const tp_info_t LFO_DEST_TREM = {"volume", 0, 127, 96, PK_BIP, 0};
static const tp_info_t LFO_DEST_DUCK = {"hold", 0, 127, 54, PK_MS, 0};
static const tp_info_t LFO_X_TREM = {"envelope", 0, 127, 64, PK_FADE, 0};
static const tp_info_t LFO_X_DUCK = {"release", 0, 127, 76, PK_MS, 0};
static const tp_info_t LFO_X2_TREM = {"shape", 0, 4, 0, PK_NAMES, TSHAPE_N};
static const tp_info_t LFO_X2_RAND = {"envelope", 0, 127, 64, PK_FADE, 0};
static const tp_info_t LFO_PARAM_ENV = {"param", 0, 3, 0, PK_NAMES, ENVP_N};
static const tp_info_t LFO_PARAM_FLT = {"param", 0, 3, 0, PK_NAMES, FLTP_N};
static const tp_info_t LFO_PARAM_AMP = {"param", 0, 3, 0, PK_NAMES, AMPP_N};
/* Engine descriptors are immutable. Keeping them in flash avoids a permanent RAM copy
 * and lazy initialization in the main loop; no descriptor is used in the sample ISR. */
static const tp_info_t eknob[NENGINE][4] = {
    {{"wave", 0, 127, 0, PK_NN, 0}, {"detune", 0, 127, 20, PK_NN, 0}, {"voices", 1, KNIT_MAX, 1, PK_NUM, 0}, {"width", 0, 127, 0, PK_NN, 0}},
    {{"bright", 0, 127, 40, PK_NN, 0}, {"ratio", 0, 127, 25, PK_NN, 0}, {"edge", 0, 127, 0, PK_NN, 0}, {"tine", 0, 127, 0, PK_NN, 0}},
    {{"table", 0, WT_NTABLE - 1, 0, PK_NAMES, WTNAME_N}, {"scan", 0, 127, 40, PK_NN, 0}, {"bend", 0, 127, 0, PK_NN, 0}, {"ripple", 0, 127, 0, PK_NN, 0}},
    {{"stops", 1, 8, 3, PK_NUM, 0}, {"pedal", 1, 8, 4, PK_NUM, 0}, {"rotor", 1, 8, 2, PK_NUM, 0}, {"rate", 1, 8, 5, PK_NUM, 0}},
    {{"model", 0, NCANE - 1, 0, PK_NAMES, CANE_N}, {"timbre", 0, 127, 64, PK_NN, 0}, {"color", 0, 127, 64, PK_NN, 0}, {"damp", 0, 127, 0, PK_NN, 0}},
    {{"model", 0, NVOILE - 1, 2, PK_NAMES, VOILE_N}, {"timbre", 0, 127, 0, PK_NN, 0}, {"color", 0, 127, 64, PK_NN, 0}, {"breath", 0, 127, 0, PK_NN, 0}},
    {{"sample", 0, SMP_CR78_BASE + SMP_CR78_N - 1, 5, PK_SAMPLE, 0}, {"start", 0, 127, 0, PK_PCT, 0}, {"length", 0, 127, 127, PK_PCT, 0}, {"mode", 0, NSM - 1, SM_ONESHOT, PK_NAMES, SMODE_N}},
    {{"sample", 0, SMP_CR78_BASE + SMP_CR78_N - 1, SMP_BREAK, PK_SAMPLE, 0}, {"slices", 0, SL_NCOUNT - 1, 1, PK_NAMES, SLICES_N}, {"pitch", 40, 88, 64, PK_BIPST, 0}, {"gate", 0, 127, 127, PK_PCT, 0}},
    {{"-", 0, 127, 0, PK_NN, 0}, {"-", 0, 127, 0, PK_NN, 0}, {"-", 0, 127, 0, PK_NN, 0}, {"-", 0, 127, 0, PK_NN, 0}},
    {{"cc", 0, 127, 64, PK_NN, 0}, {"cc", 0, 127, 64, PK_NN, 0}, {"cc", 0, 127, 64, PK_NN, 0}, {"cc", 0, 127, 64, PK_NN, 0}},
    {{"pitch", 0, 127, 48, PK_NN, 0}, {"chirp", 0, 127, 80, PK_NN, 0}, {"decay", 0, 127, 52, PK_NN, 0}, {"-", 0, 127, 0, PK_NN, 0}}
};
static const tp_info_t lparam[NENGINE] = {
    {"param", 0, 3, 0, PK_NAMES, EG_KNOB[0]},
    {"param", 0, 3, 0, PK_NAMES, EG_KNOB[1]},
    {"param", 0, 3, 0, PK_NAMES, EG_KNOB[2]},
    {"param", 0, 3, 0, PK_NAMES, EG_KNOB[3]},
    {"param", 0, 3, 0, PK_NAMES, EG_KNOB[4]},
    {"param", 0, 3, 0, PK_NAMES, EG_KNOB[5]},
    {"param", 0, 3, 0, PK_NAMES, EG_KNOB[6]},
    {"param", 0, 3, 0, PK_NAMES, EG_KNOB[7]},
    {"param", 0, 3, 0, PK_NAMES, EG_KNOB[8]},
    {"param", 0, 3, 0, PK_NAMES, EG_KNOB[9]},
    {"param", 0, 3, 0, PK_NAMES, EG_KNOB[10]}
};
/* a drum model's knobs (four, up to eight): made when asked, into a ring (16: no caller holds
 * more at once; the UI's, the main loop's only). RAM is short: a table of every model's would take 48 bytes a model,
 * 96 with eight knobs */
static tp_info_t dk_ring[16];
static uint8_t dk_at;
static const tp_info_t *dknob_of(int m, int k);
static const tp_info_t DRUMX_P = {"knob 5", 0, 127, 0, PK_NN, 0};   /* a key's knob 5..8, the model unknown */

static const tp_info_t *dknob_of(int m, int k)   /* model m's knob k (0..7) */
{
    const char *nm = k < 4 ? DM_KNOB[m][k] : DM_KNOB2[m][k - 4];
    tp_info_t *i;
    if (k >= dm_knobs(m) || !nm)                 /* (a model of three: no fourth; of seven: no eighth) */
        return &NONE_P;
    i = &dk_ring[dk_at++ & 15u];
    *i = k < 4 ? DRUMP[DP_K1 + k] : DRUMX_P;
    i->name = nm;
    i->def = k < 4 ? DM_DEFAULT[m][k] : DM_DEFAULT2[m][k - 4];
    if ((m == DM_SOPHIE || m == DM_CLANG) && k == 4) {   /* their MODEL: a list */
        i->kind = PK_NAMES;
        i->hi = (uint8_t)(m == DM_SOPHIE ? 6 : 3);
        i->names = m == DM_SOPHIE ? SPH_MODEL_N : CLANG_MODEL_N;
    }
    if ((m == DM_SOPHIE && k == 6) || (m == DM_CLANG && k == 5))   /* their SWEEP: about the middle */
        i->kind = PK_BIP;
    if (m == DM_SAMPLE || m == DM_LOFI) {                        /* the sample model: sample, pitch (+-24 semitones), start, reverse */
        static const uint8_t KIND[4] = {PK_SAMPLE, PK_BIPST, PK_PCT, PK_SWITCH};
        i->kind = (m == DM_LOFI && k == 0) ? PK_NUM : KIND[k];
        i->lo = (uint8_t)(k == 1 ? 40 : 0);
        i->hi = (uint8_t)(k == 0 ? (m == DM_LOFI ? 4 : smp_slots() - 1) : k == 1 ? 88 : k == 3 ? 1 : 127);
    }
    return i;
}

static const char *const XM_SHAPE_N[XM_SHAPES] = {"off","sine","triangle","saw up","saw down","square","random","drift"};
static const char *const XM_MODE_N[3] = {"free","retrigger","transport"};
static const char *const LAYER_MODE_N[] = {"legacy","classic","air","glass","halo"};
static const char *const BODY_MODE_N[] = {"off","on"};
static const tp_info_t BODY_MODE_INFO = {"body",0,1,0,PK_NAMES,BODY_MODE_N};
static const char *const LAYER_FILTER_N[] = {"LP","HP"};
static const tp_info_t LAYER_INFO[LAYER_N] = {
    {"layer",0,4,0,PK_NAMES,LAYER_MODE_N}, {"filter",0,1,0,PK_NAMES,LAYER_FILTER_N},
    {"cutoff",0,127,100,PK_HZ,0}, {"attack",0,127,0,PK_MS,0},
    {"release",0,127,80,PK_MS,0}, {"env amt",0,127,64,PK_BIP,0}};
static const tp_info_t BODY_X_P[4] = {{"body",0,127,0,PK_PCT,0},{"pitch",40,88,64,PK_BIPST,0},{"-",0,0,0,PK_NUM,0},{"-",0,0,0,PK_NUM,0}};
static const char *const XM_DEST_N[XM_DESTS] = {"off","pan","pitch","pitch scale","cutoff","reso","volume","FX I","FX II","character","synth 1","synth 2","synth 3","synth 4","attack","decay","sustain","release","filter env","layer level","layer cutoff","layer pitch"};
/* Stable destination IDs; engine knobs are named in the track's current context. */
const char *synth_xmod_dest_name(int dest,int engine)
{
    if(dest>=XD_E1 && dest<=XD_E4 && engine>=0 && engine<NENGINE) {
        if(engine==EG_SLICE && dest==XD_E3) return "slice pitch";
        return EG_KNOB[engine][dest-XD_E1];
    }
    return XM_DEST_N[dest>=0 && dest<XM_DESTS?dest:XD_OFF];
}
static const tp_info_t XM_INFO[XM_FIELDS] = {
    {"shape",0,XM_SHAPES-1,0,PK_NAMES,XM_SHAPE_N}, {"rate",0,127,6,PK_NUM,0},
    {"phase",0,127,0,PK_NUM,0}, {"restart",0,2,0,PK_NAMES,XM_MODE_N},
    {"dest 1",0,XM_DESTS-1,0,PK_NAMES,XM_DEST_N}, {"depth 1",0,127,64,PK_BIP,0},
    {"dest 2",0,XM_DESTS-1,0,PK_NAMES,XM_DEST_N}, {"depth 2",0,127,64,PK_BIP,0},
    {"dest 3",0,XM_DESTS-1,0,PK_NAMES,XM_DEST_N}, {"depth 3",0,127,64,PK_BIP,0},
    {"dest 4",0,XM_DESTS-1,0,PK_NAMES,XM_DEST_N}, {"depth 4",0,127,64,PK_BIP,0}};
const tp_info_t *tp_info(int p, int engine)
{
    if (layer_engine(engine) && p>=TP_LAYER_MODE && p<TP_LAYER_END) return engine==EG_VOILE && p==TP_LAYER_MODE ? &BODY_MODE_INFO : &LAYER_INFO[p-TP_LAYER_MODE];
    if (p >= TP_XMOD0 && p < NTP) return &XM_INFO[(p - TP_XMOD0) % XM_FIELDS];
    if (p >= TP_E1 && p <= TP_E4) {
        if (engine < 0 || engine >= NENGINE)
            engine = EG_KNIT;
        return &eknob[engine][p - TP_E1];
    }
    if (engine == EG_MIDI && midi_cc_of(p) >= 0)
        return &MIDI_CC_P[midi_cc_of(p)];
    if (p >= TP_X1 && p <= TP_X4)                /* the engine's second page: knit's, rayon's, else none */
        return engine == EG_VOILE ? &BODY_X_P[p-TP_X1] : engine == EG_MIDI ? &MIDI_X_P[p - TP_X1] : engine == EG_RAYON ? &RAYON_X_P[p - TP_X1]
             : engine == EG_KNIT ? &KNIT_X_P[p - TP_X1] : engine == EG_SAMPLE ? &SAMPLE_X_P[p - TP_X1] : &NONE_P;
    if (engine == EG_DRUMLINE) {
        if (p >= TP_A && p <= TP_R)
            return &DRUMENV[p - TP_A];
        if (p >= TP_CUT && p <= TP_KTRK)
            return &DRUMFLT[p - TP_CUT];
    }
    if (tp_is_dkey(p))
        return &DRUMP[(p - TP_DRUM0) % DP_N];
    if (tp_is_dknob2(p))
        return &DRUMX_P;
    if (p == TP_O2FINE)                          /* (its range on any engine, so a project's check keeps it; knit's
                                                  * Sub page shows it) */
        return &O2FINE_P;
    if (p >= 0 && p < (int)(sizeof FIXED / sizeof FIXED[0]))
        return &FIXED[p];
    return &NONE_P;
}

const tp_info_t *tp_info_par(int p, const uint8_t *par)
{
    int engine = par[TP_ENGINE], lt = par[TP_LTYPE];
    if (p >= TP_P1 && p <= TP_AP4) {
        /* Character-only callers pass NTP_SOUND bytes; read the player only for player knobs. */
        int player = par[TP_PLAYER];
        if (player == PL_ARP)
            return &FIXED[p];
        if (player == PL_STRUM && p <= TP_P4)
            return &STRUM_P[p - TP_P1];
        return &NONE_P;
    }
    if (layer_engine(engine) && p>=TP_LAYER_MODE && p<TP_LAYER_END) return engine==EG_VOILE && p==TP_LAYER_MODE ? &BODY_MODE_INFO : &LAYER_INFO[p-TP_LAYER_MODE];
    if (tp_is_dkey(p)) {
        int s = (p - TP_DRUM0) / DP_N, k = (p - TP_DRUM0) % DP_N;
        if (k >= DP_K1 && k <= DP_K4)
            return dknob_of(par[TP_DRUM(s, DP_MODEL)] % NDM, k - DP_K1);
        return &DRUMP[k];
    }
    if (tp_is_dknob2(p)) {                       /* knob 5..8: the key's model's, or none */
        int s = (p - TP_DRUMX0) / DPX_N, j = (p - TP_DRUMX0) % DPX_N;
        return dknob_of(par[TP_DRUM(s, DP_MODEL)] % NDM, 4 + j);
    }
    if (engine == EG_MIDI && midi_knob(p) >= 0) {   /* a knob named by its CC: "cc 74" */
        tp_info_t *i = &dk_ring[dk_at++ & 15u];
        *i = *tp_info(p, engine);
        i->name = MIDI_CC_N[par[midi_cc_par(midi_knob(p))] % NMIDI_CC];
        return i;
    }
    if (lt >= NLT)
        lt = LT_OFF;
    switch (p) {
    case TP_LSPEED: return lt == LT_OFF ? &NONE_P : lt == LT_PUMP ? &LFO_SPEED_DUCK : &FIXED[p];
    case TP_LAMT: return &LFO_AMT[lt];
    case TP_LDEST:
        return lt == LT_WAVE || lt == LT_DRIFT ? &FIXED[p] : lt == LT_WOBBLE ? &LFO_DEST_TREM
               : lt == LT_PUMP ? &LFO_DEST_DUCK : &NONE_P;
    case TP_LX:
        if (lt == LT_WAVE || lt == LT_DRIFT) {
            switch (par[TP_LDEST] & 3) {
            case LD_SYNTH: return &lparam[engine < NENGINE ? engine : EG_KNIT];
            case LD_ENV: return &LFO_PARAM_ENV;
            case LD_FILTER: return &LFO_PARAM_FLT;
            default: return &LFO_PARAM_AMP;
            }
        }
        return lt == LT_WOBBLE ? &LFO_X_TREM : lt == LT_PUMP ? &LFO_X_DUCK : &NONE_P;
    case TP_LX2:
        return lt == LT_WAVE ? &FIXED[p] : lt == LT_WOBBLE ? &LFO_X2_TREM : lt == LT_DRIFT ? &LFO_X2_RAND : &NONE_P;
    default: break;
    }
    return tp_info(p, engine);
}

/* number formatting without printf (the firmware's libc is small) */
static char *put_s(char *b, const char *s)
{
    while (*s)
        *b++ = *s++;
    *b = 0;
    return b;
}
static char *put_i(char *b, int v)
{
    char tmp[12];
    int n = 0;
    if (v < 0) {
        *b++ = '-';
        v = -v;
    }
    do {
        tmp[n++] = (char)('0' + v % 10);
        v /= 10;
    } while (v);
    while (n)
        *b++ = tmp[--n];
    *b = 0;
    return b;
}
static char *put_f1(char *b, float x)           /* one decimal */
{
    int t = (int)(x * 10.0f + 0.5f);
    b = put_i(b, t / 10);
    *b++ = '.';
    return put_i(b, t % 10);
}
static void ms_text(float secs, char *num, char *unit)
{
    if (secs < 1.0f) {
        put_i(num, (int)(secs * 1000.0f + 0.5f));
        put_s(unit, "ms");
    } else {
        put_f1(num, secs);
        put_s(unit, "s");
    }
}
static void hz_text(float hz, char *num, char *unit)
{
    if (hz < 1000.0f) {
        put_i(num, (int)(hz + 0.5f));
        put_s(unit, "Hz");
    } else {
        put_f1(num, hz * 0.001f);
        put_s(unit, "kHz");
    }
}

static void tp_text_i(const tp_info_t *i, int p, int v, int engine, char *num, char *unit)
{
    unit[0] = 0;
    if(p>=TP_XMOD0 && p<NTP) {
        int f=(p-TP_XMOD0)%XM_FIELDS;
        if(f>=4 && !(f&1)) {
            /* tp_text's numeric buffer is 12 bytes; keep long route names in the graph only. */
            static const char *const short_layer[3]={"layer lvl","layer cut","layer pit"};
            put_s(num,v>=XD_LAYER_LEVEL && v<=XD_LAYER_PITCH ? short_layer[v-XD_LAYER_LEVEL] : synth_xmod_dest_name(v,engine));
            return;
        }
    }
    if (p == TP_X2 && engine == EG_SAMPLE && v == 0) {   /* (the loop's length: the sample's own, or the rest) */
        put_s(num, "auto");
        return;
    }
    if (p == TP_PORTA && v == 0) {
        put_s(num, "off");
        return;
    }
    if (p == TP_E2 && engine == EG_RAYON) {       /* the ratio: "1:1 +12c" in the detuned stretch, else "3.5:1" */
        float r = (float)(v > 127 ? 127 : v) * (100.0f / 127.0f);
        if (r <= 50.0f) {
            char *e = put_s(num, "1:1");
            if (r * 0.6f >= 0.5f)
                put_s(put_i(put_s(e, "+"), (int)(r * 0.6f + 0.5f)), "c");
        } else {
            int k = (int)((r - 51.0f) * (15.99f / 49.0f));
            float q = RAYON_RATIO[k < 0 ? 0 : k > 15 ? 15 : k];
            put_s((float)(int)q == q ? put_i(num, (int)q) : put_f1(num, q), ":1");
        }
        return;
    }
    switch (i->kind) {
    case PK_PCT:
        put_i(num, (v * 100 + 63) / 127);
        put_s(unit, "%");
        break;
    case PK_BIP:
        if (v - 64 > 0)
            *num++ = '+';
        put_i(num, v - 64);
        break;
    case PK_NAMES:
        if (i->names && v >= i->lo && v <= i->hi)
            put_s(num, i->names[v - i->lo]);
        else
            put_i(num, v);
        break;
    case PK_SEMI:
        put_i(num, v);
        put_s(unit, "st");
        break;
    case PK_SWITCH: put_s(num, v ? "on" : "off"); break;
    case PK_MS: ms_text(p==TP_LAYER_R ? layer_release_seconds((float)v*(1.0f/127.0f)) : env_seconds((float)v * (1.0f / 127.0f)), num, unit); break;
    case PK_HZ_SYNC:
        if (v < LS_SYNC_N) {
            put_s(num, SYNC_N[v]);
        } else {
            put_f1(num, lfo_hz(v, 120.0f));
            put_s(unit, "Hz");
        }
        break;
    case PK_NN: {                                /* two digits, 00..99 */
        int d = (v * 100 + 64) / 128;
        num[0] = (char)('0' + d / 10);
        num[1] = (char)('0' + d % 10);
        num[2] = 0;
        break;
    }
    case PK_HZ: hz_text(50.0f * fm_exp2f((float)v * (8.64385619f / 127.0f)), num, unit); break;
    case PK_FADE:
        if (v == 64) {
            put_s(num, "off");
        } else if (v < 64) {
            put_i(put_s(num, "in "), (64 - v) * 100 / 64);
            put_s(unit, "%");
        } else {
            put_i(put_s(num, "out "), (v - 64) * 100 / 63);
            put_s(unit, "%");
        }
        break;
    case PK_DB: {                                /* -30 .. +20 dB, 76 = 0 */
        int d = ((v - 76) * 50 + (v >= 76 ? 63 : -63)) / 127;
        if (d > 0)
            *num++ = '+';
        put_i(num, d);
        put_s(unit, "dB");
        break;
    }
    case PK_FADER: {                             /* tp_level_gain in dB: 60 log10(v / 100), tenths below 10 */
        int d;
        if (v <= 0) {
            put_s(num, "off");
            break;
        }
        d = (int)(fm_log2f((float)v * 0.01f) * 180.617997f + (v >= 100 ? 0.5f : -0.5f));   /* tenths */
        if (d > 0)
            *num++ = '+';
        else if (d < 0)
            *num++ = '-';
        d = d < 0 ? -d : d;
        num = put_i(num, d >= 100 ? (d + 5) / 10 : d / 10);
        if (d < 100 && d % 10) {
            *num++ = '.';
            put_i(num, d % 10);
        }
        put_s(unit, "dB");
        break;
    }
    case PK_SAMPLE: put_s(num, smp_name(v)); break;
    case PK_BIPST: case PK_CENT:
        if (v - 64 > 0)
            *num++ = '+';
        put_i(num, v - 64);
        put_s(unit, i->kind == PK_CENT ? "ct" : "st");
        break;
    case PK_DMS: case PK_DECAY:
        if (i->kind == PK_DECAY && v >= 127)
            put_s(num, "off");
        else if (v <= 0 && i->kind == PK_DMS) {
            put_s(num, "0");
            put_s(unit, "ms");
        } else
            ms_text(env_seconds((float)v * (1.0f / 127.0f)), num, unit);
        break;
    case PK_LAGMS:
        put_i(num, (v * 60 + 63) / 127);
        put_s(unit, "ms");
        break;
    default: put_i(num, v); break;
    }
}
void tp_text(int p, int v, int engine, char *num, char *unit) { tp_text_i(tp_info(p, engine), p, v, engine, num, unit); }
void tp_text_par(int p, int v, const uint8_t *par, char *num, char *unit)
{
    if (p >= TP_XMOD0 && p < NTP) {
        int f = (p - TP_XMOD0) % XM_FIELDS;
        if (f == 1) {
            static const char *const rt[XM_SYNC] = {"2/1","1/1","1/2","1/4D","1/4","1/8D","1/8","1/16D","1/16","1/32","1/64"};
            if (v < XM_SYNC) { put_s(num, rt[v]); unit[0] = 0; }
            else { int hz = (int)(xm_hz(v,120.0f)*100.0f+0.5f); char *e = put_i(num,hz/100);
                *e++ = '.'; *e++ = (char)('0'+hz/10%10); *e++ = (char)('0'+hz%10); *e=0; put_s(unit,"Hz"); }
            return;
        }
        if (f == 2) { put_i(num,(v * 360 + 64) / 128); put_s(unit,"deg"); return; }
        if (f >= 5 && (f & 1)) { int a=v-64; put_i(num,a < 0 ? a*100/64 : a*100/63); put_s(unit,"%"); return; }
    }

    int ct = par[TP_CTYPE];
    if ((p == TP_CTONE && (ct == CT_DRIVE || ct == CT_TAPE || ct == CT_SAMPLER)) || (p == TP_CAMT && ct == CT_TILT)) {
        float t = (float)(v > 127 ? 127 : v) * (1.0f / 127.0f);   /* a low-pass, the tilt's pivot: Hz */
        hz_text(p == TP_CAMT ? ch_pivot_hz(t) : ct == CT_TAPE ? ch_tape_hz(t) : ct == CT_SAMPLER ? ch_smp_hz(t) : ch_lp_hz(t),
                num, unit);
        return;
    }
    if (p == TP_CAMT && ct == CT_SAMPLER) {                       /* the rate */
        hz_text(ch_smp_rate((float)(v > 127 ? 127 : v) * (1.0f / 127.0f)), num, unit);
        return;
    }
    if (p == TP_CTONE && ct == CT_RING) {                         /* the ratio */
        put_s(num, RING_N[(v > 127 ? 127 : v) * 16 / 128]);
        unit[0] = 0;
        return;
    }
    tp_text_i(tp_info_par(p, par), p, v, par[TP_ENGINE], num, unit);
}

void layer_defaults(uint8_t *par)
{
    if(layer_engine(par[TP_ENGINE])) for(int i=0;i<LAYER_N;i++) par[TP_LAYER_MODE+i]=LAYER_INFO[i].def;
    if(par[TP_ENGINE]==EG_VOILE) par[TP_X2]=64;
}
void sound_default(uint8_t *par, int engine)
{
    int p, k;
    if (engine < 0 || engine >= NENGINE)
        engine = EG_KNIT;
    for (p = 0; p < TP_DRUM0; p++)
        par[p] = tp_info(p, engine)->def;
    par[TP_ENGINE] = (uint8_t)engine;
    for (k = 0; k < DL_NSOUND; k++) {
        for (p = 0; p < DP_N; p++)
            par[TP_DRUM(k, p)] = DL_DEFAULT_KIT[k][p];
        for (p = 0; p < DPX_N; p++)               /* knobs 5..8: the key's model's (0 for a model with four) */
            par[TP_DRUMX(k, p)] = DM_DEFAULT2[DL_DEFAULT_KIT[k][DP_MODEL] % NDM][p];
    }
    if (engine == EG_DRUMLINE)
        par[TP_FTYPE] = FT_DYNAMIC;
    par[TP_O2FINE] = 64;
    layer_defaults(par);
    for (p=TP_XMOD0;p<NTP;p++) par[p]=tp_info(p,engine)->def;
}

/* -------------------------------------------------------------- presets --- */
/* the factory presets: recipes in tools/presets/ (tools/presets/lib.py says how one is written), made into this
 * table by tools/gen_presets.py (app/fm1.toml gen; the host tests run it). Each engine's first preset is its sound in
 * a new project (and what choosing the engine loads) */
#include "presets.h"
const int NPRESETS = (int)(sizeof PRESETS / sizeof PRESETS[0]);

int preset_first(int engine)
{
    int i;
    for (i = 0; i < NPRESETS; i++)
        if (PRESETS[i].par[TP_ENGINE] == engine)
            return i;
    return -1;
}

#ifdef PLAT_WEB
unsigned bloom_export_mask = 1023u;
#endif
