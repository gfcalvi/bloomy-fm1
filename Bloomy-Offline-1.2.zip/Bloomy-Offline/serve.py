#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import argparse,socket,webbrowser,functools
p=argparse.ArgumentParser();p.add_argument('--lan',action='store_true');p.add_argument('--port',type=int,default=8893);a=p.parse_args()
root=Path(__file__).resolve().parent
class Handler(SimpleHTTPRequestHandler):
 def end_headers(self):
  self.send_header('Cache-Control','no-cache');super().end_headers()
host='0.0.0.0' if a.lan else '127.0.0.1'
server=ThreadingHTTPServer((host,a.port),functools.partial(Handler,directory=str(root)))
url=f'http://127.0.0.1:{a.port}/Bloomy.html'
print('Bloomy locale:',url,flush=True)
if a.lan:
 try:
  with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:
   s.connect(('192.0.2.1',80));ip=s.getsockname()[0]
  print(f'iPhone, sulla stessa rete Wi-Fi: http://{ip}:{a.port}/Bloomy.html',flush=True)
 except OSError: print('Usa l’indirizzo IP del Mac mostrato in Impostazioni di Sistema → Rete.',flush=True)
 print('Il server espone solo questa cartella sulla rete locale. Nessuna autenticazione. Ctrl-C per arrestare.',flush=True)
else:webbrowser.open(url)
try:server.serve_forever()
except KeyboardInterrupt:pass
finally:server.server_close()
