/* SPDX-License-Identifier: MPL-2.0
 * Copyright (C) 2026 Charles Vestal */
/* An fm1-base app in the browser: the host simulator (host/plat_host.c: the whole app, UI and sound, against a
 * simulated FM-1) compiled to WebAssembly and run in an AudioWorklet (from X0X's, by way of FoMni-1's). The worklet asks
 * for audio; producing it advances the device's clock one millisecond at a time, which runs the
 * app's render every APP_BLOCK samples (the I2S half buffer) and the UI every 16 ms, as on the FM-1. The page
 * sends input, and reads the screen, the lights and the saved objects back through these exports.
 *
 *   tools/build.py APP_DIR --web   ->  APP_DIR/build/emu/app.wasm (+ the page) */
#include <stdint.h>

static void web_audio(const int32_t *blk, uint32_t n);
#include "plat_host.c"

#undef __attribute__

/* output ring, stereo float, filled by run_ms, drained by web_render */
#define RING 4096u
static float ring[RING * 2];
static uint32_t ring_w, ring_r;
static void web_audio(const int32_t *blk, uint32_t n)
{
    uint32_t k;
    for (k = 0; k < n; k++) {
        uint32_t i = (ring_w++ % RING) * 2u;
        ring[i] = (float)blk[2 * k] / 8388608.0f;
        ring[i + 1] = (float)blk[2 * k + 1] / 8388608.0f;
    }
}

static float out_l[1024], out_r[1024];
__attribute__((used, visibility("default"))) float *web_out_l(void) { return out_l; }
__attribute__((used, visibility("default"))) float *web_out_r(void) { return out_r; }

/* n frames (<= 1024) into out_l / out_r: the device runs until they exist */
__attribute__((used, visibility("default"))) void web_render(uint32_t n)
{
    uint32_t k;
    if (n > 1024u)
        n = 1024u;
    while (ring_w - ring_r < n)
        run_ms(1);
    for (k = 0; k < n; k++) {
        uint32_t i = (ring_r++ % RING) * 2u;
        out_l[k] = ring[i];
        out_r[k] = ring[i + 1];
    }
}

/* a screen reader (fm1-reader): the page writes a SysEx frame (the bytes between F0 and F7) to web_sysex_buf and
 * calls web_sysex(n); what the firmware says back, whole F0..F7 frames, from web_said_buf (web_said_len bytes;
 * web_said_clear when read) */
static uint8_t said_buf[4096], sx_in[64];
static uint32_t said_n;
static void web_said(const uint8_t *p, uint32_t n)
{
    if (said_n + n <= sizeof said_buf) {
        memcpy(said_buf + said_n, p, n);
        said_n += n;
    }
}
__attribute__((used, visibility("default"))) uint8_t *web_said_buf(void) { return said_buf; }
__attribute__((used, visibility("default"))) uint32_t web_said_len(void) { return said_n; }
__attribute__((used, visibility("default"))) void web_said_clear(void) { said_n = 0; }
__attribute__((used, visibility("default"))) uint8_t *web_sysex_buf(void) { return sx_in; }
__attribute__((used, visibility("default"))) void web_sysex(uint32_t n) { ann_frame(sx_in, n > sizeof sx_in ? sizeof sx_in : n, now_ms); }

/* the page's screen reader on (1) or off (0): on, the reader's HELLO now and every 2 s of the device's time (as the
 * simulator's `listen`), so it never lapses while the page is in the background; off, its BYE (an app's words then
 * come through web_said_buf) */
__attribute__((used, visibility("default"))) void web_reader(int on)
{
    static const uint8_t HELLO[] = {ANN_H0, ANN_H1, ANN_H2, ANN_HELLO, ANN_VER}, BYE[] = {ANN_H0, ANN_H1, ANN_H2, ANN_BYE};
    sim_listen = on != 0;
    if (on)
        ann_frame(HELLO, sizeof HELLO, now_ms);
    else
        ann_frame(BYE, sizeof BYE, now_ms);
}

__attribute__((used, visibility("default"))) void web_boot(void) { boot(); }
__attribute__((used, visibility("default"))) void web_buttons(uint32_t m) { held_btn = m; }
__attribute__((used, visibility("default"))) void web_keys(uint32_t m)
{
#ifdef APP_KEY_SENSE
    uint32_t k, ch = m ^ held_keys;       /* each key landing at velocity 100 (the app makes its readings) */
    for (k = 0; k < NKEYS; k++)
        if (ch >> k & 1u)
            app_host_key(k, m >> k & 1u ? 100u : 0u, 0);
#endif
    held_keys = m;
}
/* one key at velocity vel 1..127 (0 = up), pressed press 0..1000 more (APP_KEY_SENSE; else just down or up) */
__attribute__((used, visibility("default"))) void web_key(uint32_t k, uint32_t vel, uint32_t press)
{
    if (k >= NKEYS)
        return;
#ifdef APP_KEY_SENSE
    app_host_key(k, vel > 127u ? 127u : vel, (press > 1000u ? 1000u : press) / 10u);
#endif
    if (vel)
        held_keys |= 1u << k;
    else
        held_keys &= ~(1u << k);
}
__attribute__((used, visibility("default"))) void web_enc(int role, int32_t n)
{
    if (role >= 0 && role < NE)
        enc_acc[role] += n;
}
__attribute__((used, visibility("default"))) void web_master(uint32_t v) { master = v > 4096u ? 4096u : v; }
__attribute__((used, visibility("default"))) uint32_t web_lit_buttons(void) { return lit_btn; }
__attribute__((used, visibility("default"))) uint32_t web_lit_keys(void) { return lit_keys; }
__attribute__((used, visibility("default"))) uint32_t web_dim_buttons(void) { return dim_btn; }
__attribute__((used, visibility("default"))) uint32_t web_dim_keys(void) { return dim_keys | mid_keys; }

/* MIDI: in from the page (port PORT_*: a Web MIDI input is USB), out as the app sent it (USB-MIDI packets) */
__attribute__((used, visibility("default"))) void web_midi_in(uint32_t port, uint32_t pkt)
{
    if (port < NPORTS && mi_w - mi_r < MQ) {
        min_q[mi_w % MQ] = pkt;
        min_port[mi_w++ % MQ] = port;
    }
}
__attribute__((used, visibility("default"))) uint32_t web_out_n(void) { return n_out; }
__attribute__((used, visibility("default"))) uint32_t *web_out_pkts(void) { return out_pkt; }
__attribute__((used, visibility("default"))) void web_out_clear(void) { n_out = 0; }
__attribute__((used, visibility("default"))) uint16_t *web_fb(void) { return fb; }
__attribute__((used, visibility("default"))) uint32_t web_blits(void) { return blits; }
__attribute__((used, visibility("default"))) uint32_t web_now(void) { return now_ms; }
__attribute__((used, visibility("default"))) uint32_t web_cpu(void) { return cpu_pct; }

/* saved objects: the page keeps them (localStorage) and gives them back before boot */
__attribute__((used, visibility("default"))) uint8_t *web_store(uint32_t obj) { store_ready(); return obj < OBJ_NOBJ ? store[obj] : 0; }
__attribute__((used, visibility("default"))) int web_store_len(uint32_t obj) { store_ready(); return obj < OBJ_NOBJ ? store_len[obj] : -1; }
__attribute__((used, visibility("default"))) void web_store_set_len(uint32_t obj, int n)
{
    store_ready();
    if (obj < OBJ_NOBJ)
        store_len[obj] = n < 0 ? -1 : n > (int)PLAT_STORE_MAX ? (int)PLAT_STORE_MAX : n;
}
__attribute__((used, visibility("default"))) uint32_t web_store_writes(void) { return store_writes; }
__attribute__((used, visibility("default"))) uint32_t web_nobj(void) { return OBJ_NOBJ; }
__attribute__((used, visibility("default"))) uint32_t web_store_max(void) { return PLAT_STORE_MAX; }

#ifdef APP_WEB
#include "web.c"                        /* the app's own exports for its page (app.h APP_WEB) */
#endif

/* Browser-only exports. This file is never part of a hardware build. */
static uint8_t export_bank[SMP_BANK_SIZE];
__attribute__((used,visibility("default"))) uint8_t *export_bank_ptr(void) { return export_bank; }
__attribute__((used,visibility("default"))) uint32_t export_bank_size(void) { return SMP_BANK_SIZE; }
__attribute__((used,visibility("default"))) int export_bank_load(uint32_t n) {
    if (n > SMP_BANK_SIZE) return -1;
    smp_user_drop();
    for (uint32_t v=0; v<SMP_BANK_SIZE; v+=4096) {
        uint32_t off; smp_reg_of(v,&off); plat_data_erase(off);
        if (v < n) plat_data_write(off, export_bank+v, n-v<4096?n-v:4096);
    }
    smp_user_scan(); return smp_user_slots();
}
__attribute__((used,visibility("default"))) int export_prepare(int slot,int song,unsigned mask,int mastered) {
    if(slot<1 || slot>NPROJ || project_load(slot-1)) return -1;
    after_load(); load_force=0; master=4096; proj.usb_full=0;
    seq.clock=proj.clock=SEQ_CLK_INTERNAL; seq.ext=seq.ext_pending=0;
    synth_host_solo=1023; bloom_export_mask=mask&1023; fx_host_stage=mastered?9:0;
    if(song && !pats.song.len) return -2;
    if(song) pats.song.loop=0; /* Export a finite arrangement once, regardless of live loop setting. */
    seq.song_on=!!song; seq.song_pos=0; seq.song_rep=0;
    if(song) engine_scene(pats.song.slot[0].scene%NSCENE,0);
    return pats.song.len;
}
__attribute__((used,visibility("default"))) void export_start(void) { engine_transport(3); }
__attribute__((used,visibility("default"))) void export_stop(void) { engine_transport(0); }
__attribute__((used,visibility("default"))) int export_playing(void) { return seq.playing; }
__attribute__((used,visibility("default"))) int export_scene(void) { return seq.scene; }
